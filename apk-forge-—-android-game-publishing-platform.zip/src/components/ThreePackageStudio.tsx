import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { GameRecord } from '../types/models';
import { formatBytes } from '../services/apiClient';

interface ThreePackageStudioProps {
  inspectedGame: GameRecord | null;
  onClose?: () => void;
}

type FinishPreset = 'titanium' | 'obsidian' | 'cobalt';
type CameraPreset = 'isometric' | 'top' | 'side';

// Pre-allocated module-scope scratch objects to guarantee zero GC allocations inside the render loop
const _targetCamPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _dummyMat4 = new THREE.Matrix4();
const _dummyPos = new THREE.Vector3();
const _dummyQuat = new THREE.Quaternion();
const _dummyScale = new THREE.Vector3();
const _dummyColor = new THREE.Color();

function createProceduralBumpTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  ctx.strokeStyle = '#9a9a9a';
  ctx.lineWidth = 2;
  for (let i = 16; i < 256; i += 32) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(256, i);
    ctx.stroke();
  }

  ctx.fillStyle = '#b5b5b5';
  for (let x = 16; x < 256; x += 32) {
    for (let y = 16; y < 256; y += 32) {
      ctx.fillRect(x - 3, y - 3, 6, 6);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createScreenDisplayTexture(
  game: GameRecord | null,
  maxAnisotropy: number,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;

  // Crisp studio screen canvas
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(0, 0, 512, 320);

  // Subtle grid lines
  ctx.strokeStyle = '#1E293B';
  ctx.lineWidth = 1;
  for (let x = 0; x <= 512; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 320);
    ctx.stroke();
  }
  for (let y = 0; y <= 320; y += 32) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // Header band
  ctx.fillStyle = '#1D4ED8';
  ctx.fillRect(24, 24, 464, 44);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('ANDROID PACKAGE VERIFICATION STUDIO', 40, 52);

  // Package details
  ctx.fillStyle = '#E2E8F0';
  ctx.font = 'bold 22px "Plus Jakarta Sans", sans-serif';
  const titleText = game ? game.title.slice(0, 32) : 'Standard APK Package Architecture';
  ctx.fillText(titleText, 32, 114);

  ctx.fillStyle = '#94A3B8';
  ctx.font = '15px "JetBrains Mono", monospace';
  const versionLine = game
    ? `VERSION: v${game.version}  ·  SIZE: ${formatBytes(game.fileSizeBytes)}`
    : 'ARCHIVE: PK\\x03\\x04 ZIP Container  ·  ABI: universal';
  ctx.fillText(versionLine, 32, 150);

  const manifestLine = game
    ? `MANIFEST: Verified (${game.apkInspection?.entryCount || 4} entries)`
    : 'MANIFEST: AndroidManifest.xml + classes.dex';
  ctx.fillText(manifestLine, 32, 182);

  const shaLine = game
    ? `SHA-256: ${game.sha256.slice(0, 24)}...`
    : 'SECURITY: Server-Validated Archive Structure';
  ctx.fillText(shaLine, 32, 214);

  // Bottom bar
  ctx.fillStyle = '#1E293B';
  ctx.fillRect(24, 250, 464, 42);
  ctx.fillStyle = '#38BDF8';
  ctx.font = '13px "JetBrains Mono", monospace';
  ctx.fillText('DRAG TO ORBIT · USE SLIDER TO EXPLODE APK LAYERS', 40, 276);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createRadialContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 128, 12, 128, 128, 120);
  grad.addColorStop(0, 'rgba(15, 23, 42, 0.55)');
  grad.addColorStop(0.55, 'rgba(15, 23, 42, 0.22)');
  grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export const ThreePackageStudio: React.FC<ThreePackageStudioProps> = ({
  inspectedGame,
  onClose,
}) => {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const [explodedAmount, setExplodedAmount] = useState<number>(0.35);
  const [finishPreset, setFinishPreset] = useState<FinishPreset>('titanium');
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('isometric');
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);

  // Store mutable state in refs so React UI updates never tear down the WebGL canvas
  const stateRef = useRef({
    explodedTarget: 0.35,
    explodedCurrent: 0.35,
    finishPreset: 'titanium' as FinishPreset,
    cameraPreset: 'isometric' as CameraPreset,
    cameraTransitionActive: false,
  });

  const requestRenderRef = useRef<(() => void) | null>(null);
  const updateScreenTexRef = useRef<((game: GameRecord | null) => void) | null>(null);
  const updateFinishRef = useRef<((finish: FinishPreset) => void) | null>(null);

  useEffect(() => {
    stateRef.current.explodedTarget = explodedAmount;
    requestRenderRef.current?.();
  }, [explodedAmount]);

  useEffect(() => {
    stateRef.current.finishPreset = finishPreset;
    updateFinishRef.current?.(finishPreset);
    requestRenderRef.current?.();
  }, [finishPreset]);

  useEffect(() => {
    stateRef.current.cameraPreset = cameraPreset;
    stateRef.current.cameraTransitionActive = true;
    requestRenderRef.current?.();
  }, [cameraPreset]);

  useEffect(() => {
    updateScreenTexRef.current?.(inspectedGame);
    requestRenderRef.current?.();
  }, [inspectedGame]);

  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    // 1. Software WebGL detection from GPU renderer string
    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = Math.max(mountEl.clientWidth, 320);
    const height = Math.max(mountEl.clientHeight, 300);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    mountEl.innerHTML = '';
    mountEl.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const horizonColor = new THREE.Color('#F1F5F9');
    scene.background = horizonColor;
    scene.fog = new THREE.FogExp2('#F1F5F9', 0.045);

    // 2. Studio Environment Map via RoomEnvironment + PMREMGenerator on every device
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(4.8, 3.6, 5.2);
    camera.lookAt(0, 0.65, 0);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.65, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.minDistance = 2.6;
    controls.maxDistance = 12;
    controls.maxPolarAngle = Math.PI / 2 - 0.04;

    // 3. Balanced 3-Point Studio Lighting Rig (Warm Key, Cool Hemisphere Fill, Rim Light)
    const hemiLight = new THREE.HemisphereLight('#E0F2FE', '#CBD5E1', 0.85);
    hemiLight.position.set(0, 10, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight('#FFF7ED', 2.2);
    keyLight.position.set(5, 8, 4);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 20;
    const d = 4.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight('#93C5FD', 1.1);
    rimLight.position.set(-5, 4, -5);
    scene.add(rimLight);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    const bumpTex = createProceduralBumpTexture(maxAnisotropy);
    let screenTex = createScreenDisplayTexture(inspectedGame, maxAnisotropy);
    const contactShadowTex = createRadialContactShadowTexture();

    // Ground studio floor + soft radial contact shadow disc (offset by >= 0.015 on Y to prevent Z-fighting)
    const floorGeo = new THREE.CircleGeometry(18, 48);
    const floorMat = new THREE.MeshStandardMaterial({
      color: '#F8FAFC',
      roughness: 0.85,
      metalness: 0.05,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = !isSoftwareGl;
    scene.add(floorMesh);

    const shadowGeo = new THREE.CircleGeometry(2.8, 32);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.015;
    scene.add(shadowMesh);

    // ========================================================================
    // 4. Composite 8-Part Procedural 3D Model (THREE.Group) pivoted at y = 0
    // ========================================================================
    const rootGroup = new THREE.Group();
    rootGroup.position.set(0, 0, 0);
    scene.add(rootGroup);

    // Part 1 (Primary Silhouette): Bevelled Android Testbed Pedestal & Chassis
    const chassisShape = new THREE.Shape();
    const cw = 3.2;
    const ch = 2.05;
    const cr = 0.24;
    chassisShape.moveTo(-cw / 2 + cr, -ch / 2);
    chassisShape.lineTo(cw / 2 - cr, -ch / 2);
    chassisShape.quadraticCurveTo(cw / 2, -ch / 2, cw / 2, -ch / 2 + cr);
    chassisShape.lineTo(cw / 2, ch / 2 - cr);
    chassisShape.quadraticCurveTo(cw / 2, ch / 2, cw / 2 - cr, ch / 2);
    chassisShape.lineTo(-cw / 2 + cr, ch / 2);
    chassisShape.quadraticCurveTo(-cw / 2, ch / 2, -cw / 2, ch / 2 - cr);
    chassisShape.lineTo(-cw / 2, -ch / 2 + cr);
    chassisShape.quadraticCurveTo(-cw / 2, -ch / 2, -cw / 2 + cr, -ch / 2);

    const chassisGeo = new THREE.ExtrudeGeometry(chassisShape, {
      depth: 0.18,
      bevelEnabled: true,
      bevelThickness: 0.04,
      bevelSize: 0.04,
      bevelSegments: 3,
    });
    chassisGeo.rotateX(-Math.PI / 2);

    const chassisMat = new THREE.MeshPhysicalMaterial({
      color: '#CBD5E1',
      metalness: 0.88,
      roughness: 0.24,
      clearcoat: 0.2,
    });
    const chassisMesh = new THREE.Mesh(chassisGeo, chassisMat);
    chassisMesh.position.y = 0.22;
    chassisMesh.castShadow = !isSoftwareGl;
    chassisMesh.receiveShadow = !isSoftwareGl;
    rootGroup.add(chassisMesh);

    // Part 2 (Primary Base): Grounded Dock Stand (flush with y = 0)
    const standGeo = new THREE.CylinderGeometry(0.95, 1.25, 0.22, 32);
    const standMat = new THREE.MeshStandardMaterial({
      color: '#334155',
      roughness: 0.65,
      metalness: 0.4,
    });
    const standMesh = new THREE.Mesh(standGeo, standMat);
    standMesh.position.y = 0.11; // bottom sits flush at y = 0
    standMesh.castShadow = !isSoftwareGl;
    rootGroup.add(standMesh);

    // Part 3 (Secondary Read): Optical Glass Display Panel
    const screenGeo = new THREE.PlaneGeometry(2.96, 1.82);
    const screenMat = new THREE.MeshPhysicalMaterial({
      map: screenTex,
      color: 0xffffff,
      roughness: 0.12,
      metalness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
    });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.rotation.x = -Math.PI / 2;
    screenMesh.position.y = 0.445;
    rootGroup.add(screenMesh);

    // Part 4 (Secondary Read - Exploded Layer 1): DEX Bytecode Silicon Core with bumpMap
    const dexGeo = new THREE.BoxGeometry(1.75, 0.1, 1.15);
    const dexMat = new THREE.MeshStandardMaterial({
      color: '#1E293B',
      roughness: 0.52,
      metalness: 0.65,
      bumpMap: bumpTex,
      bumpScale: 0.015,
    });
    const dexMesh = new THREE.Mesh(dexGeo, dexMat);
    dexMesh.position.y = 0.62;
    dexMesh.castShadow = !isSoftwareGl;
    rootGroup.add(dexMesh);

    // Part 5 (Secondary Read - Exploded Layer 2): Resources Asset Matrix Prism
    const resGeo = new THREE.BoxGeometry(1.4, 0.08, 0.9);
    const resMat = new THREE.MeshPhysicalMaterial({
      color: '#2563EB',
      roughness: 0.15,
      metalness: 0.2,
      transmission: isSoftwareGl ? 0 : 0.75,
      transparent: true,
      opacity: isSoftwareGl ? 0.72 : 1,
      ior: 1.5,
      thickness: 0.5,
      clearcoat: 1.0,
    });
    const resMesh = new THREE.Mesh(resGeo, resMat);
    resMesh.position.y = 0.85;
    resMesh.renderOrder = 2;
    rootGroup.add(resMesh);

    // Part 6 (Secondary Read - Exploded Layer 3): AndroidManifest.xml Cryptographic Seal Ring (LatheGeometry)
    const lathePoints = [
      new THREE.Vector2(0.42, 0),
      new THREE.Vector2(0.58, 0),
      new THREE.Vector2(0.6, 0.06),
      new THREE.Vector2(0.4, 0.06),
      new THREE.Vector2(0.42, 0),
    ];
    const sealGeo = new THREE.LatheGeometry(lathePoints, 36);
    const sealMat = new THREE.MeshPhysicalMaterial({
      color: '#F59E0B',
      metalness: 0.92,
      roughness: 0.18,
      anisotropy: 0.7,
    });
    const sealMesh = new THREE.Mesh(sealGeo, sealMat);
    sealMesh.position.y = 1.08;
    sealMesh.castShadow = !isSoftwareGl;
    rootGroup.add(sealMesh);

    // Part 7 (Accent Detail): Side Power/Volume Control Rails & Camera Bezel Ring
    const buttonGeo = new THREE.BoxGeometry(0.28, 0.06, 0.06);
    const buttonMat = new THREE.MeshStandardMaterial({
      color: '#0F172A',
      roughness: 0.3,
      metalness: 0.8,
    });
    const powerBtn = new THREE.Mesh(buttonGeo, buttonMat);
    powerBtn.position.set(0.9, 0.31, 1.07);
    rootGroup.add(powerBtn);

    const volBtn = new THREE.Mesh(buttonGeo, buttonMat);
    volBtn.position.set(0.45, 0.31, 1.07);
    rootGroup.add(volBtn);

    // Part 8 (InstancedMesh > 20 items): 28 Gold Package Bus Contact Pins
    const pinCount = 28;
    const pinGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.06, 12);
    const pinMat = new THREE.MeshStandardMaterial({
      color: '#FBBF24',
      metalness: 0.9,
      roughness: 0.2,
    });
    const pinsInstanced = new THREE.InstancedMesh(pinGeo, pinMat, pinCount);
    for (let i = 0; i < pinCount; i++) {
      const side = i < 14 ? -1 : 1;
      const idx = i % 14;
      const xPos = -0.78 + idx * 0.12;
      const zPos = side * 0.66;
      _dummyPos.set(xPos, 0.62, zPos);
      _dummyQuat.identity();
      const s = 0.92 + (i % 3) * 0.08;
      _dummyScale.set(s, 1, s);
      _dummyMat4.compose(_dummyPos, _dummyQuat, _dummyScale);
      pinsInstanced.setMatrixAt(i, _dummyMat4);
      _dummyColor.setHSL(0.11, 0.9, 0.52 + (i % 4) * 0.03);
      pinsInstanced.setColorAt(i, _dummyColor);
    }
    pinsInstanced.instanceMatrix.needsUpdate = true;
    if (pinsInstanced.instanceColor) pinsInstanced.instanceColor.needsUpdate = true;
    pinsInstanced.computeBoundingSphere();
    rootGroup.add(pinsInstanced);

    //Callbacks for React prop/state updates
    updateScreenTexRef.current = (newGame: GameRecord | null) => {
      const nextTex = createScreenDisplayTexture(newGame, maxAnisotropy);
      screenMat.map = nextTex;
      screenMat.needsUpdate = true;
      screenTex.dispose();
      screenTex = nextTex;
    };

    updateFinishRef.current = (finish: FinishPreset) => {
      if (finish === 'titanium') {
        chassisMat.color.set('#CBD5E1');
        chassisMat.roughness = 0.24;
      } else if (finish === 'obsidian') {
        chassisMat.color.set('#1E293B');
        chassisMat.roughness = 0.32;
      } else {
        chassisMat.color.set('#1D4ED8');
        chassisMat.roughness = 0.28;
      }
      chassisMat.needsUpdate = true;
    };

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // 5. On-Demand Coalesced Render & Software-WebGL Paced Scheduling
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let lastTimestamp = performance.now();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (sync && state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function requestRender() {
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame((now) => {
        renderDirty = false;
        const dt = Math.min(0.1, Math.max(0.001, (now - lastTimestamp) / 1000));
        lastTimestamp = now;

        let needsMoreFrames = false;

        // Smoothly damp exploded view separation
        const diffExplode = Math.abs(
          stateRef.current.explodedCurrent - stateRef.current.explodedTarget,
        );
        if (diffExplode > 0.002) {
          stateRef.current.explodedCurrent = THREE.MathUtils.damp(
            stateRef.current.explodedCurrent,
            stateRef.current.explodedTarget,
            10,
            dt,
          );
          needsMoreFrames = true;
        } else {
          stateRef.current.explodedCurrent = stateRef.current.explodedTarget;
        }

        const e = stateRef.current.explodedCurrent;
        dexMesh.position.y = 0.48 + e * 0.45;
        pinsInstanced.position.y = e * 0.45;
        resMesh.position.y = 0.56 + e * 0.95;
        sealMesh.position.y = 0.64 + e * 1.45;
        sealMesh.rotation.y = e * Math.PI * 0.5;

        // Smoothly damp camera preset transitions
        if (stateRef.current.cameraTransitionActive) {
          const preset = stateRef.current.cameraPreset;
          if (preset === 'isometric') {
            _targetCamPos.set(4.8, 3.6, 5.2);
          } else if (preset === 'top') {
            _targetCamPos.set(0.01, 6.8, 0.8);
          } else {
            _targetCamPos.set(6.2, 1.5, 0.2);
          }
          _targetLookAt.set(0, 0.65, 0);

          camera.position.x = THREE.MathUtils.damp(camera.position.x, _targetCamPos.x, 8, dt);
          camera.position.y = THREE.MathUtils.damp(camera.position.y, _targetCamPos.y, 8, dt);
          camera.position.z = THREE.MathUtils.damp(camera.position.z, _targetCamPos.z, 8, dt);
          controls.target.lerp(_targetLookAt, 1 - Math.exp(-8 * dt));

          if (camera.position.distanceToSquared(_targetCamPos) < 0.004) {
            stateRef.current.cameraTransitionActive = false;
          } else {
            needsMoreFrames = true;
          }
        }

        controls.update();
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || needsMoreFrames) {
            requestRender();
          }
        };

        if (isSoftwareGl) {
          afterDraw(done);
        } else {
          done();
        }
      });
    }

    requestRenderRef.current = requestRender;

    const handleControlStart = () => {
      stateRef.current.cameraTransitionActive = false;
    };
    const handleControlChange = () => {
      requestRender();
    };
    controls.addEventListener('start', handleControlStart);
    controls.addEventListener('change', handleControlChange);

    const handleResize = () => {
      if (!mountEl) return;
      const w = Math.max(mountEl.clientWidth, 320);
      const h = Math.max(mountEl.clientHeight, 300);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', handleResize);

    // Initial render
    requestRender();

    return () => {
      window.removeEventListener('resize', handleResize);
      controls.removeEventListener('start', handleControlStart);
      controls.removeEventListener('change', handleControlChange);
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      controls.dispose();
      envTexture.dispose();
      bumpTex.dispose();
      screenTex.dispose();
      contactShadowTex.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      chassisGeo.dispose();
      chassisMat.dispose();
      standGeo.dispose();
      standMat.dispose();
      screenGeo.dispose();
      screenMat.dispose();
      dexGeo.dispose();
      dexMat.dispose();
      resGeo.dispose();
      resMat.dispose();
      sealGeo.dispose();
      sealMat.dispose();
      buttonGeo.dispose();
      buttonMat.dispose();
      pinGeo.dispose();
      pinMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <section
      aria-label="3D Android APK Package Inspector Studio"
      className="relative w-full h-[460px] rounded-xl border border-slate-200 bg-slate-100 overflow-hidden select-none"
    >
      {/* Dedicated isolated WebGL canvas container */}
      <div
        ref={canvasMountRef}
        data-testid="three-package-canvas"
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* Minimal Top-Left Spec Header (100% unobstructed center viewport) */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="bg-white/95 border border-slate-200 rounded-lg px-3.5 py-2 shadow-xs pointer-events-auto">
          <div className="text-xs font-semibold text-slate-900">
            {inspectedGame
              ? `3D Package Studio · ${inspectedGame.title} (v${inspectedGame.version})`
              : '3D Android APK Package Architecture Studio'}
          </div>
          <div className="text-[11px] text-slate-600 font-mono tabular-nums">
            {inspectedGame
              ? `SHA-256 ${inspectedGame.sha256.slice(0, 16)}... · ${formatBytes(inspectedGame.fileSizeBytes)}`
              : 'AndroidManifest.xml Seal · classes.dex Core · resources.arsc Matrix'}
          </div>
        </div>

        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors pointer-events-auto whitespace-nowrap shrink-0"
          >
            Close 3D Studio
          </button>
        )}
      </div>

      {/* Unified Collapsible Bottom Control Dock (Zero backdrop-filter over WebGL) */}
      <div
        style={{
          bottom: '14px',
          left: '50%',
          transform: 'translateX(-50%)',
          maxWidth: 'min(880px, 94vw)',
        }}
        className="absolute z-10 w-full flex flex-col items-center pointer-events-none"
      >
        <button
          type="button"
          onClick={() => setDockCollapsed((prev) => !prev)}
          className="mb-1.5 px-3 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md shadow-xs hover:bg-slate-50 transition-colors pointer-events-auto whitespace-nowrap shrink-0"
        >
          {dockCollapsed ? '▴ Show Controls' : '▾ Hide Controls'}
        </button>

        {!dockCollapsed && (
          <div className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm flex flex-wrap items-center justify-between gap-4 pointer-events-auto">
            {/* Exploded View Slider */}
            <div className="flex items-center gap-2.5">
              <label
                htmlFor="apk-exploded-slider"
                className="text-xs font-medium text-slate-700 whitespace-nowrap"
              >
                Exploded Layers
              </label>
              <input
                id="apk-exploded-slider"
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={explodedAmount}
                onChange={(e) => setExplodedAmount( parseFloat(e.target.value) )}
                className="w-28 accent-blue-700 cursor-pointer"
              />
              <span className="text-xs font-mono text-slate-600 tabular-nums w-9">
                {Math.round(explodedAmount * 100)}%
              </span>
            </div>

            {/* Chassis Finish Selector */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-slate-600 mr-1 whitespace-nowrap">
                Finish
              </span>
              {(['titanium', 'obsidian', 'cobalt'] as FinishPreset[]).map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setFinishPreset(preset)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors capitalize whitespace-nowrap shrink-0 ${
                    finishPreset === preset
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>

            {/* Camera Angle Presets */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-slate-600 mr-1 whitespace-nowrap">
                Camera
              </span>
              {(['isometric', 'top', 'side'] as CameraPreset[]).map((cam) => (
                <button
                  key={cam}
                  type="button"
                  onClick={() => setCameraPreset(cam)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors capitalize whitespace-nowrap shrink-0 ${
                    cameraPreset === cam
                      ? 'bg-blue-700 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {cam}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
