import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  AlertTriangle,
  CheckCircle2,
  Clock,
  FileCheck,
  Mail,
  RefreshCw,
} from 'lucide-react';
import type { NotificationRecord, SubmissionRecord } from '../types/models';
import {
  api,
  ApiClientError,
  formatBytes,
  formatDateTime,
  uploadBinaryWithProgress,
  validateClientApkFile,
  type UploadTaskHandle,
} from '../services/apiClient';
import { GameIcon } from './GameIcon';
import { listRecentGmailReviewNotifications, type GmailMessagePreview } from '../services/gmailAuth';

interface MySubmissionsModalProps {
  isOpen: boolean;
  submissions: SubmissionRecord[];
  maxApkSizeBytes: number;
  onClose: () => void;
  onRefresh: () => Promise<void>;
}

export const MySubmissionsModal: React.FC<MySubmissionsModalProps> = ({
  isOpen,
  submissions,
  maxApkSizeBytes,
  onClose,
  onRefresh,
}) => {
  const [activeResubmitId, setActiveResubmitId] = useState<string | null>(null);
  const [resubmitDescription, setResubmitDescription] = useState('');
  const [resubmitVersion, setResubmitVersion] = useState('');
  const [resubmitFile, setResubmitFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const uploadTaskRef = useRef<UploadTaskHandle<{ submission: SubmissionRecord }> | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const startResubmitForm = (sub: SubmissionRecord) => {
    setActiveResubmitId(sub.submissionId);
    setResubmitDescription(sub.description);
    setResubmitVersion(sub.version);
    setResubmitFile(null);
    setUploadProgress(0);
    setError(null);
    setSuccessMsg(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const f = e.target.files?.[0] || null;
    if (!f) {
      setResubmitFile(null);
      return;
    }
    const check = validateClientApkFile(f, maxApkSizeBytes);
    if (!check.valid) {
      setError(check.error || 'Invalid APK file.');
      setResubmitFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    setResubmitFile(f);
  };

  const handleResubmitSubmit = async (e: React.FormEvent, submissionId: string) => {
    e.preventDefault();
    if (submitting) return;
    setError(null);
    setSuccessMsg(null);

    const fileCheck = validateClientApkFile(resubmitFile, maxApkSizeBytes);
    if (!fileCheck.valid || !resubmitFile) {
      setError(fileCheck.error || 'Please select a corrected .apk file.');
      return;
    }

    setSubmitting(true);
    setUploadProgress(0);

    try {
      const task = uploadBinaryWithProgress<{ submission: SubmissionRecord }>({
        url: `/api/submissions/${encodeURIComponent(submissionId)}/resubmit`,
        method: 'POST',
        file: resubmitFile,
        meta: {
          description: resubmitDescription.trim(),
          version: resubmitVersion.trim() || '1.0.1',
        },
        onProgress: (pct) => setUploadProgress(pct),
      });
      uploadTaskRef.current = task;
      await task.promise;
      setSuccessMsg(
        'Corrected APK uploaded and resubmitted! Status is now Pending administrator review.',
      );
      setActiveResubmitId(null);
      setResubmitFile(null);
      await onRefresh();
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'Failed to resubmit APK. Please try again.',
      );
    } finally {
      setSubmitting(false);
      uploadTaskRef.current = null;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="my-submissions-title"
    >
      <div className="relative w-full max-w-3xl max-h-[88vh] flex flex-col rounded-xl bg-white border border-slate-200 shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h2 id="my-submissions-title" className="text-lg font-bold text-slate-900">
              My Submissions
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Track review status, read administrator correction messages, and resubmit updated APKs.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close My Submissions"
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5">
          {successMsg && (
            <div className="flex items-center gap-2 rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs text-emerald-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="flex items-center gap-2 rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-xs text-red-800"
            >
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {submissions.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-slate-200 rounded-xl">
              <Clock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-800">No submissions yet</p>
              <p className="text-xs text-slate-500 mt-1">
                Games you submit through Add Apps will appear here with real-time review updates.
              </p>
            </div>
          ) : (
            submissions.map((sub) => (
              <div
                key={sub.submissionId}
                className="rounded-xl border border-slate-200 bg-white p-5 space-y-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5">
                    <GameIcon title={sub.title} size="md" />
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{sub.title}</h3>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 font-mono tabular-nums mt-1">
                        <span>v{sub.version}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formatBytes(sub.fileSizeBytes)}</span>
                        <span aria-hidden="true">·</span>
                        <span>Submitted {formatDateTime(sub.submittedAt)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Readable Status Label */}
                  <div className="text-xs font-semibold">
                    {sub.reviewStatus === 'Pending' && (
                      <span className="text-amber-700">Status: Pending</span>
                    )}
                    {sub.reviewStatus === 'Needs Changes' && (
                      <span className="text-blue-700">Status: Needs Changes</span>
                    )}
                    {sub.reviewStatus === 'Approved' && (
                      <span className="text-emerald-700">Status: Approved</span>
                    )}
                    {sub.reviewStatus === 'Rejected' && (
                      <span className="text-red-700">Status: Rejected</span>
                    )}
                  </div>
                </div>

                <p className="text-sm text-slate-700 leading-relaxed">{sub.description}</p>

                {/* Prominent Administrator Correction Request Message */}
                {sub.reviewStatus === 'Needs Changes' && sub.latestCorrectionMessage && (
                  <div className="rounded-lg bg-amber-50 border border-amber-200 p-4 space-y-2">
                    <div className="text-xs font-bold text-amber-900">
                      Administrator Correction Request
                    </div>
                    <p className="text-xs text-amber-900 leading-relaxed">
                      {sub.latestCorrectionMessage}
                    </p>
                    {activeResubmitId !== sub.submissionId && (
                      <button
                        type="button"
                        onClick={() => startResubmitForm(sub)}
                        className="mt-2 inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        Replace APK &amp; Resubmit for Review
                      </button>
                    )}
                  </div>
                )}

                {/* Rejection Explanation */}
                {sub.reviewStatus === 'Rejected' && sub.rejectionReason && (
                  <div className="rounded-lg bg-red-50 border border-red-200 p-3.5 text-xs text-red-900">
                    <span className="font-bold">Rejection Reason: </span>
                    {sub.rejectionReason}
                  </div>
                )}

                {/* Resubmission Form when Needs Changes is selected */}
                {sub.reviewStatus === 'Needs Changes' && activeResubmitId === sub.submissionId && (
                  <form
                    onSubmit={(e) => handleResubmitSubmit(e, sub.submissionId)}
                    className="rounded-xl bg-slate-50 border border-slate-200 p-4 space-y-3.5"
                  >
                    <div className="text-xs font-bold text-slate-900">
                      Submit Corrected APK for &ldquo;{sub.title}&rdquo;
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label
                          htmlFor={`resubmit-version-${sub.submissionId}`}
                          className="block text-xs font-medium text-slate-700 mb-1"
                        >
                          Updated Version Number
                        </label>
                        <input
                          id={`resubmit-version-${sub.submissionId}`}
                          type="text"
                          value={resubmitVersion}
                          onChange={(e) => setResubmitVersion(e.target.value)}
                          placeholder="1.0.1"
                          className="w-full px-3 py-1.5 text-sm font-mono rounded-lg border border-slate-300 bg-white text-slate-900"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor={`resubmit-apk-${sub.submissionId}`}
                          className="block text-xs font-medium text-slate-700 mb-1"
                        >
                          Replacement APK File (.apk only)
                        </label>
                        <input
                          ref={fileInputRef}
                          id={`resubmit-apk-${sub.submissionId}`}
                          type="file"
                          accept=".apk"
                          required
                          onChange={handleFileChange}
                          className="w-full text-xs text-slate-700 file:mr-2.5 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        />
                      </div>
                    </div>

                    {resubmitFile && (
                      <div className="flex items-center justify-between rounded-lg bg-white border border-slate-200 px-3 py-2 text-xs">
                        <div className="flex items-center gap-2 font-mono text-slate-700">
                          <FileCheck className="w-4 h-4 text-emerald-600" />
                          <span>{resubmitFile.name}</span>
                          <span>·</span>
                          <span>{formatBytes(resubmitFile.size)}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setResubmitFile(null);
                            if (fileInputRef.current) fileInputRef.current.value = '';
                          }}
                          className="text-slate-500 hover:text-red-600"
                        >
                          Remove
                        </button>
                      </div>
                    )}

                    <div>
                      <label
                        htmlFor={`resubmit-desc-${sub.submissionId}`}
                        className="block text-xs font-medium text-slate-700 mb-1"
                      >
                        Updated Description
                      </label>
                      <textarea
                        id={`resubmit-desc-${sub.submissionId}`}
                        rows={2}
                        required
                        value={resubmitDescription}
                        onChange={(e) => setResubmitDescription(e.target.value)}
                        className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white text-slate-900"
                      />
                    </div>

                    {submitting && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs font-mono text-slate-600">
                          <span>Uploading corrected APK...</span>
                          <span>{uploadProgress}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-700 transition-transform duration-150 origin-left"
                            style={{ transform: `scaleX(${uploadProgress / 100})` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          if (submitting && uploadTaskRef.current) {
                            uploadTaskRef.current.abort();
                          }
                          setActiveResubmitId(null);
                        }}
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={submitting}
                        className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg"
                      >
                        {submitting ? 'Resubmitting...' : 'Submit Corrected APK'}
                      </button>
                    </div>
                  </form>
                )}

                {/* Audit History of Review Decisions & Resubmissions */}
                {sub.correctionHistory && sub.correctionHistory.length > 0 && (
                  <div className="pt-3 border-t border-slate-100">
                    <div className="text-xs font-semibold text-slate-600 mb-2">
                      Submission &amp; Review History ({sub.correctionHistory.length})
                    </div>
                    <div className="space-y-1.5">
                      {sub.correctionHistory.map((item) => (
                        <div
                          key={item.entryId}
                          className="text-xs text-slate-600 flex flex-wrap items-baseline justify-between gap-2 bg-slate-50 rounded-md px-3 py-1.5"
                        >
                          <div>
                            <span className="font-semibold text-slate-800">{item.action}</span>
                            <span className="mx-1.5">·</span>
                            <span>{item.formattedNotice || item.message}</span>
                          </div>
                          <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                            {formatDateTime(item.timestamp)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

interface NotificationsModalProps {
  isOpen: boolean;
  notifications: NotificationRecord[];
  gmailConnected: boolean;
  onClose: () => void;
  onMarkRead: (id: string) => Promise<void>;
  onMarkAllRead: () => Promise<void>;
  onOpenMySubmissions: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  notifications,
  gmailConnected,
  onClose,
  onMarkRead,
  onMarkAllRead,
  onOpenMySubmissions,
}) => {
  const [gmailPreviews, setGmailPreviews] = useState<GmailMessagePreview[]>([]);
  const [loadingGmail, setLoadingGmail] = useState(false);

  const loadGmailLogs = async () => {
    if (!gmailConnected) return;
    setLoadingGmail(true);
    try {
      const items = await listRecentGmailReviewNotifications();
      setGmailPreviews(items);
    } finally {
      setLoadingGmail(false);
    }
  };

  React.useEffect(() => {
    if (isOpen && gmailConnected) {
      loadGmailLogs();
    }
  }, [isOpen, gmailConnected]);

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.readAt).length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="notifications-modal-title"
    >
      <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col rounded-xl bg-white border border-slate-200 shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h2 id="notifications-modal-title" className="text-lg font-bold text-slate-900">
              Notifications ({unreadCount} unread)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Internal platform alerts and review status updates for your submissions.
            </p>
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={onMarkAllRead}
                className="px-3 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
              >
                Mark all as read
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close notifications"
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto space-y-4">
          {notifications.length === 0 ? (
            <div className="text-center py-10 border border-dashed border-slate-200 rounded-xl text-xs text-slate-500">
              You have no notifications yet.
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.notificationId}
                className={`rounded-xl border p-4 transition-colors ${
                  n.readAt
                    ? 'border-slate-200 bg-white'
                    : 'border-blue-200 bg-blue-50/40'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{n.title}</h3>
                    <p className="text-xs text-slate-700 mt-1 leading-relaxed">{n.message}</p>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono tabular-nums mt-2">
                      <span>{formatDateTime(n.createdAt)}</span>
                      <span>·</span>
                      <span>
                        {n.emailDelivered
                          ? 'Delivered via Gmail + In-App Notification'
                          : 'Delivered via Internal Notification System'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {n.relatedSubmissionId && (
                      <button
                        type="button"
                        onClick={() => {
                          if (!n.readAt) onMarkRead(n.notificationId);
                          onClose();
                          onOpenMySubmissions();
                        }}
                        className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md whitespace-nowrap"
                      >
                        View Submission
                      </button>
                    )}
                    {!n.readAt && (
                      <button
                        type="button"
                        onClick={() => onMarkRead(n.notificationId)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-md whitespace-nowrap"
                      >
                        Mark read
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}

          {gmailConnected && (
            <div className="pt-4 border-t border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <Mail className="w-4 h-4 text-blue-700" />
                  <span>Connected Gmail APK Forge Messages</span>
                </div>
                <button
                  type="button"
                  onClick={loadGmailLogs}
                  disabled={loadingGmail}
                  className="inline-flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingGmail ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>
              {gmailPreviews.length === 0 ? (
                <p className="text-xs text-slate-500">
                  No recent APK Forge emails found in your connected Gmail mailbox.
                </p>
              ) : (
                <div className="space-y-2">
                  {gmailPreviews.map((msg) => (
                    <div
                      key={msg.id}
                      className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs space-y-1"
                    >
                      <div className="font-semibold text-slate-900">{msg.subject}</div>
                      <div className="text-slate-600 line-clamp-2">{msg.snippet}</div>
                      <div className="text-[11px] font-mono text-slate-400">
                        To: {msg.to} · {msg.date}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface GmailConfirmModalProps {
  isOpen: boolean;
  recipientEmail: string;
  subject: string;
  bodyText: string;
  onConfirmSend: () => Promise<void>;
  onCancelSkipEmail: () => Promise<void>;
}

export const GmailConfirmModal: React.FC<GmailConfirmModalProps> = ({
  isOpen,
  recipientEmail,
  subject,
  bodyText,
  onConfirmSend,
  onCancelSkipEmail,
}) => {
  const [sending, setSending] = useState(false);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="gmail-confirm-title"
    >
      <div className="w-full max-w-md rounded-xl bg-white border border-slate-200 p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-2.5">
          <Mail className="w-5 h-5 text-blue-700" />
          <h3 id="gmail-confirm-title" className="text-base font-bold text-slate-900">
            Confirm Sending Email via Gmail?
          </h3>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          You have connected your Google account. Please confirm whether you want to send the
          following email notification on your behalf via Gmail to{' '}
          <span className="font-semibold text-slate-900">{recipientEmail}</span>:
        </p>
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs space-y-1.5">
          <div>
            <span className="font-semibold text-slate-700">To:</span> {recipientEmail}
          </div>
          <div>
            <span className="font-semibold text-slate-700">Subject:</span> {subject}
          </div>
          <div className="pt-1 text-slate-700 whitespace-pre-wrap">{bodyText}</div>
        </div>
        <div className="flex items-center justify-end gap-2 pt-2">
          <button
            type="button"
            disabled={sending}
            onClick={async () => {
              setSending(true);
              try {
                await onCancelSkipEmail();
              } finally {
                setSending(false);
              }
            }}
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            Internal Notification Only
          </button>
          <button
            type="button"
            disabled={sending}
            onClick={async () => {
              setSending(true);
              try {
                await onConfirmSend();
              } finally {
                setSending(false);
              }
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
          >
            {sending ? 'Sending Email...' : 'Confirm & Send via Gmail'}
          </button>
        </div>
      </div>
    </div>
  );
};
