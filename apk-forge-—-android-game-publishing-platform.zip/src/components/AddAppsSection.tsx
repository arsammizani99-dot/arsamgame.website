import React, { useState, useRef } from 'react';
import {
  Upload,
  FileCheck,
  AlertCircle,
  CheckCircle2,
  ShieldCheck,
  Lock,
  MailCheck,
  X,
} from 'lucide-react';
import type { SubmissionRecord, UserRecord } from '../types/models';
import {
  ApiClientError,
  formatBytes,
  uploadBinaryWithProgress,
  validateClientApkFile,
  type UploadTaskHandle,
} from '../services/apiClient';
import { GameIcon } from './GameIcon';

interface AddAppsSectionProps {
  currentUser: UserRecord | null;
  maxApkSizeBytes: number;
  draftTitle: string;
  draftDescription: string;
  draftVersion: string;
  onDraftChange: (draft: { title: string; description: string; version: string }) => void;
  onRequireAuth: (mode: 'login' | 'register' | 'verify', reason: string) => void;
  onSubmissionCreated: (submission: SubmissionRecord) => Promise<void>;
  onOpenMySubmissions: () => void;
}

export const AddAppsSection: React.FC<AddAppsSectionProps> = ({
  currentUser,
  maxApkSizeBytes,
  draftTitle,
  draftDescription,
  draftVersion,
  onDraftChange,
  onRequireAuth,
  onSubmissionCreated,
  onOpenMySubmissions,
}) => {
  const [apkFile, setApkFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [submittedRecord, setSubmittedRecord] = useState<SubmissionRecord | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const uploadTaskRef = useRef<UploadTaskHandle<{ submission: SubmissionRecord }> | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setSubmittedRecord(null);
    const file = e.target.files?.[0] || null;
    if (!file) {
      setApkFile(null);
      return;
    }

    const validation = validateClientApkFile(file, maxApkSizeBytes);
    if (!validation.valid) {
      setError(validation.error || 'Invalid APK file.');
      setApkFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setApkFile(file);
  };

  const handleClearFile = () => {
    setApkFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleCancelUpload = () => {
    if (uploadTaskRef.current) {
      uploadTaskRef.current.abort();
      uploadTaskRef.current = null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (uploading) return;
    setError(null);
    setSubmittedRecord(null);

    if (!currentUser) {
      onRequireAuth(
        'login',
        'Please sign in with your email account before submitting an APK for review.',
      );
      return;
    }

    if (!currentUser.emailVerified) {
      onRequireAuth(
        'verify',
        'Please complete email verification before submitting an APK for review.',
      );
      return;
    }

    const cleanTitle = draftTitle.trim();
    const cleanDescription = draftDescription.trim();
    const cleanVersion = draftVersion.trim() || '1.0.0';

    if (cleanTitle.length < 2) {
      setError('Game title is required and must be at least 2 characters long.');
      return;
    }
    if (cleanDescription.length < 10) {
      setError('Game description is required and must be at least 10 characters long.');
      return;
    }

    const fileCheck = validateClientApkFile(apkFile, maxApkSizeBytes);
    if (!fileCheck.valid || !apkFile) {
      setError(fileCheck.error || 'Please select a valid .apk package file.');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      const task = uploadBinaryWithProgress<{ submission: SubmissionRecord }>({
        url: '/api/submissions',
        method: 'POST',
        file: apkFile,
        meta: {
          title: cleanTitle,
          description: cleanDescription,
          version: cleanVersion,
        },
        onProgress: (pct) => setUploadProgress(pct),
      });

      uploadTaskRef.current = task;
      const result = await task.promise;
      setSubmittedRecord(result.submission);
      onDraftChange({ title: '', description: '', version: '' });
      setApkFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
      await onSubmissionCreated(result.submission);
    } catch (err) {
      setError(
        err instanceof ApiClientError
          ? err.message
          : 'Failed to submit APK for review. Your form inputs have been preserved so you can retry.',
      );
    } finally {
      setUploading(false);
      uploadTaskRef.current = null;
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="pb-6 border-b border-slate-200">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          Submit an Android APK for Review
        </h1>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Registered developers can upload Android game packages (<code>.apk</code>) for
          administrator inspection. Submitted games are stored privately and are never published
          to Apps until approved by an administrator.
        </p>
      </div>

      {/* Authentication Gate Notice if Visitor is Not Signed In */}
      {!currentUser && (
        <div
          data-testid="add-apps-auth-prompt"
          className="rounded-xl border border-slate-200 bg-white p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Email Authentication Required to Submit Games
              </h2>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Please sign in or create an account with your email address before submitting an
                APK. Any draft details you enter below will be preserved while you sign in.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() =>
                onRequireAuth(
                  'login',
                  'Sign in to submit your Android APK for administrator review.',
                )
              }
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() =>
                onRequireAuth(
                  'register',
                  'Create a developer account to submit your Android APK.',
                )
              }
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              Create Account
            </button>
          </div>
        </div>
      )}

      {/* Email Verification Prompt if Signed In but Unverified */}
      {currentUser && !currentUser.emailVerified && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <MailCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-sm font-bold text-amber-900">
                Verify Your Email Address ({currentUser.email})
              </h2>
              <p className="text-xs text-amber-800 mt-1">
                Your account is signed in, but email verification is required before uploading APK
                submissions.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              onRequireAuth('verify', 'Verify your email address to submit APK packages.')
            }
            className="px-4 py-2 text-xs font-semibold text-white bg-amber-700 hover:bg-amber-800 rounded-lg transition-colors whitespace-nowrap"
          >
            Verify Email Now
          </button>
        </div>
      )}

      {/* Submission Confirmation Banner */}
      {submittedRecord && (
        <div
          data-testid="submission-success-banner"
          className="rounded-xl border border-emerald-200 bg-emerald-50 p-5 space-y-3"
        >
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h2 className="text-sm font-bold text-emerald-950">
                APK Submitted Successfully — Pending Administrator Review
              </h2>
              <p className="text-xs text-emerald-900 leading-relaxed">
                Your game <strong>{submittedRecord.title}</strong> (v{submittedRecord.version},{' '}
                {formatBytes(submittedRecord.fileSizeBytes)}) has been stored in private storage
                with status <strong>Pending</strong>. It is not published yet and will appear in
                Apps only after the administrator reviews and approves it.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 pl-8">
            <button
              type="button"
              onClick={onOpenMySubmissions}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors"
            >
              View in My Submissions
            </button>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3.5 text-xs text-red-800"
        >
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* APK Submission Form */}
      <form
        onSubmit={handleSubmit}
        className="rounded-xl border border-slate-200 bg-white p-6 sm:p-8 space-y-6"
      >
        {/* Live Generated App Icon & Submitter Identity Preview */}
        <div className="flex items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div className="flex items-center gap-3.5">
            <GameIcon title={draftTitle || 'New Game'} size="lg" />
            <div>
              <div className="text-xs font-medium text-slate-500">Generated App Icon Preview</div>
              <div className="text-base font-bold text-slate-900">
                {draftTitle.trim() || 'Untitled Android Game'}
              </div>
              <div className="text-xs text-slate-500 font-mono mt-0.5">
                {currentUser
                  ? `Submitter: ${currentUser.email}`
                  : 'Submitter: Sign in required'}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label
              htmlFor="submit-game-title"
              className="block text-xs font-semibold text-slate-700 mb-1.5"
            >
              Game Title <span className="text-red-600">*</span>
            </label>
            <input
              id="submit-game-title"
              type="text"
              required
              maxLength={120}
              value={draftTitle}
              onChange={(e) =>
                onDraftChange({
                  title: e.target.value,
                  description: draftDescription,
                  version: draftVersion,
                })
              }
              placeholder="e.g. Orbital Odyssey 3D"
              className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
            />
          </div>

          <div>
            <label
              htmlFor="submit-game-version"
              className="block text-xs font-semibold text-slate-700 mb-1.5"
            >
              Version Number <span className="text-slate-400 font-normal">(optional)</span>
            </label>
            <input
              id="submit-game-version"
              type="text"
              maxLength={40}
              value={draftVersion}
              onChange={(e) =>
                onDraftChange({
                  title: draftTitle,
                  description: draftDescription,
                  version: e.target.value,
                })
              }
              placeholder="1.0.0"
              className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
            />
          </div>
        </div>

        <div>
          <label
            htmlFor="submit-game-description"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Game Description <span className="text-red-600">*</span>
          </label>
          <textarea
            id="submit-game-description"
            rows={4}
            required
            maxLength={5000}
            value={draftDescription}
            onChange={(e) =>
              onDraftChange({
                title: draftTitle,
                description: e.target.value,
                version: draftVersion,
              })
            }
            placeholder="Describe gameplay mechanics, controls, minimum Android requirements, and what players can expect..."
            className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
          />
          <div className="mt-1 text-right text-[11px] font-mono text-slate-400 tabular-nums">
            {draftDescription.length} / 5000 characters
          </div>
        </div>

        {/* APK Package File Input */}
        <div>
          <label
            htmlFor="submit-apk-file"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Android APK Package File (<code>.apk</code> only) <span className="text-red-600">*</span>
          </label>

          <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-5">
            <input
              ref={fileInputRef}
              id="submit-apk-file"
              type="file"
              accept=".apk"
              onChange={handleFileSelect}
              className="block w-full text-xs text-slate-700 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-700 file:text-white hover:file:bg-blue-800 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 mt-2">
              Permitted format: standard Android <code>.apk</code> package containing{' '}
              <code>AndroidManifest.xml</code> (max {formatBytes(maxApkSizeBytes)}). ZIP, EXE, MSI,
              AAB, HTML, and IPA files are strictly rejected.
            </p>

            {apkFile && (
              <div className="mt-3 flex items-center justify-between rounded-lg bg-white border border-slate-200 px-3.5 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-xs font-semibold text-slate-900 truncate">
                    {apkFile.name}
                  </span>
                  <span className="text-xs font-mono text-slate-500 tabular-nums shrink-0">
                    ({formatBytes(apkFile.size)})
                  </span>
                </div>
                {!uploading && (
                  <button
                    type="button"
                    onClick={handleClearFile}
                    aria-label="Remove selected APK file"
                    className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-red-600"
                  >
                    <X className="w-3.5 h-3.5" />
                    Remove
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Upload Progress Bar */}
        {uploading && (
          <div className="rounded-lg bg-blue-50 border border-blue-200 p-4 space-y-2">
            <div className="flex items-center justify-between text-xs font-mono text-blue-900 tabular-nums">
              <span>Uploading and validating APK archive structure...</span>
              <span>{uploadProgress}%</span>
            </div>
            <div className="w-full h-2 bg-blue-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-700 transition-transform duration-150 origin-left"
                style={{ transform: `scaleX(${uploadProgress / 100})` }}
              />
            </div>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleCancelUpload}
                className="text-xs font-semibold text-red-700 hover:underline"
              >
                Cancel Upload
              </button>
            </div>
          </div>
        )}

        {/* Security & Review Process Explanation */}
        <div className="flex items-start gap-2.5 rounded-lg bg-slate-50 border border-slate-200 p-3.5 text-xs text-slate-600">
          <ShieldCheck className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
          <span>
            Server validation verifies the APK archive header and <code>AndroidManifest.xml</code>{' '}
            structure before saving to private storage. Format validation confirms package structure
            only and does not replace runtime malware analysis during administrator review.
          </span>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            disabled={uploading}
            className="inline-flex items-center gap-2 py-2.5 px-5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            {uploading ? 'Submitting APK...' : 'Submit APK for Review'}
          </button>
        </div>
      </form>
    </div>
  );
};
