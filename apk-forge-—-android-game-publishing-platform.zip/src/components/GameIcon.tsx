import React from 'react';

interface GameIconProps {
  title: string;
  size?: 'sm' | 'md' | 'lg';
}

const PALETTES = [
  { bg: '#EFF6FF', accent: '#1D4ED8', secondary: '#93C5FD', text: '#1E3A8A' },
  { bg: '#F0FDF4', accent: '#15803D', secondary: '#86EFAC', text: '#14532D' },
  { bg: '#FEF2F2', accent: '#B91C1C', secondary: '#FCA5A5', text: '#7F1D1D' },
  { bg: '#FFFBEB', accent: '#B45309', secondary: '#FCD34D', text: '#78350F' },
  { bg: '#F5F3FF', accent: '#6D28D9', secondary: '#C4B5FD', text: '#4C1D95' },
  { bg: '#ECFEFF', accent: '#0E7490', secondary: '#67E8F9', text: '#164E63' },
  { bg: '#F8FAFC', accent: '#334155', secondary: '#94A3B8', text: '#0F172A' },
];

export const GameIcon: React.FC<GameIconProps> = ({ title, size = 'md' }) => {
  const clean = (title || 'Game').trim();
  const words = clean.split(/\s+/).filter(Boolean);
  let initials = 'GM';
  if (words.length >= 2) {
    initials = (words[0][0] + words[1][0]).toUpperCase();
  } else if (words.length === 1 && words[0].length >= 2) {
    initials = words[0].slice(0, 2).toUpperCase();
  } else if (words.length === 1 && words[0].length === 1) {
    initials = words[0].toUpperCase();
  }

  let hash = 0;
  for (let i = 0; i < clean.length; i++) {
    hash = (hash * 31 + clean.charCodeAt(i)) >>> 0;
  }

  const palette = PALETTES[hash % PALETTES.length];
  const pattern = hash % 3;

  const dimensions =
    size === 'sm'
      ? 'w-10 h-10 text-xs rounded-lg'
      : size === 'lg'
        ? 'w-16 h-16 text-lg rounded-xl'
        : 'w-12 h-12 text-sm rounded-xl';

  return (
    <div
      className={`relative flex items-center justify-center shrink-0 overflow-hidden border border-slate-200 select-none font-bold tracking-tight ${dimensions}`}
      style={{ backgroundColor: palette.bg, color: palette.text }}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 64 64"
        className="absolute inset-0 w-full h-full opacity-25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {pattern === 0 && (
          <>
            <circle cx="52" cy="12" r="20" fill={palette.secondary} />
            <rect x="-6" y="42" width="32" height="32" rx="8" fill={palette.accent} />
          </>
        )}
        {pattern === 1 && (
          <>
            <polygon points="32,4 60,56 4,56" fill={palette.secondary} />
            <circle cx="14" cy="16" r="10" fill={palette.accent} />
          </>
        )}
        {pattern === 2 && (
          <>
            <rect x="34" y="6" width="24" height="24" rx="6" fill={palette.accent} />
            <rect x="6" y="34" width="24" height="24" rx="6" fill={palette.secondary} />
          </>
        )}
      </svg>
      <span className="relative z-10 font-mono font-semibold">{initials}</span>
    </div>
  );
};
