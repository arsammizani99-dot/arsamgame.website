import React, { useState } from 'react';
import { Download, Search, Box, AlertCircle, RefreshCw, PackageOpen } from 'lucide-react';
import type { GameRecord } from '../types/models';
import { formatBytes, formatDateShort } from '../services/apiClient';
import { GameIcon } from './GameIcon';
import { ThreePackageStudio } from './ThreePackageStudio';

interface AppsSectionProps {
  games: GameRecord[];
  loading: boolean;
  error: string | null;
  searchQuery: string;
  downloadingGameId: string | null;
  downloadStatusError: string | null;
  onSearchChange: (q: string) => void;
  onRetryLoad: () => void;
  onDownloadGame: (game: GameRecord) => void;
  onNavigateAddApps: () => void;
}

export const AppsSection: React.FC<AppsSectionProps> = ({
  games,
  loading,
  error,
  searchQuery,
  downloadingGameId,
  downloadStatusError,
  onSearchChange,
  onRetryLoad,
  onDownloadGame,
  onNavigateAddApps,
}) => {
  const [show3DStudio, setShow3DStudio] = useState<boolean>(false);
  const [inspectedGame, setInspectedGame] = useState<GameRecord | null>(null);

  const handleInspect3D = (game: GameRecord) => {
    setInspectedGame(game);
    setShow3DStudio(true);
  };

  return (
    <div className="space-y-8">
      {/* Section Header & Search Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Published Android Games
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Verified Android APK packages published or approved by the platform administrator. Sign in
            with a verified email account to download any game package.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-3 shrink-0">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              aria-label="Search published games by title"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search games by title..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
            />
          </div>

          <button
            type="button"
            onClick={() => setShow3DStudio((prev) => !prev)}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              show3DStudio
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <Box className="w-4 h-4" />
            {show3DStudio ? 'Hide 3D Package Studio' : '3D Package Studio'}
          </button>
        </div>
      </div>

      {/* Optional 3D Android APK Package & Hardware Inspector Viewport */}
      {show3DStudio && (
        <ThreePackageStudio
          inspectedGame={inspectedGame}
          onClose={() => setShow3DStudio(false)}
        />
      )}

      {/* Download Error Banner */}
      {downloadStatusError && (
        <div
          role="alert"
          className="flex items-center gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-xs text-red-800"
        >
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{downloadStatusError}</span>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div
          role="alert"
          className="flex items-center justify-between gap-4 rounded-xl bg-red-50 border border-red-200 px-5 py-4 text-sm text-red-900"
        >
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={onRetryLoad}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-red-800 bg-white border border-red-300 rounded-lg hover:bg-red-100 whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* Loading Skeletons */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="rounded-xl border border-slate-200 bg-white p-6 space-y-4 animate-pulse"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-slate-200" />
                <div className="space-y-2 flex-1">
                  <div className="h-4 bg-slate-200 rounded w-2/3" />
                  <div className="h-3 bg-slate-100 rounded w-1/2" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-3 bg-slate-100 rounded w-full" />
                <div className="h-3 bg-slate-100 rounded w-4/5" />
              </div>
              <div className="h-9 bg-slate-200 rounded-lg w-full" />
            </div>
          ))}
        </div>
      )}

      {/* Empty Library State (Initial Launch or No Search Matches) */}
      {!loading && !error && games.length === 0 && (
        <div
          data-testid="apps-empty-state"
          className="rounded-xl border border-slate-200 bg-white px-6 py-16 text-center max-w-xl mx-auto my-4"
        >
          <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto mb-4 text-slate-500">
            <PackageOpen className="w-6 h-6" />
          </div>
          {searchQuery.trim() ? (
            <>
              <h2 className="text-base font-bold text-slate-900">
                No published games match &ldquo;{searchQuery.trim()}&rdquo;
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Try clearing your search filter or searching for a different game title.
              </p>
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="mt-4 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Clear Search
              </button>
            </>
          ) : (
            <>
              <h2 className="text-base font-bold text-slate-900">No games published yet.</h2>
              <p className="text-xs text-slate-500 mt-1.5 max-w-sm mx-auto leading-relaxed">
                This library displays verified Android APK games once they are published by the
                administrator in Panel or approved from a developer submission in Add Apps.
              </p>
              <div className="mt-5 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={onNavigateAddApps}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
                >
                  Submit an APK for Review
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* Responsive Game Cards Grid */}
      {!loading && !error && games.length > 0 && (
        <div
          data-testid="published-games-grid"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {games.map((game) => {
            const isDownloading = downloadingGameId === game.gameId;
            return (
              <article
                key={game.gameId}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 hover:border-slate-300 transition-colors"
              >
                <div>
                  <div className="flex items-start gap-3.5">
                    <GameIcon title={game.title} size="md" />
                    <div className="min-w-0 flex-1">
                      <h2 className="text-base font-bold text-slate-900 truncate" title={game.title}>
                        {game.title}
                      </h2>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 font-mono tabular-nums mt-1">
                        {game.version && (
                          <>
                            <span>v{game.version}</span>
                            <span aria-hidden="true">·</span>
                          </>
                        )}
                        <span>{formatBytes(game.fileSizeBytes)}</span>
                        <span aria-hidden="true">·</span>
                        <span>Published {formatDateShort(game.publishedAt)}</span>
                      </div>
                    </div>
                  </div>

                  <p className="mt-4 text-sm text-slate-600 leading-relaxed line-clamp-4">
                    {game.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-2">
                  <button
                    type="button"
                    disabled={isDownloading}
                    onClick={() => onDownloadGame(game)}
                    className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <Download className="w-4 h-4 shrink-0" />
                    {isDownloading ? 'Preparing APK...' : 'Download APK'}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleInspect3D(game)}
                    aria-label={`Inspect ${game.title} in 3D Studio`}
                    className="py-2.5 px-3 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    3D View
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
