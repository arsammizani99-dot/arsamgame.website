import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, CheckCircle2, AlertCircle, X, KeyRound } from 'lucide-react';
import type { UserRecord } from '../types/models';
import { api, ApiClientError, setStoredUserToken } from '../services/apiClient';
import { googleSignIn } from '../services/gmailAuth';

export type AuthModalMode = 'login' | 'register' | 'verify' | 'forgot' | 'reset';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: AuthModalMode;
  contextMessage?: string | null;
  currentUser: UserRecord | null;
  pendingVerificationToken: string | null;
  onClose: () => void;
  onAuthSuccess: (user: UserRecord, verificationToken?: string | null, googleAccessToken?: string | null) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  contextMessage,
  currentUser,
  pendingVerificationToken,
  onClose,
  onAuthSuccess,
}) => {
  const [mode, setMode] = useState<AuthModalMode>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [verificationTokenInput, setVerificationTokenInput] = useState(
    pendingVerificationToken || '',
  );
  const [resetTokenInput, setResetTokenInput] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  React.useEffect(() => {
    if (isOpen) {
      if (currentUser && !currentUser.emailVerified) {
        setMode('verify');
      } else {
        setMode(initialMode);
      }
      setError(null);
      setInfoMessage(null);
      if (pendingVerificationToken) {
        setVerificationTokenInput(pendingVerificationToken);
      }
    }
  }, [isOpen, initialMode, currentUser, pendingVerificationToken]);

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setInfoMessage(null);
    setLoading(true);

    try {
      const res = await api.login(email, password);
      setStoredUserToken(res.sessionToken);
      if (!res.user.emailVerified) {
        setVerificationTokenInput(res.verificationToken || '');
        onAuthSuccess(res.user, res.verificationToken);
        setMode('verify');
        setInfoMessage('Signed in. Please verify your email address to unlock APK downloads and submissions.');
      } else {
        onAuthSuccess(res.user, null);
        onClose();
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to sign in. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setInfoMessage(null);
    setLoading(true);

    try {
      const res = await api.register(email, password);
      setStoredUserToken(res.sessionToken);
      setVerificationTokenInput(res.verificationToken);
      onAuthSuccess(res.user, res.verificationToken);
      setMode('verify');
      setInfoMessage(
        'Account created! Complete email verification below to enable APK downloads and game submissions.',
      );
    } catch (err) {
      setError(
        err instanceof ApiClientError ? err.message : 'Registration failed. Please check your details.',
      );
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setLoading(true);

    try {
      const res = await api.verifyEmail(verificationTokenInput.trim() || undefined);
      onAuthSuccess(res.user, null);
      onClose();
    } catch (err) {
      setError(
        err instanceof ApiClientError
          ? err.message
          : 'Failed to verify email address. Please check the verification code.',
      );
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setInfoMessage(null);
    setLoading(true);

    try {
      const res = await api.forgotPassword(email);
      if (res.resetToken) {
        setResetTokenInput(res.resetToken);
      }
      setInfoMessage(res.message);
      setMode('reset');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Unable to request password reset.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    setInfoMessage(null);
    setLoading(true);

    try {
      const res = await api.resetPassword(email, resetTokenInput, newPassword);
      setInfoMessage(res.message);
      setPassword('');
      setMode('login');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'Password reset failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (loading) return;
    setError(null);
    setLoading(true);

    try {
      const googleRes = await googleSignIn();
      if (googleRes && googleRes.user.email) {
        const syncRes = await api.googleSync(
          googleRes.user.email,
          googleRes.user.uid,
          true,
        );
        setStoredUserToken(syncRes.sessionToken);
        onAuthSuccess(syncRes.user, null, googleRes.accessToken);
        onClose();
      }
    } catch (err: unknown) {
      const msg =
        err instanceof Error ? err.message : 'Google Sign-In was cancelled or could not complete.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="relative w-full max-w-md rounded-xl bg-white border border-slate-200 p-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h2 id="auth-modal-title" className="text-lg font-bold text-slate-900">
              {mode === 'login' && 'Sign In to Your Account'}
              {mode === 'register' && 'Create a Publisher Account'}
              {mode === 'verify' && 'Verify Your Email Address'}
              {mode === 'forgot' && 'Reset Your Password'}
              {mode === 'reset' && 'Set a New Password'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {mode === 'login' && 'Sign in with your verified email to download or submit APK games.'}
              {mode === 'register' && 'Register with your email address to submit and download Android APKs.'}
              {mode === 'verify' && 'Verified accounts are required for APK downloads and submissions.'}
              {mode === 'forgot' && 'Enter your registered email address to receive a reset token.'}
              {mode === 'reset' && 'Enter your reset token and choose a new password.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close authentication modal"
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {contextMessage && (
          <div className="mt-4 rounded-lg bg-blue-50 border border-blue-200 px-3.5 py-2.5 text-xs text-blue-900">
            {contextMessage}
          </div>
        )}

        {error && (
          <div
            role="alert"
            className="mt-4 flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs text-red-800"
          >
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {infoMessage && (
          <div className="mt-4 flex items-start gap-2 rounded-lg bg-emerald-50 border border-emerald-200 px-3.5 py-2.5 text-xs text-emerald-900">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>{infoMessage}</span>
          </div>
        )}

        {(mode === 'login' || mode === 'register') && (
          <form
            onSubmit={mode === 'login' ? handleLoginSubmit : handleRegisterSubmit}
            className="mt-5 space-y-4"
          >
            <div>
              <label
                htmlFor="auth-email-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="auth-email-input"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="developer@example.com"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="auth-password-input"
                  className="block text-xs font-semibold text-slate-700"
                >
                  Password
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setInfoMessage(null);
                      setMode('forgot');
                    }}
                    className="text-xs font-medium text-blue-700 hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="auth-password-input"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full pl-9 pr-10 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              {loading
                ? mode === 'login'
                  ? 'Signing In...'
                  : 'Creating Account...'
                : mode === 'login'
                  ? 'Sign In with Email'
                  : 'Create Account'}
            </button>

            <div className="relative flex py-1 items-center">
              <div className="grow border-t border-slate-200" />
              <span className="shrink mx-3 text-xs text-slate-400">or connect with Google & Gmail</span>
              <div className="grow border-t border-slate-200" />
            </div>

            {/* Official Google Sign-In button style per workspace-integration skill */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="gsi-material-button w-full flex items-center justify-center gap-2.5 py-2 px-4 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-sm font-medium text-slate-700 transition-colors cursor-pointer"
            >
              <div className="gsi-material-button-icon w-4 h-4 shrink-0">
                <svg
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 48 48"
                  style={{ display: 'block', width: '100%', height: '100%' }}
                >
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                  <path fill="none" d="M0 0h48v48H0z" />
                </svg>
              </div>
              <span className="gsi-material-button-contents">Sign in with Google</span>
            </button>

            <div className="pt-2 text-center text-xs text-slate-600">
              {mode === 'login' ? (
                <>
                  Don&apos;t have an account yet?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setInfoMessage(null);
                      setMode('register');
                    }}
                    className="font-semibold text-blue-700 hover:underline"
                  >
                    Create Account
                  </button>
                </>
              ) : (
                <>
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setInfoMessage(null);
                      setMode('login');
                    }}
                    className="font-semibold text-blue-700 hover:underline"
                  >
                    Sign In
                  </button>
                </>
              )}
            </div>
          </form>
        )}

        {mode === 'verify' && (
          <form onSubmit={handleVerifyEmail} className="mt-5 space-y-4">
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-3.5 text-xs text-slate-700 space-y-1.5">
              <div className="font-semibold text-slate-900">
                Account: {currentUser?.email || email}
              </div>
              <p>
                To protect the platform against automated abuse, email verification is enforced before
                downloading published APKs or submitting new games.
              </p>
              {verificationTokenInput && (
                <div className="pt-1 font-mono text-[11px] text-slate-600">
                  Verification Token: <span className="font-semibold text-slate-900">{verificationTokenInput}</span>
                </div>
              )}
            </div>

            <div>
              <label
                htmlFor="verify-token-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Verification Token
              </label>
              <input
                id="verify-token-input"
                type="text"
                required
                value={verificationTokenInput}
                onChange={(e) => setVerificationTokenInput(e.target.value)}
                placeholder="vrf_..."
                className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              {loading ? 'Verifying Email...' : 'Complete Email Verification'}
            </button>
          </form>
        )}

        {mode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="mt-5 space-y-4">
            <div>
              <label
                htmlFor="forgot-email-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Registered Email Address
              </label>
              <input
                id="forgot-email-input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="developer@example.com"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors"
            >
              {loading ? 'Generating Reset Token...' : 'Request Password Reset'}
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Back to Sign In
              </button>
            </div>
          </form>
        )}

        {mode === 'reset' && (
          <form onSubmit={handleResetPassword} className="mt-5 space-y-4">
            <div>
              <label
                htmlFor="reset-token-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Reset Token
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="reset-token-input"
                  type="text"
                  required
                  value={resetTokenInput}
                  onChange={(e) => setResetTokenInput(e.target.value)}
                  placeholder="rst_..."
                  className="w-full pl-9 pr-3 py-2 text-sm font-mono rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="reset-new-password"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                New Password
              </label>
              <input
                id="reset-new-password"
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors"
            >
              {loading ? 'Updating Password...' : 'Confirm Password Reset'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
