import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Lock,
  Eye,
  EyeOff,
  Upload,
  CheckCircle2,
  XCircle,
  MessageSquareWarning,
  Download,
  Search,
  Edit3,
  Trash2,
  EyeOff as UnpublishIcon,
  Globe,
  FileCheck,
  AlertCircle,
  RefreshCw,
  LogOut,
  History,
  X,
} from 'lucide-react';
import type {
  AuditLogRecord,
  GameRecord,
  PlatformStats,
  SubmissionRecord,
} from '../types/models';
import {
  api,
  ApiClientError,
  formatBytes,
  formatDateTime,
  uploadBinaryWithProgress,
  validateClientApkFile,
  type UploadTaskHandle,
} from '../services/apiClient';
import { GameIcon } from './GameIcon';
import { GmailConfirmModal } from './AccountModals';
import { getAccessToken, sendGmailMessage } from '../services/gmailAuth';

interface PanelSectionProps {
  adminToken: string | null;
  maxApkSizeBytes: number;
  onUnlockSuccess: (token: string) => void;
  onLockPanel: () => void;
  onPublicCatalogChanged: () => Promise<void>;
}

type PanelInternalTab = 'publish' | 'approvals';

export const PanelSection: React.FC<PanelSectionProps> = ({
  adminToken,
  maxApkSizeBytes,
  onUnlockSuccess,
  onLockPanel,
  onPublicCatalogChanged,
}) => {
  // Password Gate State
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [verifyingPassword, setVerifyingPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Internal Panel Dashboard State
  const [activeTab, setActiveTab] = useState<PanelInternalTab>('publish');
  const [stats, setStats] = useState<PlatformStats>({
    totalPublishedGames: 0,
    totalUnpublishedGames: 0,
    pendingSubmissions: 0,
    approvedSubmissions: 0,
    rejectedSubmissions: 0,
    needsChangesSubmissions: 0,
  });
  const [adminGames, setAdminGames] = useState<GameRecord[]>([]);
  const [submissions, setSubmissions] = useState<SubmissionRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);
  const [loadingDashboard, setLoadingDashboard] = useState(false);
  const [dashboardError, setDashboardError] = useState<string | null>(null);
  const [bannerSuccess, setBannerSuccess] = useState<string | null>(null);
  const [bannerError, setBannerError] = useState<string | null>(null);

  // Publish Game Form State (Tab 1)
  const [pubTitle, setPubTitle] = useState('');
  const [pubDescription, setPubDescription] = useState('');
  const [pubVersion, setPubVersion] = useState('');
  const [pubApkFile, setPubApkFile] = useState<File | null>(null);
  const [pubUploading, setPubUploading] = useState(false);
  const [pubProgress, setPubProgress] = useState(0);
  const pubFileInputRef = useRef<HTMLInputElement | null>(null);
  const pubTaskRef = useRef<UploadTaskHandle<{ game: GameRecord; stats: PlatformStats }> | null>(
    null,
  );

  // Edit Game Modal State (Section 13)
  const [editingGame, setEditingGame] = useState<GameRecord | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editVersion, setEditVersion] = useState('');
  const [editApkFile, setEditApkFile] = useState<File | null>(null);
  const [editSaving, setEditSaving] = useState(false);
  const [editProgress, setEditProgress] = useState(0);
  const editFileInputRef = useRef<HTMLInputElement | null>(null);

  // Delete Game Confirmation Dialog State
  const [deletingGame, setDeletingGame] = useState<GameRecord | null>(null);
  const [deletingBusy, setDeletingBusy] = useState(false);

  // Game Approvals Filters & Modals (Tab 2)
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [submissionSearch, setSubmissionSearch] = useState<string>('');
  const [actionBusyId, setActionBusyId] = useState<string | null>(null);

  // Reject Confirmation Modal
  const [rejectModalSubmission, setRejectModalSubmission] = useState<SubmissionRecord | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectBusy, setRejectBusy] = useState(false);

  // Request Changes Modal (Section 5.4)
  const [changesModalSubmission, setChangesModalSubmission] = useState<SubmissionRecord | null>(
    null,
  );
  const [changesMessage, setChangesMessage] = useState('');
  const [changesBusy, setChangesBusy] = useState(false);

  // Optional Gmail Confirmation Modal before sending external email
  const [pendingGmailAction, setPendingGmailAction] = useState<{
    recipientEmail: string;
    subject: string;
    bodyText: string;
    executeBackend: (emailDelivered: boolean) => Promise<void>;
  } | null>(null);

  const fetchDashboard = useCallback(
    async (token: string, filterStatus = statusFilter, search = submissionSearch) => {
      setLoadingDashboard(true);
      setDashboardError(null);
      try {
        const data = await api.adminGetDashboard(token, {
          status: filterStatus,
          search,
        });
        setStats(data.stats);
        setAdminGames(data.games);
        setSubmissions(data.submissions);
        setAuditLogs(data.auditLogs);
      } catch (err) {
        if (err instanceof ApiClientError && err.statusCode === 401) {
          onLockPanel();
          setAuthError('Administrator session expired or was locked. Please re-enter the password.');
        } else {
          setDashboardError(
            err instanceof ApiClientError
              ? err.message
              : 'Failed to load administration dashboard data.',
          );
        }
      } finally {
        setLoadingDashboard(false);
      }
    },
    [statusFilter, submissionSearch, onLockPanel],
  );

  useEffect(() => {
    if (adminToken) {
      fetchDashboard(adminToken, statusFilter, submissionSearch);
    }
  }, [adminToken, statusFilter, submissionSearch, fetchDashboard]);

  // --------------------------------------------------------------------------
  // 3.1 Administrator Password Gate Handler
  // --------------------------------------------------------------------------
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyingPassword) return;
    setAuthError(null);

    if (!passwordInput) {
      setAuthError('Please enter the administrator password.');
      return;
    }

    setVerifyingPassword(true);
    try {
      const res = await api.adminLogin(passwordInput);
      setPasswordInput('');
      onUnlockSuccess(res.adminToken);
    } catch (err) {
      if (err instanceof ApiClientError) {
        setAuthError(err.message);
      } else {
        setAuthError('Unable to verify administrator credentials due to a server error.');
      }
    } finally {
      setVerifyingPassword(false);
    }
  };

  // --------------------------------------------------------------------------
  // 4. Panel Tab 1: Publish Game Handlers
  // --------------------------------------------------------------------------
  const handlePubFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBannerError(null);
    setBannerSuccess(null);
    const file = e.target.files?.[0] || null;
    if (!file) {
      setPubApkFile(null);
      return;
    }
    const check = validateClientApkFile(file, maxApkSizeBytes);
    if (!check.valid) {
      setBannerError(check.error || 'Invalid APK file.');
      setPubApkFile(null);
      if (pubFileInputRef.current) pubFileInputRef.current.value = '';
      return;
    }
    setPubApkFile(file);
  };

  const handlePublishSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken || pubUploading) return;
    setBannerError(null);
    setBannerSuccess(null);

    const cleanTitle = pubTitle.trim();
    const cleanDesc = pubDescription.trim();
    const cleanVer = pubVersion.trim() || '1.0.0';

    if (cleanTitle.length < 2) {
      setBannerError('Game title is required and must be at least 2 characters long.');
      return;
    }
    if (cleanDesc.length < 10) {
      setBannerError('Game description is required and must be at least 10 characters long.');
      return;
    }
    const fileCheck = validateClientApkFile(pubApkFile, maxApkSizeBytes);
    if (!fileCheck.valid || !pubApkFile) {
      setBannerError(fileCheck.error || 'Please select a valid .apk file.');
      return;
    }

    setPubUploading(true);
    setPubProgress(0);

    try {
      const task = uploadBinaryWithProgress<{ game: GameRecord; stats: PlatformStats }>({
        url: '/api/admin/games',
        method: 'POST',
        file: pubApkFile,
        adminToken,
        meta: {
          title: cleanTitle,
          description: cleanDesc,
          version: cleanVer,
        },
        onProgress: (pct) => setPubProgress(pct),
      });
      pubTaskRef.current = task;
      const result = await task.promise;
      setPubTitle('');
      setPubDescription('');
      setPubVersion('');
      setPubApkFile(null);
      if (pubFileInputRef.current) pubFileInputRef.current.value = '';

      setBannerSuccess(
        `Published "${result.game.title}" (v${result.game.version})! It is now live in Apps.`,
      );
      await fetchDashboard(adminToken);
      await onPublicCatalogChanged();
    } catch (err) {
      setBannerError(
        err instanceof ApiClientError ? err.message : 'Failed to publish game. Please retry.',
      );
    } finally {
      setPubUploading(false);
      pubTaskRef.current = null;
    }
  };

  // --------------------------------------------------------------------------
  // 13. Administrator Game Management Handlers
  // --------------------------------------------------------------------------
  const openEditGameModal = (game: GameRecord) => {
    setEditingGame(game);
    setEditTitle(game.title);
    setEditDescription(game.description);
    setEditVersion(game.version);
    setEditApkFile(null);
    setEditProgress(0);
    setBannerError(null);
  };

  const handleSaveEditedGame = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken || !editingGame || editSaving) return;
    setBannerError(null);
    setBannerSuccess(null);

    if (editApkFile) {
      const check = validateClientApkFile(editApkFile, maxApkSizeBytes);
      if (!check.valid) {
        setBannerError(check.error || 'Invalid replacement APK file.');
        return;
      }
    }

    setEditSaving(true);
    setEditProgress(0);
    try {
      const task = uploadBinaryWithProgress<{ game: GameRecord; stats: PlatformStats }>({
        url: `/api/admin/games/${encodeURIComponent(editingGame.gameId)}`,
        method: 'PUT',
        file: editApkFile,
        adminToken,
        meta: {
          title: editTitle.trim(),
          description: editDescription.trim(),
          version: editVersion.trim() || editingGame.version,
        },
        onProgress: (pct) => setEditProgress(pct),
      });
      const res = await task.promise;
      setBannerSuccess(`Updated "${res.game.title}" (v${res.game.version}).`);
      setEditingGame(null);
      await fetchDashboard(adminToken);
      await onPublicCatalogChanged();
    } catch (err) {
      setBannerError(err instanceof ApiClientError ? err.message : 'Failed to update game.');
    } finally {
      setEditSaving(false);
    }
  };

  const handleToggleGamePublication = async (game: GameRecord) => {
    if (!adminToken) return;
    setBannerError(null);
    setBannerSuccess(null);
    const nextStatus = game.publicationStatus === 'Published' ? 'Unpublished' : 'Published';
    try {
      await api.adminSetGameStatus(adminToken, game.gameId, nextStatus);
      setBannerSuccess(
        nextStatus === 'Published'
          ? `Republished "${game.title}". It is now available in Apps.`
          : `Unpublished "${game.title}". New downloads are now disabled.`,
      );
      await fetchDashboard(adminToken);
      await onPublicCatalogChanged();
    } catch (err) {
      setBannerError(
        err instanceof ApiClientError ? err.message : 'Failed to change publication status.',
      );
    }
  };

  const handleConfirmDeleteGame = async () => {
    if (!adminToken || !deletingGame || deletingBusy) return;
    setDeletingBusy(true);
    setBannerError(null);
    setBannerSuccess(null);
    try {
      await api.adminDeleteGame(adminToken, deletingGame.gameId);
      setBannerSuccess(`Removed game "${deletingGame.title}" from the platform.`);
      setDeletingGame(null);
      await fetchDashboard(adminToken);
      await onPublicCatalogChanged();
    } catch (err) {
      setBannerError(err instanceof ApiClientError ? err.message : 'Failed to remove game.');
    } finally {
      setDeletingBusy(false);
    }
  };

  // --------------------------------------------------------------------------
  // 5. Panel Tab 2: Game Approvals, Downloads, Rejections & Correction Requests
  // --------------------------------------------------------------------------
  const handleDownloadSubmissionApk = async (sub: SubmissionRecord) => {
    if (!adminToken) return;
    setBannerError(null);
    try {
      const ticket = await api.adminRequestSubmissionDownload(adminToken, sub.submissionId);
      const link = document.createElement('a');
      link.href = ticket.downloadUrl;
      link.download = ticket.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      setBannerError(
        err instanceof ApiClientError ? err.message : 'Failed to download submission APK.',
      );
    }
  };

  const handleApproveSubmission = async (sub: SubmissionRecord) => {
    if (!adminToken || actionBusyId === sub.submissionId) return;
    setBannerError(null);
    setBannerSuccess(null);

    const executeApproval = async (emailDelivered: boolean) => {
      setActionBusyId(sub.submissionId);
      try {
        const res = await api.adminApproveSubmission(adminToken, sub.submissionId, emailDelivered);
        setBannerSuccess(
          `Approved "${res.game.title}"! It is now published in Apps. (${
            emailDelivered
              ? 'Notification delivered via Gmail and internal notification system'
              : 'Notification sent via internal notification system'
          })`,
        );
        await fetchDashboard(adminToken);
        await onPublicCatalogChanged();
      } catch (err) {
        setBannerError(
          err instanceof ApiClientError ? err.message : 'Failed to approve submission.',
        );
      } finally {
        setActionBusyId(null);
      }
    };

    const googleToken = await getAccessToken();
    if (googleToken) {
      const subject = `APK Forge: Your game "${sub.title}" has been Approved!`;
      const bodyText = `Hello,\n\nYour submitted Android APK game "${sub.title}" (v${sub.version}) has been reviewed and approved by the administrator.\nIt is now published in the public Apps library.\n\n— APK Forge Administration`;
      setPendingGmailAction({
        recipientEmail: sub.submittedByEmail,
        subject,
        bodyText,
        executeBackend: executeApproval,
      });
    } else {
      await executeApproval(false);
    }
  };

  const handleConfirmRejectSubmission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken || !rejectModalSubmission || rejectBusy) return;
    setBannerError(null);
    setBannerSuccess(null);

    const targetSub = rejectModalSubmission;
    const reasonText = rejectReason.trim();

    const executeRejection = async (emailDelivered: boolean) => {
      setRejectBusy(true);
      try {
        await api.adminRejectSubmission(
          adminToken,
          targetSub.submissionId,
          reasonText,
          emailDelivered,
        );
        setBannerSuccess(
          `Rejected submission "${targetSub.title}". (${
            emailDelivered
              ? 'Notification delivered via Gmail and internal notification system'
              : 'Notification sent via internal notification system'
          })`,
        );
        setRejectModalSubmission(null);
        setRejectReason('');
        await fetchDashboard(adminToken);
      } catch (err) {
        setBannerError(
          err instanceof ApiClientError ? err.message : 'Failed to reject submission.',
        );
      } finally {
        setRejectBusy(false);
      }
    };

    const googleToken = await getAccessToken();
    if (googleToken) {
      const subject = `APK Forge: Update regarding your submission "${targetSub.title}"`;
      const bodyText = reasonText
        ? `Hello,\n\nYour submission "${targetSub.title}" (v${targetSub.version}) was not approved.\nReason: ${reasonText}\n\n— APK Forge Administration`
        : `Hello,\n\nYour submission "${targetSub.title}" (v${targetSub.version}) was not approved by the administrator.\n\n— APK Forge Administration`;
      setRejectModalSubmission(null);
      setPendingGmailAction({
        recipientEmail: targetSub.submittedByEmail,
        subject,
        bodyText,
        executeBackend: executeRejection,
      });
    } else {
      await executeRejection(false);
    }
  };

  const handleSendChangesRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken || !changesModalSubmission || changesBusy) return;
    setBannerError(null);
    setBannerSuccess(null);

    const cleanMsg = changesMessage.trim();
    if (!cleanMsg) {
      setBannerError('Please enter correction instructions before sending.');
      return;
    }

    const targetSub = changesModalSubmission;
    const formattedBody = cleanMsg.startsWith('Your game has the following issues')
      ? cleanMsg
      : `Your game has the following issues that need to be corrected: ${cleanMsg}. Please fix these issues and submit the updated APK for review.`;

    const executeRequestChanges = async (emailDelivered: boolean) => {
      setChangesBusy(true);
      try {
        await api.adminRequestChanges(
          adminToken,
          targetSub.submissionId,
          cleanMsg,
          emailDelivered,
        );
        setBannerSuccess(
          `Correction request sent for "${targetSub.title}". Status updated to Needs Changes. (${
            emailDelivered
              ? 'Delivered via Gmail and internal notification system'
              : 'Sent through the website’s internal notification system'
          })`,
        );
        setChangesModalSubmission(null);
        setChangesMessage('');
        await fetchDashboard(adminToken);
      } catch (err) {
        setBannerError(
          err instanceof ApiClientError ? err.message : 'Failed to send correction request.',
        );
      } finally {
        setChangesBusy(false);
      }
    };

    const googleToken = await getAccessToken();
    if (googleToken) {
      const subject = `APK Forge: Action Required — Corrections Requested for "${targetSub.title}"`;
      setChangesModalSubmission(null);
      setPendingGmailAction({
        recipientEmail: targetSub.submittedByEmail,
        subject,
        bodyText: formattedBody,
        executeBackend: executeRequestChanges,
      });
    } else {
      await executeRequestChanges(false);
    }
  };

  // ============================================================================
  // RENDER: PASSWORD SCREEN WHEN PANEL IS LOCKED
  // ============================================================================
  if (!adminToken) {
    return (
      <div
        data-testid="admin-password-screen"
        className="max-w-md mx-auto my-10 rounded-xl border border-slate-200 bg-white p-6 sm:p-8 shadow-xs"
      >
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
          <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-blue-700">APK Forge Security Gate</div>
            <h1 className="text-lg font-bold text-slate-900">Administrator Access</h1>
          </div>
        </div>

        <p className="mt-4 text-xs text-slate-600 leading-relaxed">
          Enter the administrator password to unlock Panel. For security, your session locks
          automatically whenever you navigate away from Panel, refresh the browser, or background
          the page.
        </p>

        {authError && (
          <div
            role="alert"
            data-testid="admin-auth-error"
            className="mt-4 flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs text-red-800"
          >
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <span>{authError}</span>
          </div>
        )}

        <form onSubmit={handleAdminLogin} className="mt-5 space-y-4">
          <div>
            <label
              htmlFor="admin-password-input"
              className="block text-xs font-semibold text-slate-700 mb-1.5"
            >
              Administrator Password
            </label>
            <div className="relative">
              <input
                id="admin-password-input"
                type={showPassword ? 'text' : 'password'}
                required
                autoFocus
                autoComplete="off"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter administrator password"
                className="w-full pl-3.5 pr-10 py-2.5 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                aria-label={
                  showPassword ? 'Hide administrator password' : 'Show administrator password'
                }
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={verifyingPassword}
            className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
          >
            {verifyingPassword ? 'Verifying Credentials...' : 'Login'}
          </button>
        </form>
      </div>
    );
  }

  // ============================================================================
  // RENDER: UNLOCKED ADMINISTRATION DASHBOARD
  // ============================================================================
  return (
    <div data-testid="admin-dashboard" className="space-y-8">
      {/* Top Bar of Panel Dashboard */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Administration Panel
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Authenticated administrator session active for this visit. Leaving Panel locks access
            immediately.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => fetchDashboard(adminToken)}
            disabled={loadingDashboard}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingDashboard ? 'animate-spin' : ''}`} />
            Refresh
          </button>

          <button
            type="button"
            onClick={onLockPanel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 transition-colors whitespace-nowrap cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Lock &amp; Exit Panel
          </button>
        </div>
      </div>

      {/* Real Database Statistics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">Published Games</div>
          <div
            data-testid="stat-published-games"
            className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1"
          >
            {stats.totalPublishedGames}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">Pending Submissions</div>
          <div
            data-testid="stat-pending-submissions"
            className="text-2xl font-bold font-mono tabular-nums text-amber-700 mt-1"
          >
            {stats.pendingSubmissions}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">Awaiting Corrections</div>
          <div
            data-testid="stat-needs-changes"
            className="text-2xl font-bold font-mono tabular-nums text-blue-700 mt-1"
          >
            {stats.needsChangesSubmissions}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">Approved Submissions</div>
          <div
            data-testid="stat-approved-submissions"
            className="text-2xl font-bold font-mono tabular-nums text-emerald-700 mt-1"
          >
            {stats.approvedSubmissions}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-medium text-slate-500">Rejected Submissions</div>
          <div
            data-testid="stat-rejected-submissions"
            className="text-2xl font-bold font-mono tabular-nums text-red-700 mt-1"
          >
            {stats.rejectedSubmissions}
          </div>
        </div>
      </div>

      {/* Feedback Banners */}
      {bannerSuccess && (
        <div
          data-testid="panel-success-banner"
          className="flex items-start justify-between gap-3 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-xs text-emerald-900"
        >
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>{bannerSuccess}</span>
          </div>
          <button
            type="button"
            onClick={() => setBannerSuccess(null)}
            aria-label="Dismiss message"
            className="text-emerald-700 hover:text-emerald-950"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {(bannerError || dashboardError) && (
        <div
          role="alert"
          className="flex items-start justify-between gap-3 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-xs text-red-800"
        >
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <span>{bannerError || dashboardError}</span>
          </div>
          <button
            type="button"
            onClick={() => {
              setBannerError(null);
              setDashboardError(null);
            }}
            aria-label="Dismiss error"
            className="text-red-700 hover:text-red-950"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Two Primary Internal Panel Tabs: 1. Publish Game | 2. Game Approvals */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          type="button"
          onClick={() => setActiveTab('publish')}
          className={`px-5 py-3 text-sm font-semibold border-b-2 -mb-px transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'publish'
              ? 'border-blue-700 text-blue-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          Publish Game
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('approvals')}
          className={`px-5 py-3 text-sm font-semibold border-b-2 -mb-px transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'approvals'
              ? 'border-blue-700 text-blue-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          Game Approvals ({stats.pendingSubmissions} Pending)
        </button>
      </div>

      {/* ==================================================================== */}
      {/* TAB 1: PUBLISH GAME & MANAGE PUBLISHED GAMES                         */}
      {/* ==================================================================== */}
      {activeTab === 'publish' && (
        <div className="space-y-10">
          {/* Direct Administrator Publishing Form */}
          <form
            onSubmit={handlePublishSubmit}
            className="rounded-xl border border-slate-200 bg-white p-6 sm:p-8 space-y-6"
          >
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Publish New APK Game Directly</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Games published here are validated, saved to permanent object storage, and appear
                  immediately in Apps.
                </p>
              </div>
              <GameIcon title={pubTitle || 'Admin Game'} size="md" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label
                  htmlFor="admin-pub-title"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Game Title <span className="text-red-600">*</span>
                </label>
                <input
                  id="admin-pub-title"
                  type="text"
                  required
                  maxLength={120}
                  value={pubTitle}
                  onChange={(e) => setPubTitle(e.target.value)}
                  placeholder="e.g. Aether Drift Horizon"
                  className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label
                  htmlFor="admin-pub-version"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Version Number <span className="text-slate-400 font-normal">(optional)</span>
                </label>
                <input
                  id="admin-pub-version"
                  type="text"
                  maxLength={40}
                  value={pubVersion}
                  onChange={(e) => setPubVersion(e.target.value)}
                  placeholder="1.0.0"
                  className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="admin-pub-description"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Game Description <span className="text-red-600">*</span>
              </label>
              <textarea
                id="admin-pub-description"
                rows={3}
                required
                maxLength={5000}
                value={pubDescription}
                onChange={(e) => setPubDescription(e.target.value)}
                placeholder="Write a clear description of the game, features, and controls..."
                className="w-full px-3.5 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="admin-pub-apk"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                APK File (<code>.apk</code> only) <span className="text-red-600">*</span>
              </label>
              <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-4">
                <input
                  ref={pubFileInputRef}
                  id="admin-pub-apk"
                  type="file"
                  accept=".apk"
                  onChange={handlePubFileChange}
                  className="block w-full text-xs text-slate-700 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-900 file:text-white hover:file:bg-slate-800 cursor-pointer"
                />

                {pubApkFile && (
                  <div className="mt-3 flex items-center justify-between rounded-lg bg-white border border-slate-200 px-3.5 py-2">
                    <div className="flex items-center gap-2 text-xs font-mono text-slate-800">
                      <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{pubApkFile.name}</span>
                      <span>·</span>
                      <span>{formatBytes(pubApkFile.size)}</span>
                    </div>
                    {!pubUploading && (
                      <button
                        type="button"
                        onClick={() => {
                          setPubApkFile(null);
                          if (pubFileInputRef.current) pubFileInputRef.current.value = '';
                        }}
                        className="text-xs font-medium text-slate-500 hover:text-red-600"
                      >
                        Cancel Selection
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            {pubUploading && (
              <div className="rounded-lg bg-blue-50 border border-blue-200 p-4 space-y-2">
                <div className="flex justify-between text-xs font-mono text-blue-900 tabular-nums">
                  <span>Uploading and verifying APK package...</span>
                  <span>{pubProgress}%</span>
                </div>
                <div className="w-full h-2 bg-blue-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-700 transition-transform duration-150 origin-left"
                    style={{ transform: `scaleX(${pubProgress / 100})` }}
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => pubTaskRef.current?.abort()}
                    className="text-xs font-semibold text-red-700 hover:underline"
                  >
                    Cancel Upload
                  </button>
                </div>
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={pubUploading}
                className="inline-flex items-center gap-2 py-2.5 px-5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                {pubUploading ? 'Publishing APK...' : 'Publish Game Now'}
              </button>
            </div>
          </form>

          {/* Section 13: Administrator Game Management */}
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Manage Published &amp; Unpublished Games ({adminGames.length})
              </h2>
              <p className="text-xs text-slate-500">
                Edit game details, replace APK binaries safely, unpublish/republish, or remove
                games.
              </p>
            </div>

            {adminGames.length === 0 ? (
              <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-500">
                No games have been published yet.
              </div>
            ) : (
              <div className="space-y-3">
                {adminGames.map((game) => (
                  <div
                    key={game.gameId}
                    className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3.5 min-w-0">
                      <GameIcon title={game.title} size="md" />
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="text-sm font-bold text-slate-900">{game.title}</h3>
                          <span className="text-xs font-mono text-slate-500">v{game.version}</span>
                          <span aria-hidden="true" className="text-slate-300">
                            ·
                          </span>
                          <span
                            className={`text-xs font-semibold ${
                              game.publicationStatus === 'Published'
                                ? 'text-emerald-700'
                                : 'text-amber-700'
                            }`}
                          >
                            {game.publicationStatus}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                          {game.description}
                        </p>
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-mono text-slate-400 tabular-nums mt-1.5">
                          <span>{formatBytes(game.fileSizeBytes)}</span>
                          <span>·</span>
                          <span>SHA-256: {game.sha256.slice(0, 12)}...</span>
                          <span>·</span>
                          <span>Published {formatDateTime(game.publishedAt)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => openEditGameModal(game)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        Edit / Replace APK
                      </button>

                      <button
                        type="button"
                        onClick={() => handleToggleGamePublication(game)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
                      >
                        {game.publicationStatus === 'Published' ? (
                          <>
                            <UnpublishIcon className="w-3.5 h-3.5" />
                            Unpublish
                          </>
                        ) : (
                          <>
                            <Globe className="w-3.5 h-3.5" />
                            Republish
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => setDeletingGame(game)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors whitespace-nowrap"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Administrator Audit Log */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-slate-600" />
              <h2 className="text-base font-bold text-slate-900">
                Administrator Audit Log ({auditLogs.length})
              </h2>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100 max-h-64 overflow-y-auto">
              {auditLogs.length === 0 ? (
                <div className="p-4 text-xs text-slate-500">No audit entries recorded yet.</div>
              ) : (
                auditLogs.map((log) => (
                  <div
                    key={log.logId}
                    className="px-4 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2"
                  >
                    <div>
                      <span className="font-mono font-semibold text-slate-800">{log.action}</span>
                      <span className="mx-1.5 text-slate-300">·</span>
                      <span className="font-medium text-slate-900">{log.targetTitle}</span>
                      <span className="mx-1.5 text-slate-300">·</span>
                      <span className="text-slate-600">{log.details}</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                      {formatDateTime(log.timestamp)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 2: GAME APPROVALS                                                */}
      {/* ==================================================================== */}
      {activeTab === 'approvals' && (
        <div className="space-y-6">
          {/* Filter & Search Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {['All', 'Pending', 'Needs Changes', 'Approved', 'Rejected'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    statusFilter === st
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                aria-label="Search submissions by title or submitter email"
                value={submissionSearch}
                onChange={(e) => setSubmissionSearch(e.target.value)}
                placeholder="Search title or submitter email..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          {submissions.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center space-y-1">
              <div className="text-sm font-bold text-slate-900">
                No submissions match the current filter
              </div>
              <p className="text-xs text-slate-500">
                When registered users submit APK packages via Add Apps, they will appear here for
                inspection and approval.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {submissions.map((sub) => {
                const isBusy = actionBusyId === sub.submissionId;
                return (
                  <article
                    key={sub.submissionId}
                    data-testid={`submission-card-${sub.submissionId}`}
                    className="rounded-xl border border-slate-200 bg-white p-6 space-y-4"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="flex items-start gap-3.5">
                        <GameIcon title={sub.title} size="md" />
                        <div>
                          <h3 className="text-base font-bold text-slate-900">{sub.title}</h3>
                          <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 font-mono tabular-nums mt-1">
                            <span>Submitter: {sub.submittedByEmail}</span>
                            <span aria-hidden="true">·</span>
                            <span>v{sub.version}</span>
                            <span aria-hidden="true">·</span>
                            <span>{formatBytes(sub.fileSizeBytes)}</span>
                            <span aria-hidden="true">·</span>
                            <span>Submitted {formatDateTime(sub.submittedAt)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-xs font-semibold">
                        {sub.reviewStatus === 'Pending' && (
                          <span className="text-amber-700">Status: Pending</span>
                        )}
                        {sub.reviewStatus === 'Needs Changes' && (
                          <span className="text-blue-700">Status: Needs Changes</span>
                        )}
                        {sub.reviewStatus === 'Approved' && (
                          <span className="text-emerald-700">Status: Approved</span>
                        )}
                        {sub.reviewStatus === 'Rejected' && (
                          <span className="text-red-700">Status: Rejected</span>
                        )}
                      </div>
                    </div>

                    <p className="text-sm text-slate-700 leading-relaxed">{sub.description}</p>

                    <div className="rounded-lg bg-slate-50 border border-slate-200 px-3.5 py-2 text-xs font-mono text-slate-600 flex flex-wrap items-center gap-x-4 gap-y-1">
                      <span>File: {sub.apkInspection?.fileName || 'package.apk'}</span>
                      <span>SHA-256: {sub.sha256.slice(0, 16)}...</span>
                      <span>
                        Manifest:{' '}
                        {sub.apkInspection?.hasAndroidManifest ? 'Verified' : 'Unverified'}
                      </span>
                      <span>Entries: {sub.apkInspection?.entryCount || 0}</span>
                    </div>

                    {sub.latestCorrectionMessage && (
                      <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900">
                        <span className="font-bold">Latest Correction Message Sent: </span>
                        {sub.latestCorrectionMessage}
                      </div>
                    )}

                    {sub.rejectionReason && (
                      <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-xs text-red-900">
                        <span className="font-bold">Rejection Reason: </span>
                        {sub.rejectionReason}
                      </div>
                    )}

                    {/* Review Actions */}
                    <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => handleDownloadSubmissionApk(sub)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download APK for Review
                      </button>

                      <div className="flex flex-wrap items-center gap-2">
                        {sub.reviewStatus !== 'Approved' && (
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => handleApproveSubmission(sub)}
                            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {isBusy ? 'Approving...' : 'Approve'}
                          </button>
                        )}

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => {
                            setChangesModalSubmission(sub);
                            setChangesMessage('');
                          }}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                        >
                          <MessageSquareWarning className="w-3.5 h-3.5" />
                          Request Changes
                        </button>

                        {sub.reviewStatus !== 'Rejected' && (
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => {
                              setRejectModalSubmission(sub);
                              setRejectReason('');
                            }}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            Reject
                          </button>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL: REQUEST CHANGES & SEND MESSAGE (SECTION 5.4)                  */}
      {/* ==================================================================== */}
      {changesModalSubmission && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="request-changes-title"
        >
          <div className="w-full max-w-lg rounded-xl bg-white border border-slate-200 p-6 shadow-xl space-y-4">
            <h3 id="request-changes-title" className="text-base font-bold text-slate-900">
              Request Corrections &amp; Send Message
            </h3>

            <div className="rounded-lg bg-slate-50 border border-slate-200 p-3.5 text-xs space-y-1">
              <div>
                <span className="font-semibold text-slate-700">Game Title: </span>
                <span className="text-slate-900 font-bold">{changesModalSubmission.title}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-700">Submitter Email: </span>
                <span className="text-slate-900 font-mono">
                  {changesModalSubmission.submittedByEmail}
                </span>
              </div>
            </div>

            <form onSubmit={handleSendChangesRequest} className="space-y-4">
              <div>
                <label
                  htmlFor="correction-message-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Required Correction Instructions <span className="text-red-600">*</span>
                </label>
                <textarea
                  id="correction-message-input"
                  rows={4}
                  required
                  value={changesMessage}
                  onChange={(e) => setChangesMessage(e.target.value)}
                  placeholder="Describe the issues that need to be fixed before the APK can be approved..."
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  The submitter will receive: &ldquo;Your game has the following issues that need to
                  be corrected: [your message]. Please fix these issues and submit the updated APK
                  for review.&rdquo;
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setChangesModalSubmission(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={changesBusy}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg"
                >
                  {changesBusy ? 'Sending Message...' : 'Send Message'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL: REJECT SUBMISSION CONFIRMATION (SECTION 5.3)                  */}
      {/* ==================================================================== */}
      {rejectModalSubmission && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="reject-submission-title"
        >
          <div className="w-full max-w-md rounded-xl bg-white border border-slate-200 p-6 shadow-xl space-y-4">
            <h3 id="reject-submission-title" className="text-base font-bold text-slate-900">
              Confirm Rejecting &ldquo;{rejectModalSubmission.title}&rdquo;?
            </h3>
            <p className="text-xs text-slate-600">
              Rejected submissions are not displayed in Apps. The review record is preserved and the
              submitter ({rejectModalSubmission.submittedByEmail}) will be notified.
            </p>

            <form onSubmit={handleConfirmRejectSubmission} className="space-y-4">
              <div>
                <label
                  htmlFor="reject-reason-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Rejection Explanation <span className="text-slate-400 font-normal">(optional)</span>
                </label>
                <textarea
                  id="reject-reason-input"
                  rows={3}
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="Optional explanation for why the submission was rejected..."
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRejectModalSubmission(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={rejectBusy}
                  className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 rounded-lg"
                >
                  {rejectBusy ? 'Rejecting...' : 'Confirm Reject'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL: EDIT PUBLISHED GAME / REPLACE APK (SECTION 13)                */}
      {/* ==================================================================== */}
      {editingGame && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-game-title"
        >
          <div className="w-full max-w-lg rounded-xl bg-white border border-slate-200 p-6 shadow-xl space-y-4">
            <h3 id="edit-game-title" className="text-base font-bold text-slate-900">
              Edit Game: {editingGame.title}
            </h3>

            <form onSubmit={handleSaveEditedGame} className="space-y-4">
              <div>
                <label
                  htmlFor="edit-game-title-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Game Title
                </label>
                <input
                  id="edit-game-title-input"
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900"
                />
              </div>

              <div>
                <label
                  htmlFor="edit-game-version-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Version Number
                </label>
                <input
                  id="edit-game-version-input"
                  type="text"
                  value={editVersion}
                  onChange={(e) => setEditVersion(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 text-slate-900"
                />
              </div>

              <div>
                <label
                  htmlFor="edit-game-desc-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Description
                </label>
                <textarea
                  id="edit-game-desc-input"
                  rows={3}
                  required
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-900"
                />
              </div>

              <div>
                <label
                  htmlFor="edit-game-apk-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Replace APK File <span className="text-slate-400 font-normal">(optional)</span>
                </label>
                <input
                  ref={editFileInputRef}
                  id="edit-game-apk-input"
                  type="file"
                  accept=".apk"
                  onChange={(e) => setEditApkFile(e.target.files?.[0] || null)}
                  className="w-full text-xs text-slate-700 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-slate-100 file:text-slate-800"
                />
              </div>

              {editSaving && editApkFile && (
                <div className="text-xs font-mono text-blue-800">
                  Uploading replacement APK... {editProgress}%
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingGame(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={editSaving}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
                >
                  {editSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL: REMOVE GAME CONFIRMATION (SECTION 13)                         */}
      {/* ==================================================================== */}
      {deletingGame && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-game-title"
        >
          <div className="w-full max-w-md rounded-xl bg-white border border-slate-200 p-6 shadow-xl space-y-4">
            <h3 id="delete-game-title" className="text-base font-bold text-slate-900">
              Remove &ldquo;{deletingGame.title}&rdquo;?
            </h3>
            <p className="text-xs text-slate-600">
              This will immediately unpublish the game from Apps and remove its published catalog
              record.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingGame(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deletingBusy}
                onClick={handleConfirmDeleteGame}
                className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg"
              >
                {deletingBusy ? 'Removing...' : 'Confirm Remove'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL: GMAIL CONFIRMATION FOR OUTBOUND EMAILS                        */}
      {/* ==================================================================== */}
      {pendingGmailAction && (
        <GmailConfirmModal
          isOpen={true}
          recipientEmail={pendingGmailAction.recipientEmail}
          subject={pendingGmailAction.subject}
          bodyText={pendingGmailAction.bodyText}
          onConfirmSend={async () => {
            const action = pendingGmailAction;
            setPendingGmailAction(null);
            let sentOk = false;
            try {
              await sendGmailMessage({
                to: action.recipientEmail,
                subject: action.subject,
                bodyText: action.bodyText,
              });
              sentOk = true;
            } catch (err) {
              setBannerError(
                err instanceof Error
                  ? `Gmail delivery failed (${err.message}); falling back to internal notification.`
                  : 'Gmail delivery failed; falling back to internal notification.',
              );
            }
            await action.executeBackend(sentOk);
          }}
          onCancelSkipEmail={async () => {
            const action = pendingGmailAction;
            setPendingGmailAction(null);
            await action.executeBackend(false);
          }}
        />
      )}
    </div>
  );
};
