import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Bell, ChevronDown, FolderKanban, LogOut, MailCheck, User as UserIcon } from 'lucide-react';
import type {
  GameRecord,
  NotificationRecord,
  SubmissionRecord,
  UserRecord,
} from './types/models';
import {
  api,
  ApiClientError,
  getStoredUserToken,
  setStoredUserToken,
} from './services/apiClient';
import { initAuth, logoutGoogle } from './services/gmailAuth';
import { AppsSection } from './components/AppsSection';
import { AddAppsSection } from './components/AddAppsSection';
import { PanelSection } from './components/PanelSection';
import { AuthModal, type AuthModalMode } from './components/AuthModal';
import { MySubmissionsModal, NotificationsModal } from './components/AccountModals';

type MainSection = 'panel' | 'apps' | 'add-apps';

function resolveSectionFromPathname(pathname: string): MainSection {
  const clean = pathname.toLowerCase().replace(/\/+$/, '');
  if (clean === '/panel') return 'panel';
  if (clean === '/add-apps') return 'add-apps';
  return 'apps';
}

function pathForSection(section: MainSection): string {
  if (section === 'panel') return '/panel';
  if (section === 'add-apps') return '/add-apps';
  return '/apps';
}

export default function App() {
  // Primary Route State
  const [activeSection, setActiveSection] = useState<MainSection>(() =>
    resolveSectionFromPathname(window.location.pathname),
  );

  // Administrator Session Token (Strictly in-memory for current uninterrupted Panel visit only)
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const adminTokenRef = useRef<string | null>(null);

  // Platform Configuration & Public Games Catalog
  const [maxApkSizeBytes, setMaxApkSizeBytes] = useState<number>(150 * 1024 * 1024);
  const [games, setGames] = useState<GameRecord[]>([]);
  const [loadingGames, setLoadingGames] = useState<boolean>(true);
  const [gamesError, setGamesError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Authenticated User State
  const [currentUser, setCurrentUser] = useState<UserRecord | null>(null);
  const [pendingVerificationToken, setPendingVerificationToken] = useState<string | null>(null);
  const [gmailConnected, setGmailConnected] = useState<boolean>(false);

  // User Submissions & Notifications State
  const [mySubmissions, setMySubmissions] = useState<SubmissionRecord[]>([]);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  // Add Apps Form Draft Persistence across Sign-In
  const [draftForm, setDraftForm] = useState({
    title: '',
    description: '',
    version: '',
  });

  // Modals & Account Menu State
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode>('login');
  const [authContextMessage, setAuthContextMessage] = useState<string | null>(null);
  const [mySubmissionsOpen, setMySubmissionsOpen] = useState<boolean>(false);
  const [notificationsOpen, setNotificationsOpen] = useState<boolean>(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState<boolean>(false);
  const accountMenuRef = useRef<HTMLDivElement | null>(null);

  // Deferred Download State (when unauthenticated visitor clicks Download APK)
  const [pendingDownloadGameId, setPendingDownloadGameId] = useState<string | null>(null);
  const [downloadingGameId, setDownloadingGameId] = useState<string | null>(null);
  const [downloadStatusError, setDownloadStatusError] = useState<string | null>(null);

  // Keep adminTokenRef synchronized
  useEffect(() => {
    adminTokenRef.current = adminToken;
  }, [adminToken]);

  // --------------------------------------------------------------------------
  // Strict Panel Locking & Backend Session Invalidation (Section 3.2)
  // --------------------------------------------------------------------------
  const lockPanelImmediately = useCallback(() => {
    const tokenToInvalidate = adminTokenRef.current;
    adminTokenRef.current = null;
    setAdminToken(null);
    if (tokenToInvalidate) {
      try {
        if (navigator.sendBeacon) {
          const blob = new Blob([JSON.stringify({ adminToken: tokenToInvalidate })], {
            type: 'application/json',
          });
          navigator.sendBeacon('/api/admin/lock', blob);
        }
      } catch {
        // fallback to fetch below
      }
      api.adminLock(tokenToInvalidate);
    }
  }, []);

  // Navigate between primary sections and immediately lock Panel when leaving it
  const navigateToSection = useCallback(
    (nextSection: MainSection) => {
      if (activeSection === 'panel' && nextSection !== 'panel') {
        lockPanelImmediately();
      } else if (nextSection === 'panel' && activeSection !== 'panel') {
        // Always require fresh password entry when entering Panel
        lockPanelImmediately();
      }

      setActiveSection(nextSection);
      setDownloadStatusError(null);
      const targetPath = pathForSection(nextSection);
      if (window.location.pathname !== targetPath) {
        window.history.pushState({ section: nextSection }, '', targetPath);
      }
    },
    [activeSection, lockPanelImmediately],
  );

  // Lock Panel on browser Back/Forward navigation, page unload, or backgrounding
  useEffect(() => {
    const handlePopState = () => {
      lockPanelImmediately();
      setActiveSection(resolveSectionFromPathname(window.location.pathname));
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && adminTokenRef.current) {
        lockPanelImmediately();
      }
    };

    const handlePageHide = () => {
      if (adminTokenRef.current) {
        lockPanelImmediately();
      }
    };

    window.addEventListener('popstate', handlePopState);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pagehide', handlePageHide);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pagehide', handlePageHide);
    };
  }, [lockPanelImmediately]);

  // Close account dropdown when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (accountMenuRef.current && !accountMenuRef.current.contains(e.target as Node)) {
        setAccountMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // --------------------------------------------------------------------------
  // Data Fetching: Public Games, Health, and User Account Data
  // --------------------------------------------------------------------------
  const fetchPublicGames = useCallback(async (search = searchQuery) => {
    setLoadingGames(true);
    setGamesError(null);
    try {
      const res = await api.listGames(search);
      setGames(res.games);
    } catch (err) {
      setGamesError(
        err instanceof ApiClientError
          ? err.message
          : 'Unable to load published games from the server.',
      );
    } finally {
      setLoadingGames(false);
    }
  }, [searchQuery]);

  const fetchUserAccountData = useCallback(async () => {
    const token = getStoredUserToken();
    if (!token) return;
    try {
      const [subsRes, notifsRes] = await Promise.all([
        api.listMySubmissions(),
        api.listNotifications(),
      ]);
      setMySubmissions(subsRes.submissions);
      setNotifications(notifsRes.notifications);
      setUnreadCount(notifsRes.unreadCount);
    } catch {
      // ignore if session expired
    }
  }, []);

  // Initial Bootstrap
  useEffect(() => {
    api
      .getHealth()
      .then((h) => {
        if (h.maxApkSizeBytes) setMaxApkSizeBytes(h.maxApkSizeBytes);
      })
      .catch(() => {});

    const storedToken = getStoredUserToken();
    if (storedToken) {
      api
        .getMe()
        .then((res) => {
          setCurrentUser(res.user);
          setGmailConnected(Boolean(res.user.gmailConnected));
          fetchUserAccountData();
        })
        .catch(() => {
          setStoredUserToken(null);
          setCurrentUser(null);
        });
    }

    const unsubscribeFirebase = initAuth(
      (_fbUser, _accessToken) => {
        setGmailConnected(true);
      },
      () => {
        setGmailConnected(false);
      },
    );

    return () => {
      unsubscribeFirebase();
    };
  }, [fetchUserAccountData]);

  // Reload public games when search query changes
  useEffect(() => {
    fetchPublicGames(searchQuery);
  }, [searchQuery, fetchPublicGames]);

  // Poll user notifications periodically while signed in for realtime review updates
  useEffect(() => {
    if (!currentUser) return;
    const interval = window.setInterval(() => {
      fetchUserAccountData();
    }, 10000);
    return () => window.clearInterval(interval);
  }, [currentUser, fetchUserAccountData]);

  // --------------------------------------------------------------------------
  // Authenticated APK Download Flow (Section 6.2)
  // --------------------------------------------------------------------------
  const executeAuthorizedDownload = useCallback(
    async (gameId: string) => {
      setDownloadingGameId(gameId);
      setDownloadStatusError(null);
      try {
        // Recheck that the game is still published on the backend & obtain short-lived download token
        const ticket = await api.requestGameDownloadToken(gameId);
        const link = document.createElement('a');
        link.href = ticket.downloadUrl;
        link.download = ticket.fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (err) {
        if (err instanceof ApiClientError && err.code === 'EMAIL_NOT_VERIFIED') {
          setPendingDownloadGameId(gameId);
          setAuthModalMode('verify');
          setAuthContextMessage(
            'Please verify your email address to start your APK download.',
          );
          setAuthModalOpen(true);
        } else if (err instanceof ApiClientError && err.statusCode === 401) {
          setPendingDownloadGameId(gameId);
          setAuthModalMode('login');
          setAuthContextMessage('Please sign in with your email account to download this APK.');
          setAuthModalOpen(true);
        } else {
          setDownloadStatusError(
            err instanceof ApiClientError
              ? err.message
              : 'This game download is no longer available.',
          );
          await fetchPublicGames(searchQuery);
        }
      } finally {
        setDownloadingGameId(null);
      }
    },
    [fetchPublicGames, searchQuery],
  );

  const handleDownloadGameClick = (game: GameRecord) => {
    setDownloadStatusError(null);
    if (!currentUser) {
      setPendingDownloadGameId(game.gameId);
      setAuthModalMode('login');
      setAuthContextMessage(
        `Sign in with a verified email account to download "${game.title}" (${game.version ? `v${game.version}` : 'APK'}).`,
      );
      setAuthModalOpen(true);
      return;
    }

    if (!currentUser.emailVerified) {
      setPendingDownloadGameId(game.gameId);
      setAuthModalMode('verify');
      setAuthContextMessage(
        `Verify your email address (${currentUser.email}) to start downloading "${game.title}".`,
      );
      setAuthModalOpen(true);
      return;
    }

    executeAuthorizedDownload(game.gameId);
  };

  // Resume pending download automatically once authenticated and email-verified
  const handleAuthSuccess = async (
    user: UserRecord,
    verificationToken?: string | null,
    googleAccessToken?: string | null,
  ) => {
    setCurrentUser(user);
    if (verificationToken !== undefined) {
      setPendingVerificationToken(verificationToken);
    }
    if (googleAccessToken) {
      setGmailConnected(true);
    }
    await fetchUserAccountData();

    if (user.emailVerified && pendingDownloadGameId) {
      const targetGameId = pendingDownloadGameId;
      setPendingDownloadGameId(null);
      setAuthContextMessage(null);
      await executeAuthorizedDownload(targetGameId);
    }
  };

  const handleSignOut = async () => {
    setAccountMenuOpen(false);
    try {
      await api.logout();
      await logoutGoogle();
    } finally {
      setStoredUserToken(null);
      setCurrentUser(null);
      setMySubmissions([]);
      setNotifications([]);
      setUnreadCount(0);
      setGmailConnected(false);
    }
  };

  const handleMarkNotificationRead = async (notificationId: string) => {
    await api.markNotificationRead(notificationId);
    await fetchUserAccountData();
  };

  const handleMarkAllNotificationsRead = async () => {
    await api.markAllNotificationsRead();
    await fetchUserAccountData();
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      {/* ==================================================================== */}
      {/* 3-ZONE TOP BAR CONTRACT                                              */}
      {/* Zone 1: Brand Wordmark | Zone 2: Panel, Apps, Add Apps | Zone 3: CTA */}
      {/* ==================================================================== */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-4 sm:gap-8 px-4 sm:px-8 py-3.5 bg-white border-b border-slate-200">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="/apps"
          onClick={(e) => {
            e.preventDefault();
            navigateToSection('apps');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          APK Forge
        </a>

        {/* Zone 2: Exact three primary navigation sections: Panel, Apps, Add Apps */}
        <nav
          aria-label="Primary Navigation"
          className="flex items-center gap-5 sm:gap-8 text-sm font-medium text-slate-600"
        >
          <a
            href="/panel"
            onClick={(e) => {
              e.preventDefault();
              navigateToSection('panel');
            }}
            aria-current={activeSection === 'panel' ? 'page' : undefined}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeSection === 'panel'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Panel
          </a>

          <a
            href="/apps"
            onClick={(e) => {
              e.preventDefault();
              navigateToSection('apps');
            }}
            aria-current={activeSection === 'apps' ? 'page' : undefined}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeSection === 'apps'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Apps
          </a>

          <a
            href="/add-apps"
            onClick={(e) => {
              e.preventDefault();
              navigateToSection('add-apps');
            }}
            aria-current={activeSection === 'add-apps' ? 'page' : undefined}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
              activeSection === 'add-apps'
                ? 'border-blue-700 text-slate-900 font-semibold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            Add Apps
          </a>
        </nav>

        {/* Zone 3: User Account Menu or Sign In Action */}
        <div className="flex items-center gap-3 shrink-0" ref={accountMenuRef}>
          {!currentUser ? (
            <button
              type="button"
              onClick={() => {
                setAuthModalMode('login');
                setAuthContextMessage(null);
                setAuthModalOpen(true);
              }}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Sign In
            </button>
          ) : (
            <div className="relative">
              <button
                type="button"
                onClick={() => setAccountMenuOpen((prev) => !prev)}
                aria-expanded={accountMenuOpen}
                aria-label={`Account menu for ${currentUser.email}`}
                className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <UserIcon className="w-3.5 h-3.5 text-slate-600" />
                <span className="max-w-[140px] truncate">{currentUser.email}</span>
                {unreadCount > 0 && (
                  <span
                    data-testid="unread-notifications-count"
                    className="font-mono text-[11px] font-bold text-blue-700 tabular-nums"
                  >
                    ({unreadCount})
                  </span>
                )}
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {accountMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 rounded-xl bg-white border border-slate-200 shadow-lg py-2 z-40">
                  <div className="px-4 py-2.5 border-b border-slate-100">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {currentUser.email}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {currentUser.emailVerified
                        ? 'Verified Publisher Account'
                        : 'Email Unverified'}
                    </div>
                  </div>

                  {!currentUser.emailVerified && (
                    <button
                      type="button"
                      onClick={() => {
                        setAccountMenuOpen(false);
                        setAuthModalMode('verify');
                        setAuthModalOpen(true);
                      }}
                      className="w-full px-4 py-2 text-left text-xs font-semibold text-amber-800 hover:bg-amber-50 flex items-center gap-2.5"
                    >
                      <MailCheck className="w-4 h-4 text-amber-600" />
                      Verify Email Address
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setAccountMenuOpen(false);
                      fetchUserAccountData();
                      setMySubmissionsOpen(true);
                    }}
                    className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2.5">
                      <FolderKanban className="w-4 h-4 text-slate-500" />
                      My Submissions
                    </span>
                    <span className="font-mono text-slate-400 tabular-nums">
                      {mySubmissions.length}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAccountMenuOpen(false);
                      fetchUserAccountData();
                      setNotificationsOpen(true);
                    }}
                    className="w-full px-4 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center justify-between"
                  >
                    <span className="flex items-center gap-2.5">
                      <Bell className="w-4 h-4 text-slate-500" />
                      Notifications
                    </span>
                    {unreadCount > 0 && (
                      <span className="font-mono font-bold text-blue-700 tabular-nums">
                        {unreadCount} unread
                      </span>
                    )}
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="w-full px-4 py-2 text-left text-xs font-semibold text-red-700 hover:bg-red-50 flex items-center gap-2.5"
                  >
                    <LogOut className="w-4 h-4 text-red-600" />
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </header>

      {/* ==================================================================== */}
      {/* MAIN CONTENT VIEWPORT                                                */}
      {/* ==================================================================== */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-8 py-8">
        {activeSection === 'apps' && (
          <AppsSection
            games={games}
            loading={loadingGames}
            error={gamesError}
            searchQuery={searchQuery}
            downloadingGameId={downloadingGameId}
            downloadStatusError={downloadStatusError}
            onSearchChange={setSearchQuery}
            onRetryLoad={() => fetchPublicGames(searchQuery)}
            onDownloadGame={handleDownloadGameClick}
            onNavigateAddApps={() => navigateToSection('add-apps')}
          />
        )}

        {activeSection === 'add-apps' && (
          <AddAppsSection
            currentUser={currentUser}
            maxApkSizeBytes={maxApkSizeBytes}
            draftTitle={draftForm.title}
            draftDescription={draftForm.description}
            draftVersion={draftForm.version}
            onDraftChange={setDraftForm}
            onRequireAuth={(mode, reason) => {
              setAuthModalMode(mode);
              setAuthContextMessage(reason);
              setAuthModalOpen(true);
            }}
            onSubmissionCreated={async () => {
              await fetchUserAccountData();
            }}
            onOpenMySubmissions={() => {
              fetchUserAccountData();
              setMySubmissionsOpen(true);
            }}
          />
        )}

        {activeSection === 'panel' && (
          <PanelSection
            adminToken={adminToken}
            maxApkSizeBytes={maxApkSizeBytes}
            onUnlockSuccess={(token) => setAdminToken(token)}
            onLockPanel={lockPanelImmediately}
            onPublicCatalogChanged={() => fetchPublicGames(searchQuery)}
          />
        )}
      </main>

      {/* ==================================================================== */}
      {/* QUIET FOOTER                                                         */}
      {/* ==================================================================== */}
      <footer className="border-t border-slate-200 bg-white px-4 sm:px-8 py-5 text-xs text-slate-500">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>APK Forge — Android APK Game Publishing Platform</div>
          <div className="flex items-center gap-4">
            <a
              href="/panel"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('panel');
              }}
              className="hover:text-slate-900"
            >
              Panel
            </a>
            <a
              href="/apps"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('apps');
              }}
              className="hover:text-slate-900"
            >
              Apps
            </a>
            <a
              href="/add-apps"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('add-apps');
              }}
              className="hover:text-slate-900"
            >
              Add Apps
            </a>
          </div>
        </div>
      </footer>

      {/* ==================================================================== */}
      {/* MODALS: AUTHENTICATION, MY SUBMISSIONS, NOTIFICATIONS                */}
      {/* ==================================================================== */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authModalMode}
        contextMessage={authContextMessage}
        currentUser={currentUser}
        pendingVerificationToken={pendingVerificationToken}
        onClose={() => {
          setAuthModalOpen(false);
          setAuthContextMessage(null);
        }}
        onAuthSuccess={handleAuthSuccess}
      />

      <MySubmissionsModal
        isOpen={mySubmissionsOpen}
        submissions={mySubmissions}
        maxApkSizeBytes={maxApkSizeBytes}
        onClose={() => setMySubmissionsOpen(false)}
        onRefresh={fetchUserAccountData}
      />

      <NotificationsModal
        isOpen={notificationsOpen}
        notifications={notifications}
        gmailConnected={gmailConnected}
        onClose={() => setNotificationsOpen(false)}
        onMarkRead={handleMarkNotificationRead}
        onMarkAllRead={handleMarkAllNotificationsRead}
        onOpenMySubmissions={() => setMySubmissionsOpen(true)}
      />
    </div>
  );
}
