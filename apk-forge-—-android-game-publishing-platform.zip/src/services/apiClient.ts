import type {
  AuditLogRecord,
  GameRecord,
  NotificationRecord,
  PlatformStats,
  ReviewMessageRecord,
  SubmissionRecord,
  UserRecord,
} from '../types/models';

const USER_SESSION_STORAGE_KEY = 'apkforge_user_session_token';

export function getStoredUserToken(): string | null {
  try {
    return window.localStorage.getItem(USER_SESSION_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredUserToken(token: string | null): void {
  try {
    if (token) {
      window.localStorage.setItem(USER_SESSION_STORAGE_KEY, token);
    } else {
      window.localStorage.removeItem(USER_SESSION_STORAGE_KEY);
    }
  } catch {
    // ignore storage errors
  }
}

export class ApiClientError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 400, code = 'API_ERROR') {
    super(message);
    this.name = 'ApiClientError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

async function requestJson<T>(
  url: string,
  options: RequestInit & { userToken?: string | null; adminToken?: string | null } = {},
): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && options.body && typeof options.body === 'string') {
    headers.set('Content-Type', 'application/json');
  }

  const userToken = options.userToken !== undefined ? options.userToken : getStoredUserToken();
  if (userToken) {
    headers.set('Authorization', `Bearer ${userToken}`);
  }
  if (options.adminToken) {
    headers.set('x-admin-token', options.adminToken);
  }

  let response: Response;
  try {
    response = await fetch(url, {
      ...options,
      headers,
    });
  } catch {
    throw new ApiClientError(
      'Network connection failed. Please check your connection and try again.',
      0,
      'NETWORK_ERROR',
    );
  }

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new ApiClientError(
      data?.error || `Request failed with status ${response.status}.`,
      response.status,
      data?.code || 'HTTP_ERROR',
    );
  }
  return data as T;
}

function encodeMetaHeader(meta: Record<string, unknown>): string {
  const jsonStr = JSON.stringify(meta);
  const bytes = new TextEncoder().encode(jsonStr);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export interface UploadTaskHandle<T> {
  promise: Promise<T>;
  abort: () => void;
}

export function uploadBinaryWithProgress<T>(params: {
  url: string;
  method?: 'POST' | 'PUT';
  file: File | null;
  meta: Record<string, unknown>;
  userToken?: string | null;
  adminToken?: string | null;
  onProgress?: (percent: number, loadedBytes: number, totalBytes: number) => void;
}): UploadTaskHandle<T> {
  const xhr = new XMLHttpRequest();

  const promise = new Promise<T>((resolve, reject) => {
    xhr.open(params.method || 'POST', params.url, true);

    const userToken = params.userToken !== undefined ? params.userToken : getStoredUserToken();
    if (userToken) {
      xhr.setRequestHeader('Authorization', `Bearer ${userToken}`);
    }
    if (params.adminToken) {
      xhr.setRequestHeader('x-admin-token', params.adminToken);
    }

    xhr.setRequestHeader(
      'x-apk-meta',
      encodeMetaHeader({
        ...params.meta,
        apkFileName: params.file ? params.file.name : '',
      }),
    );

    if (params.file) {
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    } else {
      xhr.setRequestHeader('Content-Type', 'application/json');
    }

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && params.onProgress) {
        const pct = Math.min(100, Math.round((event.loaded / event.total) * 100));
        params.onProgress(pct, event.loaded, event.total);
      }
    };

    xhr.onload = () => {
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(xhr.responseText || '{}') as Record<string, unknown>;
      } catch {
        parsed = {};
      }

      if (xhr.status >= 200 && xhr.status < 300) {
        if (params.onProgress && params.file) {
          params.onProgress(100, params.file.size, params.file.size);
        }
        resolve(parsed as T);
      } else {
        reject(
          new ApiClientError(
            (typeof parsed.error === 'string' && parsed.error) ||
              `Upload failed with status ${xhr.status}.`,
            xhr.status,
            (typeof parsed.code === 'string' && parsed.code) || 'UPLOAD_ERROR',
          ),
        );
      }
    };

    xhr.onerror = () => {
      reject(
        new ApiClientError(
          'Network error occurred while uploading APK file. Please retry.',
          0,
          'NETWORK_ERROR',
        ),
      );
    };

    xhr.onabort = () => {
      reject(new ApiClientError('APK upload was cancelled.', 0, 'UPLOAD_ABORTED'));
    };

    if (params.file) {
      xhr.send(params.file);
    } else {
      xhr.send(JSON.stringify(params.meta));
    }
  });

  return {
    promise,
    abort: () => xhr.abort(),
  };
}

// ============================================================================
// CLIENT-SIDE VALIDATION & ICON HELPERS
// ============================================================================

const FORBIDDEN_EXTENSIONS = [
  '.zip',
  '.html',
  '.htm',
  '.exe',
  '.msi',
  '.aab',
  '.ipa',
  '.dmg',
  '.tar',
  '.gz',
  '.rar',
  '.7z',
];

export function validateClientApkFile(
  file: File | null,
  maxBytes = 150 * 1024 * 1024,
): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'Please select an Android APK (.apk) file to upload.' };
  }
  const lower = file.name.trim().toLowerCase();
  for (const ext of FORBIDDEN_EXTENSIONS) {
    if (lower.endsWith(ext)) {
      return {
        valid: false,
        error: `File type "${ext.toUpperCase()}" is not allowed. Only Android APK (.apk) files are permitted.`,
      };
    }
  }
  if (!lower.endsWith('.apk')) {
    return {
      valid: false,
      error: 'Invalid file type. Only files with the .apk extension are accepted.',
    };
  }
  if (file.size === 0) {
    return { valid: false, error: 'Selected APK file is empty (0 bytes).' };
  }
  if (file.size > maxBytes) {
    const maxMb = (maxBytes / (1024 * 1024)).toFixed(1);
    const fileMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `Selected APK file (${fileMb} MB) exceeds the maximum allowed size of ${maxMb} MB.`,
    };
  }
  return { valid: true };
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  return `${mb.toFixed(2)} MB`;
}

export function formatDateShort(iso: string | null | undefined): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return iso;
  }
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

// ============================================================================
// TYPED API METHODS
// ============================================================================

export const api = {
  getHealth: () =>
    requestJson<{
      status: string;
      maxApkSizeBytes: number;
      adminSecretConfigured: boolean;
      firebaseConfigPresent: boolean;
    }>('/api/health'),

  // User Auth
  register: (email: string, password: string) =>
    requestJson<{ user: UserRecord; sessionToken: string; verificationToken: string }>(
      '/api/auth/register',
      {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      },
    ),

  login: (email: string, password: string) =>
    requestJson<{ user: UserRecord; sessionToken: string; verificationToken: string | null }>(
      '/api/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      },
    ),

  googleSync: (email: string, uid: string, gmailConnected: boolean) =>
    requestJson<{ user: UserRecord; sessionToken: string }>('/api/auth/google-sync', {
      method: 'POST',
      body: JSON.stringify({ email, uid, gmailConnected }),
    }),

  verifyEmail: (token?: string) =>
    requestJson<{ user: UserRecord }>('/api/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify({ token }),
    }),

  forgotPassword: (email: string) =>
    requestJson<{ resetToken: string | null; message: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  resetPassword: (email: string, resetToken: string, newPassword: string) =>
    requestJson<{ user: UserRecord; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, resetToken, newPassword }),
    }),

  getMe: () => requestJson<{ user: UserRecord }>('/api/auth/me'),

  logout: () =>
    requestJson<{ success: boolean }>('/api/auth/logout', {
      method: 'POST',
    }),

  // Public Apps & Downloads
  listGames: (search?: string) => {
    const qs = search ? `?search=${encodeURIComponent(search)}` : '';
    return requestJson<{ games: GameRecord[] }>(`/api/games${qs}`);
  },

  requestGameDownloadToken: (gameId: string) =>
    requestJson<{
      downloadToken: string;
      fileName: string;
      fileSizeBytes: number;
      gameId: string;
      downloadUrl: string;
    }>(`/api/games/${encodeURIComponent(gameId)}/download-token`, {
      method: 'POST',
    }),

  // User Submissions & Notifications
  listMySubmissions: () => requestJson<{ submissions: SubmissionRecord[] }>('/api/submissions/mine'),

  getMySubmission: (submissionId: string) =>
    requestJson<{ submission: SubmissionRecord }>(
      `/api/submissions/${encodeURIComponent(submissionId)}`,
    ),

  listNotifications: () =>
    requestJson<{ notifications: NotificationRecord[]; unreadCount: number }>('/api/notifications'),

  markNotificationRead: (notificationId: string) =>
    requestJson<{ notification: NotificationRecord }>(
      `/api/notifications/${encodeURIComponent(notificationId)}/read`,
      { method: 'POST' },
    ),

  markAllNotificationsRead: () =>
    requestJson<{ updatedCount: number }>('/api/notifications/read-all', { method: 'POST' }),

  // Admin Panel
  adminLogin: (password: string) =>
    requestJson<{ adminToken: string; expiresAt: string }>('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ password }),
    }),

  adminLock: (adminToken: string | null) => {
    if (!adminToken) return Promise.resolve({ locked: true });
    return requestJson<{ locked: boolean }>('/api/admin/lock', {
      method: 'POST',
      adminToken,
      body: JSON.stringify({ adminToken }),
    }).catch(() => ({ locked: true }));
  },

  adminGetDashboard: (adminToken: string, filter?: { status?: string; search?: string }) => {
    const params = new URLSearchParams();
    if (filter?.status) params.set('status', filter.status);
    if (filter?.search) params.set('search', filter.search);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return requestJson<{
      stats: PlatformStats;
      games: GameRecord[];
      submissions: SubmissionRecord[];
      auditLogs: AuditLogRecord[];
    }>(`/api/admin/dashboard${qs}`, { adminToken });
  },

  adminSetGameStatus: (adminToken: string, gameId: string, status: 'Published' | 'Unpublished') =>
    requestJson<{ game: GameRecord; stats: PlatformStats }>(
      `/api/admin/games/${encodeURIComponent(gameId)}/status`,
      {
        method: 'PATCH',
        adminToken,
        body: JSON.stringify({ status }),
      },
    ),

  adminDeleteGame: (adminToken: string, gameId: string) =>
    requestJson<{ deleted: boolean; stats: PlatformStats }>(
      `/api/admin/games/${encodeURIComponent(gameId)}`,
      {
        method: 'DELETE',
        adminToken,
      },
    ),

  adminRequestSubmissionDownload: (adminToken: string, submissionId: string) =>
    requestJson<{
      downloadToken: string;
      fileName: string;
      fileSizeBytes: number;
      submissionId: string;
      downloadUrl: string;
    }>(`/api/admin/submissions/${encodeURIComponent(submissionId)}/download-token`, {
      method: 'POST',
      adminToken,
    }),

  adminApproveSubmission: (
    adminToken: string,
    submissionId: string,
    emailDelivered = false,
  ) =>
    requestJson<{ submission: SubmissionRecord; game: GameRecord; stats: PlatformStats }>(
      `/api/admin/submissions/${encodeURIComponent(submissionId)}/approve`,
      {
        method: 'POST',
        adminToken,
        body: JSON.stringify({ emailDelivered }),
      },
    ),

  adminRejectSubmission: (
    adminToken: string,
    submissionId: string,
    reason?: string,
    emailDelivered = false,
  ) =>
    requestJson<{ submission: SubmissionRecord; stats: PlatformStats }>(
      `/api/admin/submissions/${encodeURIComponent(submissionId)}/reject`,
      {
        method: 'POST',
        adminToken,
        body: JSON.stringify({ reason, emailDelivered }),
      },
    ),

  adminRequestChanges: (
    adminToken: string,
    submissionId: string,
    message: string,
    emailDelivered = false,
  ) =>
    requestJson<{
      submission: SubmissionRecord;
      reviewMessage: ReviewMessageRecord;
      stats: PlatformStats;
    }>(`/api/admin/submissions/${encodeURIComponent(submissionId)}/request-changes`, {
      method: 'POST',
      adminToken,
      body: JSON.stringify({ message, emailDelivered }),
    }),
};
