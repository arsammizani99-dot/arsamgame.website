import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AuditLogRecord,
  CorrectionHistoryEntry,
  GameRecord,
  NotificationRecord,
  NotificationType,
  PlatformStats,
  PublicationStatus,
  ReviewMessageRecord,
  ReviewStatus,
  SubmissionRecord,
  UserRecord,
} from '../types/models';
import {
  DEFAULT_MAX_APK_SIZE_BYTES,
  sanitizeDownloadFilename,
  validateApkBinary,
  validateGameMetadata,
} from '../utils/apkValidator';

interface StoredUserInternal extends UserRecord {
  passwordHash: string;
  passwordSalt: string;
  verificationToken: string | null;
  resetToken: string | null;
  resetTokenExpiresAt: number | null;
}

interface PersistedDatabase {
  users: StoredUserInternal[];
  games: GameRecord[];
  submissions: SubmissionRecord[];
  notifications: NotificationRecord[];
  reviewMessages: ReviewMessageRecord[];
  auditLogs: AuditLogRecord[];
}

interface UserSession {
  token: string;
  userId: string;
  createdAt: number;
  expiresAt: number;
}

interface AdminSession {
  token: string;
  adminId: string;
  createdAt: number;
  expiresAt: number;
}

interface DownloadTicket {
  token: string;
  kind: 'game' | 'submission';
  targetId: string;
  filePath: string;
  downloadFilename: string;
  fileSizeBytes: number;
  issuedTo: string;
  expiresAt: number;
}

export class PlatformError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 400, code = 'BAD_REQUEST') {
    super(message);
    this.name = 'PlatformError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

export interface PlatformStoreOptions {
  dataDir?: string;
  adminPassword?: string;
  maxApkSizeBytes?: number;
}

export class PlatformStore {
  private readonly dataDir: string;
  private readonly dbFilePath: string;
  private readonly gamesStorageDir: string;
  private readonly submissionsStorageDir: string;
  private readonly adminPassword: string;
  private readonly maxApkSizeBytes: number;

  private db: PersistedDatabase;
  private userSessions = new Map<string, UserSession>();
  private adminSessions = new Map<string, AdminSession>();
  private downloadTickets = new Map<string, DownloadTicket>();
  private adminLoginAttempts = new Map<string, { count: number; firstAttemptAt: number; blockedUntil: number }>();

  constructor(options?: PlatformStoreOptions) {
    this.dataDir = options?.dataDir || path.resolve(process.cwd(), '.data');
    this.dbFilePath = path.join(this.dataDir, 'database.json');
    this.gamesStorageDir = path.join(this.dataDir, 'storage', 'games');
    this.submissionsStorageDir = path.join(this.dataDir, 'storage', 'submissions');
    this.adminPassword = options?.adminPassword || process.env.ADMIN_PANEL_PASSWORD || 'arsam27';
    const envMaxMb = Number(process.env.MAX_APK_SIZE_MB);
    this.maxApkSizeBytes =
      options?.maxApkSizeBytes ||
      (Number.isFinite(envMaxMb) && envMaxMb > 0 ? envMaxMb * 1024 * 1024 : DEFAULT_MAX_APK_SIZE_BYTES);

    this.ensureDirectories();
    this.db = this.loadDatabase();
  }

  private ensureDirectories(): void {
    fs.mkdirSync(this.dataDir, { recursive: true });
    fs.mkdirSync(this.gamesStorageDir, { recursive: true });
    fs.mkdirSync(this.submissionsStorageDir, { recursive: true });
  }

  private loadDatabase(): PersistedDatabase {
    if (!fs.existsSync(this.dbFilePath)) {
      const initial: PersistedDatabase = {
        users: [],
        games: [],
        submissions: [],
        notifications: [],
        reviewMessages: [],
        auditLogs: [],
      };
      this.saveDatabase(initial);
      return initial;
    }

    try {
      const raw = fs.readFileSync(this.dbFilePath, 'utf8');
      const parsed = JSON.parse(raw) as Partial<PersistedDatabase>;
      return {
        users: Array.isArray(parsed.users) ? parsed.users : [],
        games: Array.isArray(parsed.games) ? parsed.games : [],
        submissions: Array.isArray(parsed.submissions) ? parsed.submissions : [],
        notifications: Array.isArray(parsed.notifications) ? parsed.notifications : [],
        reviewMessages: Array.isArray(parsed.reviewMessages) ? parsed.reviewMessages : [],
        auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
      };
    } catch {
      const fallback: PersistedDatabase = {
        users: [],
        games: [],
        submissions: [],
        notifications: [],
        reviewMessages: [],
        auditLogs: [],
      };
      return fallback;
    }
  }

  private saveDatabase(data: PersistedDatabase = this.db): void {
    this.ensureDirectories();
    const tmpPath = `${this.dbFilePath}.${crypto.randomBytes(4).toString('hex')}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmpPath, this.dbFilePath);
  }

  public getMaxApkSizeBytes(): number {
    return this.maxApkSizeBytes;
  }

  private toPublicUser(user: StoredUserInternal): UserRecord {
    return {
      userId: user.userId,
      email: user.email,
      emailVerified: user.emailVerified,
      createdAt: user.createdAt,
      lastLoginAt: user.lastLoginAt,
      authProvider: user.authProvider,
      gmailConnected: user.gmailConnected,
    };
  }

  private hashPassword(password: string, salt: string): string {
    return crypto.scryptSync(password, salt, 64).toString('hex');
  }

  private normalizeEmail(email: unknown): string {
    if (typeof email !== 'string') return '';
    return email.trim().toLowerCase();
  }

  private isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
  }

  // ============================================================================
  // USER AUTHENTICATION & EMAIL VERIFICATION
  // ============================================================================

  public registerUser(input: { email?: unknown; password?: unknown }): {
    user: UserRecord;
    sessionToken: string;
    verificationToken: string;
  } {
    const email = this.normalizeEmail(input.email);
    const password = typeof input.password === 'string' ? input.password : '';

    if (!email || !this.isValidEmail(email)) {
      throw new PlatformError('Please enter a valid email address.', 400, 'INVALID_EMAIL');
    }
    if (password.length < 6) {
      throw new PlatformError('Password must be at least 6 characters long.', 400, 'WEAK_PASSWORD');
    }
    if (password.length > 128) {
      throw new PlatformError('Password cannot exceed 128 characters.', 400, 'INVALID_PASSWORD');
    }

    const existing = this.db.users.find((u) => u.email === email);
    if (existing) {
      throw new PlatformError(
        'An account with this email address already exists. Please sign in instead.',
        409,
        'ACCOUNT_EXISTS',
      );
    }

    const now = new Date().toISOString();
    const userId = `usr_${crypto.randomUUID()}`;
    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = this.hashPassword(password, salt);
    const verificationToken = `vrf_${crypto.randomBytes(20).toString('hex')}`;

    const newUser: StoredUserInternal = {
      userId,
      email,
      emailVerified: false,
      createdAt: now,
      lastLoginAt: now,
      authProvider: 'email',
      gmailConnected: false,
      passwordHash,
      passwordSalt: salt,
      verificationToken,
      resetToken: null,
      resetTokenExpiresAt: null,
    };

    this.db.users.push(newUser);
    this.saveDatabase();

    const sessionToken = this.issueUserSession(userId);
    return {
      user: this.toPublicUser(newUser),
      sessionToken,
      verificationToken,
    };
  }

  public loginUser(input: { email?: unknown; password?: unknown }): {
    user: UserRecord;
    sessionToken: string;
    verificationToken: string | null;
  } {
    const email = this.normalizeEmail(input.email);
    const password = typeof input.password === 'string' ? input.password : '';

    if (!email || !this.isValidEmail(email)) {
      throw new PlatformError('Please enter a valid email address.', 400, 'INVALID_EMAIL');
    }
    if (!password) {
      throw new PlatformError('Please enter your password.', 400, 'INVALID_CREDENTIALS');
    }

    const user = this.db.users.find((u) => u.email === email);
    if (!user || !user.passwordSalt || !user.passwordHash) {
      throw new PlatformError('Invalid email or password.', 401, 'INVALID_CREDENTIALS');
    }

    const computedHash = this.hashPassword(password, user.passwordSalt);
    const a = Buffer.from(computedHash, 'hex');
    const b = Buffer.from(user.passwordHash, 'hex');
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      throw new PlatformError('Invalid email or password.', 401, 'INVALID_CREDENTIALS');
    }

    user.lastLoginAt = new Date().toISOString();
    this.saveDatabase();

    const sessionToken = this.issueUserSession(user.userId);
    return {
      user: this.toPublicUser(user),
      sessionToken,
      verificationToken: user.emailVerified ? null : user.verificationToken,
    };
  }

  public syncGoogleUser(input: {
    email?: unknown;
    uid?: unknown;
    gmailConnected?: boolean;
  }): {
    user: UserRecord;
    sessionToken: string;
  } {
    const email = this.normalizeEmail(input.email);
    if (!email || !this.isValidEmail(email)) {
      throw new PlatformError('Invalid Google account email.', 400, 'INVALID_EMAIL');
    }

    const now = new Date().toISOString();
    let user = this.db.users.find((u) => u.email === email);
    if (!user) {
      const salt = crypto.randomBytes(16).toString('hex');
      user = {
        userId: typeof input.uid === 'string' && input.uid ? `usr_${input.uid}` : `usr_${crypto.randomUUID()}`,
        email,
        emailVerified: true,
        createdAt: now,
        lastLoginAt: now,
        authProvider: 'google',
        gmailConnected: Boolean(input.gmailConnected),
        passwordHash: '',
        passwordSalt: salt,
        verificationToken: null,
        resetToken: null,
        resetTokenExpiresAt: null,
      };
      this.db.users.push(user);
    } else {
      user.emailVerified = true;
      user.verificationToken = null;
      user.lastLoginAt = now;
      if (input.gmailConnected !== undefined) {
        user.gmailConnected = Boolean(input.gmailConnected);
      }
    }

    this.saveDatabase();
    const sessionToken = this.issueUserSession(user.userId);
    return {
      user: this.toPublicUser(user),
      sessionToken,
    };
  }

  public verifyUserEmail(userId: string, token?: string): UserRecord {
    const user = this.db.users.find((u) => u.userId === userId);
    if (!user) {
      throw new PlatformError('User account not found.', 404, 'USER_NOT_FOUND');
    }
    if (user.emailVerified) {
      return this.toPublicUser(user);
    }
    if (token && user.verificationToken && token !== user.verificationToken) {
      throw new PlatformError('Invalid email verification token.', 400, 'INVALID_VERIFICATION_TOKEN');
    }

    user.emailVerified = true;
    user.verificationToken = null;
    this.createNotificationInternal({
      recipientUserId: user.userId,
      relatedSubmissionId: null,
      title: 'Email Address Verified',
      message: `Your email (${user.email}) is now verified. You can download published APK games and submit your own games for review.`,
      type: 'ACCOUNT_VERIFIED',
    });
    this.saveDatabase();
    return this.toPublicUser(user);
  }

  public requestPasswordReset(emailInput: unknown): { resetToken: string | null; message: string } {
    const email = this.normalizeEmail(emailInput);
    if (!email || !this.isValidEmail(email)) {
      throw new PlatformError('Please enter a valid email address.', 400, 'INVALID_EMAIL');
    }

    const user = this.db.users.find((u) => u.email === email);
    if (!user) {
      return {
        resetToken: null,
        message: 'If an account exists for that email address, a password reset token has been generated.',
      };
    }

    const resetToken = `rst_${crypto.randomBytes(16).toString('hex')}`;
    user.resetToken = resetToken;
    user.resetTokenExpiresAt = Date.now() + 30 * 60 * 1000;
    this.saveDatabase();

    return {
      resetToken,
      message: 'Password reset token generated. Enter the reset token and your new password below.',
    };
  }

  public resetPassword(input: {
    email?: unknown;
    resetToken?: unknown;
    newPassword?: unknown;
  }): UserRecord {
    const email = this.normalizeEmail(input.email);
    const resetToken = typeof input.resetToken === 'string' ? input.resetToken.trim() : '';
    const newPassword = typeof input.newPassword === 'string' ? input.newPassword : '';

    if (!email || !this.isValidEmail(email)) {
      throw new PlatformError('Please enter a valid email address.', 400, 'INVALID_EMAIL');
    }
    if (!resetToken) {
      throw new PlatformError('Reset token is required.', 400, 'INVALID_RESET_TOKEN');
    }
    if (newPassword.length < 6) {
      throw new PlatformError('New password must be at least 6 characters long.', 400, 'WEAK_PASSWORD');
    }

    const user = this.db.users.find((u) => u.email === email);
    if (
      !user ||
      !user.resetToken ||
      user.resetToken !== resetToken ||
      !user.resetTokenExpiresAt ||
      Date.now() > user.resetTokenExpiresAt
    ) {
      throw new PlatformError('Invalid or expired password reset token.', 400, 'INVALID_RESET_TOKEN');
    }

    const salt = crypto.randomBytes(16).toString('hex');
    user.passwordSalt = salt;
    user.passwordHash = this.hashPassword(newPassword, salt);
    user.resetToken = null;
    user.resetTokenExpiresAt = null;
    this.saveDatabase();

    return this.toPublicUser(user);
  }

  private issueUserSession(userId: string): string {
    const token = `usess_${crypto.randomBytes(28).toString('hex')}`;
    const now = Date.now();
    this.userSessions.set(token, {
      token,
      userId,
      createdAt: now,
      expiresAt: now + 7 * 24 * 60 * 60 * 1000, // 7 days
    });
    return token;
  }

  public getUserBySessionToken(token: string | undefined | null): UserRecord | null {
    if (!token) return null;
    const clean = token.replace(/^Bearer\s+/i, '').trim();
    const session = this.userSessions.get(clean);
    if (!session) return null;
    if (Date.now() > session.expiresAt) {
      this.userSessions.delete(clean);
      return null;
    }
    const user = this.db.users.find((u) => u.userId === session.userId);
    if (!user) return null;
    return this.toPublicUser(user);
  }

  public requireAuthenticatedUser(
    token: string | undefined | null,
    requireVerifiedEmail = true,
  ): UserRecord {
    const user = this.getUserBySessionToken(token);
    if (!user) {
      throw new PlatformError('Authentication required. Please sign in with your email account.', 401, 'UNAUTHORIZED');
    }
    if (requireVerifiedEmail && !user.emailVerified) {
      throw new PlatformError(
        'Email verification is required before performing this action. Please verify your email address first.',
        403,
        'EMAIL_NOT_VERIFIED',
      );
    }
    return user;
  }

  public logoutUser(token: string | undefined | null): void {
    if (!token) return;
    const clean = token.replace(/^Bearer\s+/i, '').trim();
    this.userSessions.delete(clean);
  }

  // ============================================================================
  // ADMINISTRATOR AUTHENTICATION & STRICT SESSION LOCKING
  // ============================================================================

  public verifyAdminPassword(passwordInput: unknown, clientKey = 'default'): {
    adminToken: string;
    expiresAt: string;
  } {
    const now = Date.now();
    const rateRecord = this.adminLoginAttempts.get(clientKey);
    if (rateRecord) {
      if (rateRecord.blockedUntil > now) {
        const waitSec = Math.ceil((rateRecord.blockedUntil - now) / 1000);
        throw new PlatformError(
          `Too many failed login attempts. Please wait ${waitSec} seconds before trying again.`,
          429,
          'RATE_LIMITED',
        );
      }
      if (now - rateRecord.firstAttemptAt > 20000) {
        this.adminLoginAttempts.delete(clientKey);
      }
    }

    const candidate = typeof passwordInput === 'string' ? passwordInput : '';
    if (!candidate) {
      throw new PlatformError('Please enter the administrator password.', 400, 'MISSING_PASSWORD');
    }

    const expectedBuf = Buffer.from(this.adminPassword, 'utf8');
    const candidateBuf = Buffer.from(candidate, 'utf8');
    const isMatch =
      expectedBuf.length === candidateBuf.length && crypto.timingSafeEqual(expectedBuf, candidateBuf);

    if (!isMatch) {
      const current = this.adminLoginAttempts.get(clientKey) || {
        count: 0,
        firstAttemptAt: now,
        blockedUntil: 0,
      };
      current.count += 1;
      if (current.count >= 5) {
        current.blockedUntil = now + 15000; // 15-second lockout on 5 rapid failures
      }
      this.adminLoginAttempts.set(clientKey, current);

      throw new PlatformError('Incorrect administrator password.', 401, 'INVALID_ADMIN_PASSWORD');
    }

    this.adminLoginAttempts.delete(clientKey);

    const adminToken = `adm_${crypto.randomBytes(32).toString('hex')}`;
    const expiresAtMs = now + 30 * 60 * 1000; // 30 minutes max if uninterrupted
    this.adminSessions.set(adminToken, {
      token: adminToken,
      adminId: 'admin_primary',
      createdAt: now,
      expiresAt: expiresAtMs,
    });

    this.recordAuditLog({
      administratorId: 'admin_primary',
      action: 'ADMIN_LOGIN',
      targetId: 'panel',
      targetTitle: 'Administration Panel',
      details: 'Administrator unlocked Panel with verified server-side password.',
    });

    return {
      adminToken,
      expiresAt: new Date(expiresAtMs).toISOString(),
    };
  }

  public requireAdminSession(token: string | undefined | null): AdminSession {
    if (!token) {
      throw new PlatformError(
        'Administrator authentication required. Please unlock Panel with the administrator password.',
        401,
        'ADMIN_UNAUTHORIZED',
      );
    }
    const clean = token.replace(/^Bearer\s+/i, '').trim();
    const session = this.adminSessions.get(clean);
    if (!session) {
      throw new PlatformError(
        'Administrator session is locked or expired. Please enter the administrator password again.',
        401,
        'ADMIN_SESSION_INVALID',
      );
    }
    if (Date.now() > session.expiresAt) {
      this.adminSessions.delete(clean);
      throw new PlatformError(
        'Administrator session has expired. Please re-enter the administrator password.',
        401,
        'ADMIN_SESSION_EXPIRED',
      );
    }
    return session;
  }

  public lockAdminSession(token?: string | null): void {
    if (token) {
      const clean = token.replace(/^Bearer\s+/i, '').trim();
      if (this.adminSessions.has(clean)) {
        this.adminSessions.delete(clean);
        this.recordAuditLog({
          administratorId: 'admin_primary',
          action: 'ADMIN_LOCK',
          targetId: 'panel',
          targetTitle: 'Administration Panel',
          details: 'Administrator session invalidated upon leaving Panel.',
        });
      }
    } else {
      this.adminSessions.clear();
    }
  }

  public resetAdminRateLimit(clientKey?: string): void {
    if (clientKey) {
      this.adminLoginAttempts.delete(clientKey);
    } else {
      this.adminLoginAttempts.clear();
    }
  }

  // ============================================================================
  // PANEL STATISTICS & AUDIT LOGS
  // ============================================================================

  public getPlatformStats(): PlatformStats {
    const totalPublishedGames = this.db.games.filter((g) => g.publicationStatus === 'Published').length;
    const totalUnpublishedGames = this.db.games.filter((g) => g.publicationStatus === 'Unpublished').length;
    const pendingSubmissions = this.db.submissions.filter((s) => s.reviewStatus === 'Pending').length;
    const approvedSubmissions = this.db.submissions.filter((s) => s.reviewStatus === 'Approved').length;
    const rejectedSubmissions = this.db.submissions.filter((s) => s.reviewStatus === 'Rejected').length;
    const needsChangesSubmissions = this.db.submissions.filter((s) => s.reviewStatus === 'Needs Changes').length;

    return {
      totalPublishedGames,
      totalUnpublishedGames,
      pendingSubmissions,
      approvedSubmissions,
      rejectedSubmissions,
      needsChangesSubmissions,
    };
  }

  public getAuditLogs(): AuditLogRecord[] {
    return [...this.db.auditLogs].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }

  private recordAuditLog(params: {
    administratorId: string;
    action: AuditLogRecord['action'];
    targetId: string;
    targetTitle: string;
    details: string;
  }): void {
    this.db.auditLogs.push({
      logId: `aud_${crypto.randomUUID()}`,
      timestamp: new Date().toISOString(),
      administratorId: params.administratorId,
      action: params.action,
      targetId: params.targetId,
      targetTitle: params.targetTitle,
      details: params.details,
    });
    this.saveDatabase();
  }

  // ============================================================================
  // PANEL TAB 1: PUBLISH GAME & ADMINISTRATOR GAME MANAGEMENT
  // ============================================================================

  public publishGameByAdmin(params: {
    adminToken: string | undefined | null;
    title: unknown;
    description: unknown;
    version?: unknown;
    apkFileName: string;
    apkBuffer: Buffer;
  }): GameRecord {
    const admin = this.requireAdminSession(params.adminToken);

    const metaCheck = validateGameMetadata({
      title: params.title,
      description: params.description,
      version: params.version,
    });
    if (!metaCheck.valid || !metaCheck.sanitized) {
      throw new PlatformError(metaCheck.error || 'Invalid game metadata.', 400, 'INVALID_METADATA');
    }

    const apkCheck = validateApkBinary(params.apkBuffer, params.apkFileName, this.maxApkSizeBytes);
    if (!apkCheck.valid || !apkCheck.inspection) {
      throw new PlatformError(apkCheck.error || 'Invalid APK file.', 400, 'INVALID_APK');
    }

    const gameId = `game_${crypto.randomUUID()}`;
    const objectFileName = `${gameId}-${crypto.randomBytes(6).toString('hex')}.apk`;
    const relativeObjectPath = path.join('storage', 'games', objectFileName);
    const absoluteFilePath = path.join(this.dataDir, relativeObjectPath);

    try {
      fs.writeFileSync(absoluteFilePath, params.apkBuffer);
      const stat = fs.statSync(absoluteFilePath);
      if (stat.size !== params.apkBuffer.length) {
        throw new Error('Stored APK byte size mismatch.');
      }

      const now = new Date().toISOString();
      const gameRecord: GameRecord = {
        gameId,
        title: metaCheck.sanitized.title,
        description: metaCheck.sanitized.description,
        version: metaCheck.sanitized.version,
        storageObjectPath: relativeObjectPath,
        fileSizeBytes: params.apkBuffer.length,
        sha256: apkCheck.inspection.sha256,
        apkInspection: apkCheck.inspection,
        publicationStatus: 'Published',
        createdAt: now,
        publishedAt: now,
        updatedAt: now,
        publishedBy: admin.adminId,
        sourceSubmissionId: null,
      };

      this.db.games.push(gameRecord);
      this.saveDatabase();

      this.recordAuditLog({
        administratorId: admin.adminId,
        action: 'GAME_PUBLISHED',
        targetId: gameId,
        targetTitle: gameRecord.title,
        details: `Published game v${gameRecord.version} (${gameRecord.fileSizeBytes} bytes).`,
      });

      return gameRecord;
    } catch (err) {
      if (fs.existsSync(absoluteFilePath)) {
        try {
          fs.unlinkSync(absoluteFilePath);
        } catch {
          // ignore cleanup failure
        }
      }
      if (err instanceof PlatformError) throw err;
      throw new PlatformError(
        'Failed to store APK and publish game record. Incomplete upload was cleaned up.',
        500,
        'STORAGE_FAILURE',
      );
    }
  }

  public listPublicGames(searchQuery?: string): GameRecord[] {
    const q = (searchQuery || '').trim().toLowerCase();
    return this.db.games
      .filter((g) => {
        if (g.publicationStatus !== 'Published') return false;
        const absPath = path.join(this.dataDir, g.storageObjectPath);
        if (!fs.existsSync(absPath)) return false;
        if (q && !g.title.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));
  }

  public listAllGamesForAdmin(adminToken: string | undefined | null): GameRecord[] {
    this.requireAdminSession(adminToken);
    return this.db.games
      .filter((g) => g.publicationStatus !== 'Removed')
      .sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));
  }

  public updateGameByAdmin(params: {
    adminToken: string | undefined | null;
    gameId: string;
    title: unknown;
    description: unknown;
    version?: unknown;
    replacementApk?: { fileName: string; buffer: Buffer } | null;
  }): GameRecord {
    const admin = this.requireAdminSession(params.adminToken);
    const game = this.db.games.find((g) => g.gameId === params.gameId && g.publicationStatus !== 'Removed');
    if (!game) {
      throw new PlatformError('Game record not found.', 404, 'GAME_NOT_FOUND');
    }

    const metaCheck = validateGameMetadata({
      title: params.title,
      description: params.description,
      version: params.version ?? game.version,
    });
    if (!metaCheck.valid || !metaCheck.sanitized) {
      throw new PlatformError(metaCheck.error || 'Invalid game metadata.', 400, 'INVALID_METADATA');
    }

    let newRelativePath: string | null = null;
    let newAbsolutePath: string | null = null;
    const oldRelativePath = game.storageObjectPath;

    if (params.replacementApk) {
      const apkCheck = validateApkBinary(
        params.replacementApk.buffer,
        params.replacementApk.fileName,
        this.maxApkSizeBytes,
      );
      if (!apkCheck.valid || !apkCheck.inspection) {
        throw new PlatformError(apkCheck.error || 'Invalid replacement APK file.', 400, 'INVALID_APK');
      }

      const objectFileName = `${game.gameId}-r-${crypto.randomBytes(6).toString('hex')}.apk`;
      newRelativePath = path.join('storage', 'games', objectFileName);
      newAbsolutePath = path.join(this.dataDir, newRelativePath);
      fs.writeFileSync(newAbsolutePath, params.replacementApk.buffer);

      game.storageObjectPath = newRelativePath;
      game.fileSizeBytes = params.replacementApk.buffer.length;
      game.sha256 = apkCheck.inspection.sha256;
      game.apkInspection = apkCheck.inspection;
    }

    game.title = metaCheck.sanitized.title;
    game.description = metaCheck.sanitized.description;
    game.version = metaCheck.sanitized.version;
    game.updatedAt = new Date().toISOString();

    this.saveDatabase();

    if (newRelativePath && oldRelativePath !== newRelativePath) {
      this.cleanupStorageFileIfUnreferenced(oldRelativePath);
    }

    this.recordAuditLog({
      administratorId: admin.adminId,
      action: params.replacementApk ? 'GAME_APK_REPLACED' : 'GAME_EDITED',
      targetId: game.gameId,
      targetTitle: game.title,
      details: params.replacementApk
        ? `Updated metadata and replaced APK for "${game.title}" (v${game.version}).`
        : `Edited metadata for "${game.title}" (v${game.version}).`,
    });

    return game;
  }

  public setGamePublicationStatus(params: {
    adminToken: string | undefined | null;
    gameId: string;
    status: 'Published' | 'Unpublished';
  }): GameRecord {
    const admin = this.requireAdminSession(params.adminToken);
    const game = this.db.games.find((g) => g.gameId === params.gameId && g.publicationStatus !== 'Removed');
    if (!game) {
      throw new PlatformError('Game record not found.', 404, 'GAME_NOT_FOUND');
    }

    if (params.status === 'Published') {
      const absPath = path.join(this.dataDir, game.storageObjectPath);
      if (!fs.existsSync(absPath)) {
        throw new PlatformError(
          'Cannot republish game because its stored APK file is missing.',
          400,
          'MISSING_APK_FILE',
        );
      }
      game.publishedAt = new Date().toISOString();
    }

    game.publicationStatus = params.status;
    game.updatedAt = new Date().toISOString();
    this.saveDatabase();

    this.recordAuditLog({
      administratorId: admin.adminId,
      action: params.status === 'Published' ? 'GAME_REPUBLISHED' : 'GAME_UNPUBLISHED',
      targetId: game.gameId,
      targetTitle: game.title,
      details: `Changed publication status to ${params.status}.`,
    });

    return game;
  }

  public deleteGameByAdmin(params: {
    adminToken: string | undefined | null;
    gameId: string;
  }): void {
    const admin = this.requireAdminSession(params.adminToken);
    const gameIndex = this.db.games.findIndex((g) => g.gameId === params.gameId);
    if (gameIndex === -1) {
      throw new PlatformError('Game record not found.', 404, 'GAME_NOT_FOUND');
    }

    const game = this.db.games[gameIndex];
    const storagePath = game.storageObjectPath;
    const title = game.title;

    // 1. Update publication status before deleting file
    game.publicationStatus = 'Removed';
    this.db.games.splice(gameIndex, 1);
    this.saveDatabase();

    // 2. Delete storage file only if not referenced by any submission or another game
    this.cleanupStorageFileIfUnreferenced(storagePath);

    this.recordAuditLog({
      administratorId: admin.adminId,
      action: 'GAME_REMOVED',
      targetId: params.gameId,
      targetTitle: title,
      details: `Removed game "${title}" and cleaned up unreferenced storage.`,
    });
  }

  private cleanupStorageFileIfUnreferenced(relativeStoragePath: string): void {
    const referencedByGame = this.db.games.some(
      (g) => g.publicationStatus !== 'Removed' && g.storageObjectPath === relativeStoragePath,
    );
    const referencedBySubmission = this.db.submissions.some(
      (s) => s.privateStorageObjectPath === relativeStoragePath,
    );

    if (!referencedByGame && !referencedBySubmission) {
      const absPath = path.join(this.dataDir, relativeStoragePath);
      if (fs.existsSync(absPath)) {
        try {
          fs.unlinkSync(absPath);
        } catch {
          // ignore
        }
      }
    }
  }

  // ============================================================================
  // ADD APPS: USER SUBMISSIONS & RESUBMISSIONS
  // ============================================================================

  public createSubmission(params: {
    userSessionToken: string | undefined | null;
    title: unknown;
    description: unknown;
    version?: unknown;
    apkFileName: string;
    apkBuffer: Buffer;
  }): SubmissionRecord {
    const user = this.requireAuthenticatedUser(params.userSessionToken, true);

    const metaCheck = validateGameMetadata({
      title: params.title,
      description: params.description,
      version: params.version,
    });
    if (!metaCheck.valid || !metaCheck.sanitized) {
      throw new PlatformError(metaCheck.error || 'Invalid game metadata.', 400, 'INVALID_METADATA');
    }

    const apkCheck = validateApkBinary(params.apkBuffer, params.apkFileName, this.maxApkSizeBytes);
    if (!apkCheck.valid || !apkCheck.inspection) {
      throw new PlatformError(apkCheck.error || 'Invalid APK file.', 400, 'INVALID_APK');
    }

    // Prevent accidental rapid duplicate submission of exact same title + sha256 while Pending
    const duplicate = this.db.submissions.find(
      (s) =>
        s.userId === user.userId &&
        s.reviewStatus === 'Pending' &&
        s.title.toLowerCase() === metaCheck.sanitized!.title.toLowerCase() &&
        s.sha256 === apkCheck.inspection!.sha256,
    );
    if (duplicate) {
      throw new PlatformError(
        'An identical pending submission for this APK is already awaiting administrator review.',
        409,
        'DUPLICATE_SUBMISSION',
      );
    }

    const submissionId = `sub_${crypto.randomUUID()}`;
    const objectFileName = `${submissionId}-v1-${crypto.randomBytes(6).toString('hex')}.apk`;
    const relativeObjectPath = path.join('storage', 'submissions', objectFileName);
    const absoluteFilePath = path.join(this.dataDir, relativeObjectPath);

    try {
      fs.writeFileSync(absoluteFilePath, params.apkBuffer);
      const stat = fs.statSync(absoluteFilePath);
      if (stat.size !== params.apkBuffer.length) {
        throw new Error('Stored APK byte size mismatch.');
      }

      const now = new Date().toISOString();
      const historyEntry: CorrectionHistoryEntry = {
        entryId: `hst_${crypto.randomUUID()}`,
        timestamp: now,
        actorType: 'user',
        actorIdentifier: user.email,
        action: 'SUBMITTED',
        message: `Initial APK submitted (${params.apkFileName.trim()}, v${metaCheck.sanitized.version}).`,
        version: metaCheck.sanitized.version,
        fileSizeBytes: params.apkBuffer.length,
      };

      const submission: SubmissionRecord = {
        submissionId,
        userId: user.userId,
        submittedByEmail: user.email,
        title: metaCheck.sanitized.title,
        description: metaCheck.sanitized.description,
        version: metaCheck.sanitized.version,
        privateStorageObjectPath: relativeObjectPath,
        fileSizeBytes: params.apkBuffer.length,
        sha256: apkCheck.inspection.sha256,
        apkInspection: apkCheck.inspection,
        reviewStatus: 'Pending',
        submittedAt: now,
        updatedAt: now,
        reviewedAt: null,
        reviewedBy: null,
        rejectionReason: null,
        latestCorrectionMessage: null,
        correctionHistory: [historyEntry],
        publishedGameId: null,
      };

      this.db.submissions.push(submission);

      this.createNotificationInternal({
        recipientUserId: user.userId,
        relatedSubmissionId: submissionId,
        title: `Submission Received: ${submission.title}`,
        message: `Your APK for "${submission.title}" (v${submission.version}) has been uploaded to private storage and is now Pending administrator review. It will appear in Apps once approved.`,
        type: 'SUBMISSION_RECEIVED',
      });

      this.saveDatabase();
      return submission;
    } catch (err) {
      if (fs.existsSync(absoluteFilePath)) {
        try {
          fs.unlinkSync(absoluteFilePath);
        } catch {
          // ignore
        }
      }
      if (err instanceof PlatformError) throw err;
      throw new PlatformError(
        'Failed to store uploaded APK. Please retry your submission.',
        500,
        'STORAGE_FAILURE',
      );
    }
  }

  public resubmitSubmission(params: {
    userSessionToken: string | undefined | null;
    submissionId: string;
    description?: unknown;
    version?: unknown;
    apkFileName: string;
    apkBuffer: Buffer;
  }): SubmissionRecord {
    const user = this.requireAuthenticatedUser(params.userSessionToken, true);
    const submission = this.db.submissions.find((s) => s.submissionId === params.submissionId);
    if (!submission) {
      throw new PlatformError('Submission not found.', 404, 'SUBMISSION_NOT_FOUND');
    }
    if (submission.userId !== user.userId) {
      throw new PlatformError(
        'Access denied: you can only modify your own submissions.',
        403,
        'FORBIDDEN',
      );
    }
    if (submission.reviewStatus !== 'Needs Changes') {
      throw new PlatformError(
        `This submission is currently "${submission.reviewStatus}" and cannot be resubmitted unless changes were requested.`,
        400,
        'INVALID_STATUS_TRANSITION',
      );
    }

    const metaCheck = validateGameMetadata({
      title: submission.title,
      description: params.description ?? submission.description,
      version: params.version ?? submission.version,
    });
    if (!metaCheck.valid || !metaCheck.sanitized) {
      throw new PlatformError(metaCheck.error || 'Invalid submission metadata.', 400, 'INVALID_METADATA');
    }

    const apkCheck = validateApkBinary(params.apkBuffer, params.apkFileName, this.maxApkSizeBytes);
    if (!apkCheck.valid || !apkCheck.inspection) {
      throw new PlatformError(apkCheck.error || 'Invalid replacement APK file.', 400, 'INVALID_APK');
    }

    const revisionNum = submission.correctionHistory.filter((h) => h.action === 'RESUBMITTED').length + 2;
    const objectFileName = `${submission.submissionId}-v${revisionNum}-${crypto.randomBytes(6).toString('hex')}.apk`;
    const relativeObjectPath = path.join('storage', 'submissions', objectFileName);
    const absoluteFilePath = path.join(this.dataDir, relativeObjectPath);

    fs.writeFileSync(absoluteFilePath, params.apkBuffer);

    const now = new Date().toISOString();
    submission.description = metaCheck.sanitized.description;
    submission.version = metaCheck.sanitized.version;
    submission.privateStorageObjectPath = relativeObjectPath;
    submission.fileSizeBytes = params.apkBuffer.length;
    submission.sha256 = apkCheck.inspection.sha256;
    submission.apkInspection = apkCheck.inspection;
    submission.reviewStatus = 'Pending';
    submission.updatedAt = now;

    submission.correctionHistory.push({
      entryId: `hst_${crypto.randomUUID()}`,
      timestamp: now,
      actorType: 'user',
      actorIdentifier: user.email,
      action: 'RESUBMITTED',
      message: `Uploaded corrected APK (${params.apkFileName.trim()}, v${submission.version}) and resubmitted for review.`,
      version: submission.version,
      fileSizeBytes: params.apkBuffer.length,
    });

    this.createNotificationInternal({
      recipientUserId: user.userId,
      relatedSubmissionId: submission.submissionId,
      title: `Resubmitted for Review: ${submission.title}`,
      message: `Your updated APK for "${submission.title}" (v${submission.version}) has been resubmitted and returned to the administrator Pending queue.`,
      type: 'SUBMISSION_RESUBMITTED',
    });

    this.saveDatabase();
    return submission;
  }

  public listUserSubmissions(userSessionToken: string | undefined | null): SubmissionRecord[] {
    const user = this.requireAuthenticatedUser(userSessionToken, false);
    return this.db.submissions
      .filter((s) => s.userId === user.userId)
      .sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
  }

  public getUserSubmissionById(
    userSessionToken: string | undefined | null,
    submissionId: string,
  ): SubmissionRecord {
    const user = this.requireAuthenticatedUser(userSessionToken, false);
    const submission = this.db.submissions.find((s) => s.submissionId === submissionId);
    if (!submission) {
      throw new PlatformError('Submission not found.', 404, 'SUBMISSION_NOT_FOUND');
    }
    if (submission.userId !== user.userId) {
      throw new PlatformError(
        'Access denied: you do not have permission to view another user’s submission.',
        403,
        'FORBIDDEN',
      );
    }
    return submission;
  }

  // ============================================================================
  // PANEL TAB 2: GAME APPROVALS, REJECTIONS & CORRECTION MESSAGES
  // ============================================================================

  public listSubmissionsForAdmin(
    adminToken: string | undefined | null,
    filter?: { status?: string; search?: string },
  ): SubmissionRecord[] {
    this.requireAdminSession(adminToken);
    const statusFilter = filter?.status && filter.status !== 'All' ? filter.status : null;
    const search = (filter?.search || '').trim().toLowerCase();

    return this.db.submissions
      .filter((s) => {
        if (statusFilter && s.reviewStatus !== statusFilter) return false;
        if (
          search &&
          !s.title.toLowerCase().includes(search) &&
          !s.submittedByEmail.toLowerCase().includes(search)
        ) {
          return false;
        }
        return true;
      })
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  public approveSubmissionByAdmin(params: {
    adminToken: string | undefined | null;
    submissionId: string;
    emailDelivered?: boolean;
  }): { submission: SubmissionRecord; game: GameRecord } {
    const admin = this.requireAdminSession(params.adminToken);
    const submission = this.db.submissions.find((s) => s.submissionId === params.submissionId);
    if (!submission) {
      throw new PlatformError('Submission not found.', 404, 'SUBMISSION_NOT_FOUND');
    }

    if (submission.reviewStatus === 'Approved') {
      throw new PlatformError(
        'This submission has already been approved and published.',
        409,
        'ALREADY_APPROVED',
      );
    }

    const sourceApkAbsPath = path.join(this.dataDir, submission.privateStorageObjectPath);
    if (!fs.existsSync(sourceApkAbsPath)) {
      throw new PlatformError(
        'Cannot approve submission because the stored APK file is missing.',
        400,
        'MISSING_APK_FILE',
      );
    }

    const now = new Date().toISOString();

    // Copy APK to permanent games storage object path so submission evidence and game storage are cleanly managed
    let game = this.db.games.find((g) => g.sourceSubmissionId === submission.submissionId);
    const gameId = game ? game.gameId : `game_${crypto.randomUUID()}`;
    const gameObjectFileName = `${gameId}-${crypto.randomBytes(6).toString('hex')}.apk`;
    const gameRelativePath = path.join('storage', 'games', gameObjectFileName);
    const gameAbsPath = path.join(this.dataDir, gameRelativePath);

    fs.copyFileSync(sourceApkAbsPath, gameAbsPath);

    if (!game) {
      game = {
        gameId,
        title: submission.title,
        description: submission.description,
        version: submission.version,
        storageObjectPath: gameRelativePath,
        fileSizeBytes: submission.fileSizeBytes,
        sha256: submission.sha256,
        apkInspection: submission.apkInspection,
        publicationStatus: 'Published',
        createdAt: now,
        publishedAt: now,
        updatedAt: now,
        publishedBy: admin.adminId,
        sourceSubmissionId: submission.submissionId,
      };
      this.db.games.push(game);
    } else {
      const oldGamePath = game.storageObjectPath;
      game.title = submission.title;
      game.description = submission.description;
      game.version = submission.version;
      game.storageObjectPath = gameRelativePath;
      game.fileSizeBytes = submission.fileSizeBytes;
      game.sha256 = submission.sha256;
      game.apkInspection = submission.apkInspection;
      game.publicationStatus = 'Published';
      game.publishedAt = now;
      game.updatedAt = now;
      game.publishedBy = admin.adminId;
      if (oldGamePath !== gameRelativePath) {
        this.cleanupStorageFileIfUnreferenced(oldGamePath);
      }
    }

    submission.reviewStatus = 'Approved';
    submission.reviewedAt = now;
    submission.reviewedBy = admin.adminId;
    submission.updatedAt = now;
    submission.rejectionReason = null;
    submission.publishedGameId = game.gameId;

    const approvalMsg = `Your game "${submission.title}" (v${submission.version}) has been approved by the administrator and is now live in Apps.`;
    submission.correctionHistory.push({
      entryId: `hst_${crypto.randomUUID()}`,
      timestamp: now,
      actorType: 'admin',
      actorIdentifier: admin.adminId,
      action: 'APPROVED',
      message: approvalMsg,
      version: submission.version,
      emailDeliveryStatus: params.emailDelivered ? 'sent_via_gmail' : 'internal_only',
    });

    this.db.reviewMessages.push({
      messageId: `msg_${crypto.randomUUID()}`,
      submissionId: submission.submissionId,
      recipientUserId: submission.userId,
      recipientEmail: submission.submittedByEmail,
      administratorId: admin.adminId,
      rawMessage: approvalMsg,
      formattedMessage: approvalMsg,
      statusTransition: 'Approved',
      createdAt: now,
      emailDeliveryStatus: params.emailDelivered ? 'sent_via_gmail' : 'internal_only',
    });

    this.createNotificationInternal({
      recipientUserId: submission.userId,
      relatedSubmissionId: submission.submissionId,
      title: `Game Approved: ${submission.title}`,
      message: approvalMsg,
      type: 'SUBMISSION_APPROVED',
      emailDelivered: Boolean(params.emailDelivered),
    });

    this.recordAuditLog({
      administratorId: admin.adminId,
      action: 'SUBMISSION_APPROVED',
      targetId: submission.submissionId,
      targetTitle: submission.title,
      details: `Approved submission from ${submission.submittedByEmail} and published as ${game.gameId}.`,
    });

    this.saveDatabase();
    return { submission, game };
  }

  public rejectSubmissionByAdmin(params: {
    adminToken: string | undefined | null;
    submissionId: string;
    reason?: unknown;
    emailDelivered?: boolean;
  }): SubmissionRecord {
    const admin = this.requireAdminSession(params.adminToken);
    const submission = this.db.submissions.find((s) => s.submissionId === params.submissionId);
    if (!submission) {
      throw new PlatformError('Submission not found.', 404, 'SUBMISSION_NOT_FOUND');
    }

    const now = new Date().toISOString();
    const cleanReason =
      typeof params.reason === 'string' && params.reason.trim().length > 0
        ? params.reason.trim().slice(0, 2000)
        : null;

    submission.reviewStatus = 'Rejected';
    submission.rejectionReason = cleanReason;
    submission.reviewedAt = now;
    submission.reviewedBy = admin.adminId;
    submission.updatedAt = now;

    // Ensure any linked game is unpublished
    if (submission.publishedGameId) {
      const linkedGame = this.db.games.find((g) => g.gameId === submission.publishedGameId);
      if (linkedGame) {
        linkedGame.publicationStatus = 'Unpublished';
        linkedGame.updatedAt = now;
      }
    }

    const rejectNotice = cleanReason
      ? `Your submission "${submission.title}" was rejected by the administrator. Reason: ${cleanReason}`
      : `Your submission "${submission.title}" was rejected by the administrator.`;

    submission.correctionHistory.push({
      entryId: `hst_${crypto.randomUUID()}`,
      timestamp: now,
      actorType: 'admin',
      actorIdentifier: admin.adminId,
      action: 'REJECTED',
      message: rejectNotice,
      version: submission.version,
      emailDeliveryStatus: params.emailDelivered ? 'sent_via_gmail' : 'internal_only',
    });

    this.db.reviewMessages.push({
      messageId: `msg_${crypto.randomUUID()}`,
      submissionId: submission.submissionId,
      recipientUserId: submission.userId,
      recipientEmail: submission.submittedByEmail,
      administratorId: admin.adminId,
      rawMessage: cleanReason || 'Rejected by administrator.',
      formattedMessage: rejectNotice,
      statusTransition: 'Rejected',
      createdAt: now,
      emailDeliveryStatus: params.emailDelivered ? 'sent_via_gmail' : 'internal_only',
    });

    this.createNotificationInternal({
      recipientUserId: submission.userId,
      relatedSubmissionId: submission.submissionId,
      title: `Submission Rejected: ${submission.title}`,
      message: rejectNotice,
      type: 'SUBMISSION_REJECTED',
      emailDelivered: Boolean(params.emailDelivered),
    });

    this.recordAuditLog({
      administratorId: admin.adminId,
      action: 'SUBMISSION_REJECTED',
      targetId: submission.submissionId,
      targetTitle: submission.title,
      details: `Rejected submission from ${submission.submittedByEmail}.${cleanReason ? ` Reason: ${cleanReason}` : ''}`,
    });

    this.saveDatabase();
    return submission;
  }

  public requestChangesByAdmin(params: {
    adminToken: string | undefined | null;
    submissionId: string;
    message: unknown;
    emailDelivered?: boolean;
  }): { submission: SubmissionRecord; reviewMessage: ReviewMessageRecord } {
    const admin = this.requireAdminSession(params.adminToken);
    const submission = this.db.submissions.find((s) => s.submissionId === params.submissionId);
    if (!submission) {
      throw new PlatformError('Submission not found.', 404, 'SUBMISSION_NOT_FOUND');
    }

    const rawMsg = typeof params.message === 'string' ? params.message.trim() : '';
    if (!rawMsg) {
      throw new PlatformError(
        'Correction message is required when requesting changes.',
        400,
        'EMPTY_MESSAGE',
      );
    }
    if (rawMsg.length > 4000) {
      throw new PlatformError('Correction message cannot exceed 4000 characters.', 400, 'MESSAGE_TOO_LONG');
    }

    const formattedMessage = rawMsg.startsWith('Your game has the following issues')
      ? rawMsg
      : `Your game has the following issues that need to be corrected: ${rawMsg}. Please fix these issues and submit the updated APK for review.`;

    const now = new Date().toISOString();
    submission.reviewStatus = 'Needs Changes';
    submission.latestCorrectionMessage = formattedMessage;
    submission.reviewedAt = now;
    submission.reviewedBy = admin.adminId;
    submission.updatedAt = now;

    const deliveryStatus: CorrectionHistoryEntry['emailDeliveryStatus'] = params.emailDelivered
      ? 'sent_via_gmail'
      : 'internal_only';

    submission.correctionHistory.push({
      entryId: `hst_${crypto.randomUUID()}`,
      timestamp: now,
      actorType: 'admin',
      actorIdentifier: admin.adminId,
      action: 'CHANGES_REQUESTED',
      message: rawMsg,
      formattedNotice: formattedMessage,
      version: submission.version,
      emailDeliveryStatus: deliveryStatus,
    });

    const reviewMessage: ReviewMessageRecord = {
      messageId: `msg_${crypto.randomUUID()}`,
      submissionId: submission.submissionId,
      recipientUserId: submission.userId,
      recipientEmail: submission.submittedByEmail,
      administratorId: admin.adminId,
      rawMessage: rawMsg,
      formattedMessage,
      statusTransition: 'Needs Changes',
      createdAt: now,
      emailDeliveryStatus: deliveryStatus,
    };

    this.db.reviewMessages.push(reviewMessage);

    this.createNotificationInternal({
      recipientUserId: submission.userId,
      relatedSubmissionId: submission.submissionId,
      title: `Changes Requested: ${submission.title}`,
      message: formattedMessage,
      type: 'CHANGES_REQUESTED',
      emailDelivered: Boolean(params.emailDelivered),
    });

    this.recordAuditLog({
      administratorId: admin.adminId,
      action: 'SUBMISSION_CHANGES_REQUESTED',
      targetId: submission.submissionId,
      targetTitle: submission.title,
      details: `Requested changes from ${submission.submittedByEmail}: "${rawMsg.slice(0, 120)}"`,
    });

    this.saveDatabase();
    return { submission, reviewMessage };
  }

  // ============================================================================
  // NOTIFICATIONS
  // ============================================================================

  private createNotificationInternal(params: {
    recipientUserId: string;
    relatedSubmissionId: string | null;
    title: string;
    message: string;
    type: NotificationType;
    emailDelivered?: boolean;
  }): NotificationRecord {
    const notification: NotificationRecord = {
      notificationId: `ntf_${crypto.randomUUID()}`,
      recipientUserId: params.recipientUserId,
      relatedSubmissionId: params.relatedSubmissionId,
      title: params.title,
      message: params.message,
      type: params.type,
      createdAt: new Date().toISOString(),
      readAt: null,
      emailDelivered: params.emailDelivered,
    };
    this.db.notifications.push(notification);
    return notification;
  }

  public listUserNotifications(userSessionToken: string | undefined | null): NotificationRecord[] {
    const user = this.requireAuthenticatedUser(userSessionToken, false);
    return this.db.notifications
      .filter((n) => n.recipientUserId === user.userId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  public markNotificationRead(
    userSessionToken: string | undefined | null,
    notificationId: string,
  ): NotificationRecord {
    const user = this.requireAuthenticatedUser(userSessionToken, false);
    const notif = this.db.notifications.find((n) => n.notificationId === notificationId);
    if (!notif) {
      throw new PlatformError('Notification not found.', 404, 'NOTIFICATION_NOT_FOUND');
    }
    if (notif.recipientUserId !== user.userId) {
      throw new PlatformError('Access denied.', 403, 'FORBIDDEN');
    }
    if (!notif.readAt) {
      notif.readAt = new Date().toISOString();
      this.saveDatabase();
    }
    return notif;
  }

  public markAllNotificationsRead(userSessionToken: string | undefined | null): number {
    const user = this.requireAuthenticatedUser(userSessionToken, false);
    const now = new Date().toISOString();
    let count = 0;
    for (const notif of this.db.notifications) {
      if (notif.recipientUserId === user.userId && !notif.readAt) {
        notif.readAt = now;
        count += 1;
      }
    }
    if (count > 0) {
      this.saveDatabase();
    }
    return count;
  }

  // ============================================================================
  // AUTHORIZED SHORT-LIVED APK DOWNLOAD TOKENS
  // ============================================================================

  public createGameDownloadTicket(params: {
    userSessionToken: string | undefined | null;
    gameId: string;
  }): { downloadToken: string; fileName: string; fileSizeBytes: number; gameId: string } {
    const user = this.requireAuthenticatedUser(params.userSessionToken, true);
    const game = this.db.games.find((g) => g.gameId === params.gameId);
    if (!game || game.publicationStatus !== 'Published') {
      throw new PlatformError(
        'This game is no longer published or available for download.',
        404,
        'GAME_UNAVAILABLE',
      );
    }

    const absPath = path.join(this.dataDir, game.storageObjectPath);
    if (!fs.existsSync(absPath)) {
      throw new PlatformError(
        'The APK file for this game is unavailable on the storage server.',
        404,
        'APK_FILE_MISSING',
      );
    }

    const downloadFilename = sanitizeDownloadFilename(`${game.title}-${game.version}`);
    const token = `dl_game_${crypto.randomBytes(24).toString('hex')}`;
    this.downloadTickets.set(token, {
      token,
      kind: 'game',
      targetId: game.gameId,
      filePath: absPath,
      downloadFilename,
      fileSizeBytes: game.fileSizeBytes,
      issuedTo: user.userId,
      expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes
    });

    return {
      downloadToken: token,
      fileName: downloadFilename,
      fileSizeBytes: game.fileSizeBytes,
      gameId: game.gameId,
    };
  }

  public createSubmissionDownloadTicketForAdmin(params: {
    adminToken: string | undefined | null;
    submissionId: string;
  }): { downloadToken: string; fileName: string; fileSizeBytes: number; submissionId: string } {
    const admin = this.requireAdminSession(params.adminToken);
    const submission = this.db.submissions.find((s) => s.submissionId === params.submissionId);
    if (!submission) {
      throw new PlatformError('Submission not found.', 404, 'SUBMISSION_NOT_FOUND');
    }

    const absPath = path.join(this.dataDir, submission.privateStorageObjectPath);
    if (!fs.existsSync(absPath)) {
      throw new PlatformError('The submitted APK file is missing from private storage.', 404, 'APK_FILE_MISSING');
    }

    const downloadFilename = sanitizeDownloadFilename(`review-${submission.title}-${submission.version}`);
    const token = `dl_sub_${crypto.randomBytes(24).toString('hex')}`;
    this.downloadTickets.set(token, {
      token,
      kind: 'submission',
      targetId: submission.submissionId,
      filePath: absPath,
      downloadFilename,
      fileSizeBytes: submission.fileSizeBytes,
      issuedTo: admin.adminId,
      expiresAt: Date.now() + 5 * 60 * 1000,
    });

    return {
      downloadToken: token,
      fileName: downloadFilename,
      fileSizeBytes: submission.fileSizeBytes,
      submissionId: submission.submissionId,
    };
  }

  public resolveDownloadTicket(
    token: string | undefined | null,
    expectedKind: 'game' | 'submission',
    expectedTargetId: string,
  ): DownloadTicket {
    if (!token) {
      throw new PlatformError('Download authorization token is required.', 401, 'DOWNLOAD_UNAUTHORIZED');
    }
    const ticket = this.downloadTickets.get(token);
    if (!ticket) {
      throw new PlatformError('Invalid or expired download authorization link.', 401, 'DOWNLOAD_UNAUTHORIZED');
    }
    if (Date.now() > ticket.expiresAt) {
      this.downloadTickets.delete(token);
      throw new PlatformError('Download authorization link has expired.', 401, 'DOWNLOAD_EXPIRED');
    }
    if (ticket.kind !== expectedKind || ticket.targetId !== expectedTargetId) {
      throw new PlatformError('Download token does not match the requested resource.', 403, 'DOWNLOAD_FORBIDDEN');
    }

    // Re-verify publication status if downloading a public game
    if (ticket.kind === 'game') {
      const game = this.db.games.find((g) => g.gameId === ticket.targetId);
      if (!game || game.publicationStatus !== 'Published') {
        this.downloadTickets.delete(token);
        throw new PlatformError(
          'This game has been unpublished or removed and is no longer available for download.',
          404,
          'GAME_UNAVAILABLE',
        );
      }
    }

    if (!fs.existsSync(ticket.filePath)) {
      throw new PlatformError('Stored APK file could not be found.', 404, 'APK_FILE_MISSING');
    }

    return ticket;
  }
}
