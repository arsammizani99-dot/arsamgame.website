import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { PlatformStore, PlatformError } from './store';
import { buildValidApkBuffer } from '../utils/apkValidator';

function createTempStore() {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'apkforge-test-'));
  const store = new PlatformStore({
    dataDir: tempDir,
    adminPassword: 'arsam27',
    maxApkSizeBytes: 5 * 1024 * 1024, // 5 MB for test
  });
  return {
    store,
    tempDir,
    cleanup: () => {
      fs.rmSync(tempDir, { recursive: true, force: true });
    },
  };
}

test('Initial store is completely empty and returns accurate zero counts (TEST 1, TEST 38)', () => {
  const { store, cleanup } = createTempStore();
  try {
    assert.equal(store.listPublicGames().length, 0);
    const stats = store.getPlatformStats();
    assert.deepEqual(stats, {
      totalPublishedGames: 0,
      totalUnpublishedGames: 0,
      pendingSubmissions: 0,
      approvedSubmissions: 0,
      rejectedSubmissions: 0,
      needsChangesSubmissions: 0,
    });
  } finally {
    cleanup();
  }
});

test('User registration, email verification enforcement, sign in, and sign out (TEST 2, 3, 4, 5)', () => {
  const { store, cleanup } = createTempStore();
  try {
    const reg = store.registerUser({ email: 'player@example.com', password: 'password123' });
    assert.equal(reg.user.email, 'player@example.com');
    assert.equal(reg.user.emailVerified, false);

    // Unverified user cannot submit an APK (TEST 4)
    const apkBuf = buildValidApkBuffer({ title: 'Star Hopper' });
    assert.throws(
      () =>
        store.createSubmission({
          userSessionToken: reg.sessionToken,
          title: 'Star Hopper',
          description: 'An exciting space platformer built for Android.',
          version: '1.0.0',
          apkFileName: 'star-hopper.apk',
          apkBuffer: apkBuf,
        }),
      (err: unknown) => err instanceof PlatformError && err.code === 'EMAIL_NOT_VERIFIED',
    );

    // Verify email
    const verified = store.verifyUserEmail(reg.user.userId, reg.verificationToken);
    assert.equal(verified.emailVerified, true);

    // Sign out and sign in again (TEST 5)
    store.logoutUser(reg.sessionToken);
    assert.equal(store.getUserBySessionToken(reg.sessionToken), null);

    const login = store.loginUser({ email: 'player@example.com', password: 'password123' });
    assert.equal(login.user.emailVerified, true);
    assert.ok(login.sessionToken);
  } finally {
    cleanup();
  }
});

test('Admin password verification, rate limiting, session locking, and direct publish (TEST 9, 10, 11, 14, 15, 29)', () => {
  const { store, cleanup } = createTempStore();
  try {
    // Unauthorized user cannot access admin APIs (TEST 9)
    assert.throws(
      () => store.listSubmissionsForAdmin('invalid_token'),
      (err: unknown) => err instanceof PlatformError && err.statusCode === 401,
    );

    // Wrong password fails
    assert.throws(
      () => store.verifyAdminPassword('wrongpass', 'ip1'),
      (err: unknown) => err instanceof PlatformError && err.code === 'INVALID_ADMIN_PASSWORD',
    );

    // Unlock Panel with arsam27 (TEST 10)
    const { adminToken } = store.verifyAdminPassword('arsam27', 'ip2');
    assert.ok(adminToken);

    // Direct game publish by admin (TEST 14, 15)
    const apkBuf = buildValidApkBuffer({ title: 'Admin Racer', versionName: '1.4.0' });
    const published = store.publishGameByAdmin({
      adminToken,
      title: 'Admin Racer',
      description: 'Official administrator published Android racing game.',
      version: '1.4.0',
      apkFileName: 'admin-racer.apk',
      apkBuffer: apkBuf,
    });
    assert.equal(published.publicationStatus, 'Published');
    assert.equal(store.listPublicGames().length, 1);

    // Unpublish prevents public listing and downloads (TEST 29)
    store.setGamePublicationStatus({
      adminToken,
      gameId: published.gameId,
      status: 'Unpublished',
    });
    assert.equal(store.listPublicGames().length, 0);

    // Republish restores public listing
    store.setGamePublicationStatus({
      adminToken,
      gameId: published.gameId,
      status: 'Published',
    });
    assert.equal(store.listPublicGames().length, 1);

    // Leaving Panel locks admin session and requires password again (TEST 11)
    store.lockAdminSession(adminToken);
    assert.throws(
      () => store.listSubmissionsForAdmin(adminToken),
      (err: unknown) => err instanceof PlatformError && err.statusCode === 401,
    );
  } finally {
    cleanup();
  }
});

test('Full submission lifecycle: submit, request changes, resubmit, approve once, reject, and owner isolation (TEST 6, 7, 8, 16, 17, 18, 19, 20, 21, 22, 26, 27, 28, 30)', () => {
  const { store, tempDir, cleanup } = createTempStore();
  try {
    // Create User A and User B
    const userA = store.registerUser({ email: 'deva@example.com', password: 'password123' });
    store.verifyUserEmail(userA.user.userId, userA.verificationToken);

    const userB = store.registerUser({ email: 'devb@example.com', password: 'password123' });
    store.verifyUserEmail(userB.user.userId, userB.verificationToken);

    // User A submits a valid APK (TEST 6, 7)
    const apkV1 = buildValidApkBuffer({ title: 'Dungeon Tactics', versionName: '0.9.0' });
    const sub = store.createSubmission({
      userSessionToken: userA.sessionToken,
      title: 'Dungeon Tactics',
      description: 'Turn-based tactical dungeon crawler for Android devices.',
      version: '0.9.0',
      apkFileName: 'dungeon-tactics-0.9.apk',
      apkBuffer: apkV1,
    });
    assert.equal(sub.reviewStatus, 'Pending');
    assert.equal(store.listPublicGames().length, 0); // Pending does not appear in Apps

    // User B cannot access User A's submission details (TEST 22)
    assert.throws(
      () => store.getUserSubmissionById(userB.sessionToken, sub.submissionId),
      (err: unknown) => err instanceof PlatformError && err.statusCode === 403,
    );

    // Admin unlocks Panel and sees submission in queue (TEST 8)
    const { adminToken } = store.verifyAdminPassword('arsam27', 'ip_workflow');
    const queue = store.listSubmissionsForAdmin(adminToken, { status: 'Pending' });
    assert.equal(queue.length, 1);
    assert.equal(queue[0].submissionId, sub.submissionId);

    // Admin requests changes with custom message (TEST 18, 19)
    const reqChanges = store.requestChangesByAdmin({
      adminToken,
      submissionId: sub.submissionId,
      message: 'Touch controls overlap the inventory bar on 16:9 phones',
    });
    assert.equal(reqChanges.submission.reviewStatus, 'Needs Changes');
    assert.match(
      reqChanges.submission.latestCorrectionMessage || '',
      /Your game has the following issues that need to be corrected: Touch controls overlap the inventory bar on 16:9 phones\. Please fix these issues and submit the updated APK for review\./,
    );

    // User A sees notification and correction message
    const userNotifs = store.listUserNotifications(userA.sessionToken);
    assert.ok(userNotifs.some((n) => n.type === 'CHANGES_REQUESTED'));

    // User A replaces APK and resubmits (TEST 20, 21)
    const apkV2 = buildValidApkBuffer({ title: 'Dungeon Tactics', versionName: '1.0.0' });
    const resubmitted = store.resubmitSubmission({
      userSessionToken: userA.sessionToken,
      submissionId: sub.submissionId,
      description: 'Turn-based tactical dungeon crawler with fixed 16:9 HUD layout.',
      version: '1.0.0',
      apkFileName: 'dungeon-tactics-1.0.apk',
      apkBuffer: apkV2,
    });
    assert.equal(resubmitted.reviewStatus, 'Pending');
    assert.equal(resubmitted.version, '1.0.0');
    assert.equal(store.listPublicGames().length, 0);

    // Admin approves the resubmitted game (TEST 16)
    const approved = store.approveSubmissionByAdmin({
      adminToken,
      submissionId: sub.submissionId,
    });
    assert.equal(approved.submission.reviewStatus, 'Approved');
    assert.equal(approved.game.publicationStatus, 'Published');
    assert.equal(store.listPublicGames().length, 1);

    // Clicking Approve a second time is rejected to prevent duplicates (TEST 16)
    assert.throws(
      () =>
        store.approveSubmissionByAdmin({
          adminToken,
          submissionId: sub.submissionId,
        }),
      (err: unknown) => err instanceof PlatformError && err.code === 'ALREADY_APPROVED',
    );

    // Unauthenticated user cannot download game (TEST 2, 26)
    assert.throws(
      () => store.createGameDownloadTicket({ userSessionToken: null, gameId: approved.game.gameId }),
      (err: unknown) => err instanceof PlatformError && err.statusCode === 401,
    );

    // Authenticated verified user can download published APK with .apk extension (TEST 27, 28)
    const ticket = store.createGameDownloadTicket({
      userSessionToken: userB.sessionToken,
      gameId: approved.game.gameId,
    });
    assert.ok(ticket.fileName.endsWith('.apk'));
    const resolved = store.resolveDownloadTicket(ticket.downloadToken, 'game', approved.game.gameId);
    assert.equal(fs.readFileSync(resolved.filePath).length, apkV2.length);

    // Persistence across fresh store instantiation (simulating server/browser restart, TEST 30, 31)
    const reloadedStore = new PlatformStore({ dataDir: tempDir, adminPassword: 'arsam27' });
    assert.equal(reloadedStore.listPublicGames().length, 1);
    assert.equal(reloadedStore.listPublicGames()[0].title, 'Dungeon Tactics');
  } finally {
    cleanup();
  }
});
