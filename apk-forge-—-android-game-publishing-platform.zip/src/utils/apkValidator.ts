import crypto from 'node:crypto';
import type { ApkInspectionSummary } from '../types/models';

export const MAX_TITLE_LENGTH = 120;
export const MIN_TITLE_LENGTH = 2;
export const MAX_DESCRIPTION_LENGTH = 5000;
export const MIN_DESCRIPTION_LENGTH = 10;
export const MAX_VERSION_LENGTH = 40;
export const DEFAULT_MAX_APK_SIZE_BYTES = 150 * 1024 * 1024; // 150 MB

const FORBIDDEN_EXTENSIONS = [
  '.zip',
  '.html',
  '.htm',
  '.exe',
  '.msi',
  '.aab',
  '.ipa',
  '.dmg',
  '.tar',
  '.gz',
  '.rar',
  '.7z',
  '.js',
  '.sh',
  '.bat',
];

export interface MetadataValidationResult {
  valid: boolean;
  error?: string;
  sanitized?: {
    title: string;
    description: string;
    version: string;
  };
}

export function validateGameMetadata(input: {
  title?: unknown;
  description?: unknown;
  version?: unknown;
}): MetadataValidationResult {
  const rawTitle = typeof input.title === 'string' ? input.title.trim().replace(/\s+/g, ' ') : '';
  const rawDescription = typeof input.description === 'string' ? input.description.trim() : '';
  const rawVersion = typeof input.version === 'string' ? input.version.trim() : '';

  if (!rawTitle) {
    return { valid: false, error: 'Game title is required and cannot be empty.' };
  }
  if (rawTitle.length < MIN_TITLE_LENGTH) {
    return {
      valid: false,
      error: `Game title must be at least ${MIN_TITLE_LENGTH} characters long.`,
    };
  }
  if (rawTitle.length > MAX_TITLE_LENGTH) {
    return {
      valid: false,
      error: `Game title cannot exceed ${MAX_TITLE_LENGTH} characters (currently ${rawTitle.length}).`,
    };
  }

  if (!rawDescription) {
    return { valid: false, error: 'Game description is required and cannot be empty.' };
  }
  if (rawDescription.length < MIN_DESCRIPTION_LENGTH) {
    return {
      valid: false,
      error: `Game description must be at least ${MIN_DESCRIPTION_LENGTH} characters long.`,
    };
  }
  if (rawDescription.length > MAX_DESCRIPTION_LENGTH) {
    return {
      valid: false,
      error: `Game description cannot exceed ${MAX_DESCRIPTION_LENGTH} characters (currently ${rawDescription.length}).`,
    };
  }

  if (rawVersion.length > MAX_VERSION_LENGTH) {
    return {
      valid: false,
      error: `Version number cannot exceed ${MAX_VERSION_LENGTH} characters.`,
    };
  }

  if (rawVersion && !/^[a-zA-Z0-9._\-+]+$/.test(rawVersion)) {
    return {
      valid: false,
      error: 'Version number may only contain letters, numbers, dots, hyphens, and underscores.',
    };
  }

  return {
    valid: true,
    sanitized: {
      title: rawTitle,
      description: rawDescription,
      version: rawVersion || '1.0.0',
    },
  };
}

export function validateApkFilename(fileName: string): { valid: boolean; error?: string } {
  const trimmed = (fileName || '').trim();
  if (!trimmed) {
    return { valid: false, error: 'No file selected. Please select a valid .apk package file.' };
  }

  const lower = trimmed.toLowerCase();
  for (const ext of FORBIDDEN_EXTENSIONS) {
    if (lower.endsWith(ext)) {
      return {
        valid: false,
        error: `File type "${ext.toUpperCase()}" is not permitted. Only Android APK (.apk) package files are allowed.`,
      };
    }
  }

  if (!lower.endsWith('.apk')) {
    return {
      valid: false,
      error: 'Invalid file extension. Only files ending in .apk are permitted as game packages.',
    };
  }

  const baseName = trimmed.slice(0, -4).trim();
  if (!baseName) {
    return {
      valid: false,
      error: 'Invalid APK filename.',
    };
  }

  return { valid: true };
}

export interface ApkBinaryValidationResult {
  valid: boolean;
  error?: string;
  inspection?: ApkInspectionSummary;
}

/**
 * Inspects actual uploaded APK binary bytes without ever executing the file.
 * Verifies:
 * 1. Filename ends in .apk
 * 2. Size > 0 and <= maxBytes
 * 3. ZIP Local File Header signature (PK\x03\x04)
 * 4. Presence of ZIP Central Directory / local entries including AndroidManifest.xml
 */
export function validateApkBinary(
  buffer: Buffer,
  fileName: string,
  maxBytes: number = DEFAULT_MAX_APK_SIZE_BYTES,
): ApkBinaryValidationResult {
  const nameCheck = validateApkFilename(fileName);
  if (!nameCheck.valid) {
    return { valid: false, error: nameCheck.error };
  }

  if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
    return { valid: false, error: 'Uploaded APK file is empty (0 bytes).' };
  }

  if (buffer.length > maxBytes) {
    const maxMb = (maxBytes / (1024 * 1024)).toFixed(1);
    const actualMb = (buffer.length / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `APK file is too large (${actualMb} MB). Maximum permitted size is ${maxMb} MB.`,
    };
  }

  if (buffer.length < 30) {
    return {
      valid: false,
      error: 'Invalid APK structure: file is smaller than the minimum Android package archive header.',
    };
  }

  // Check ZIP Local File Header magic bytes: 0x50 0x4b 0x03 0x04 ("PK\x03\x04")
  const magic = buffer.readUInt32LE(0);
  if (magic !== 0x04034b50) {
    return {
      valid: false,
      error:
        'Invalid APK archive structure: file does not begin with a valid Android ZIP/APK package header (PK\\x03\\x04).',
    };
  }

  // Parse ZIP local file headers & central directory headers to list package entries safely
  const entries = extractZipEntries(buffer);
  if (entries.length === 0) {
    return {
      valid: false,
      error: 'Invalid APK archive structure: unable to read package entries from archive.',
    };
  }

  const hasAndroidManifest = entries.some(
    (e) => e === 'AndroidManifest.xml' || e.endsWith('/AndroidManifest.xml'),
  );
  const hasClassesDex = entries.some((e) => /^classes\d*\.dex$/.test(e) || e.endsWith('/classes.dex'));
  const hasResourcesArsc = entries.some((e) => e === 'resources.arsc' || e.endsWith('/resources.arsc'));

  if (!hasAndroidManifest) {
    return {
      valid: false,
      error:
        'Invalid Android APK package: archive does not contain a required AndroidManifest.xml entry.',
    };
  }

  const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

  return {
    valid: true,
    inspection: {
      fileName: fileName.trim(),
      fileSizeBytes: buffer.length,
      sha256,
      hasAndroidManifest,
      hasClassesDex,
      hasResourcesArsc,
      entryCount: entries.length,
      entriesPreview: entries.slice(0, 12),
      formatVerifiedAt: new Date().toISOString(),
    },
  };
}

function extractZipEntries(buffer: Buffer): string[] {
  const entriesSet = new Set<string>();

  // 1. Scan Local File Headers (0x04034b50) sequentially from start
  let offset = 0;
  while (offset + 30 <= buffer.length) {
    const sig = buffer.readUInt32LE(offset);
    if (sig !== 0x04034b50) {
      break;
    }
    const flags = buffer.readUInt16LE(offset + 6);
    const compressedSize = buffer.readUInt32LE(offset + 18);
    const fileNameLen = buffer.readUInt16LE(offset + 26);
    const extraLen = buffer.readUInt16LE(offset + 28);
    const nameStart = offset + 30;
    const nameEnd = nameStart + fileNameLen;
    if (nameEnd > buffer.length) break;

    const entryName = buffer.subarray(nameStart, nameEnd).toString('utf8');
    if (entryName) {
      entriesSet.add(entryName);
    }

    // If bit 3 (data descriptor) is set and compressedSize is 0, stop sequential walk and scan central directory
    if ((flags & 0x08) !== 0 && compressedSize === 0) {
      break;
    }
    offset = nameEnd + extraLen + compressedSize;
  }

  // 2. Also scan Central Directory File Headers (0x02014b50) in the tail of the buffer (last 128 KB)
  const scanStart = Math.max(0, buffer.length - 131072);
  for (let i = scanStart; i <= buffer.length - 46; i++) {
    if (
      buffer[i] === 0x50 &&
      buffer[i + 1] === 0x4b &&
      buffer[i + 2] === 0x01 &&
      buffer[i + 3] === 0x02
    ) {
      const fileNameLen = buffer.readUInt16LE(i + 28);
      const extraLen = buffer.readUInt16LE(i + 30);
      const commentLen = buffer.readUInt16LE(i + 32);
      const nameStart = i + 46;
      const nameEnd = nameStart + fileNameLen;
      if (nameEnd <= buffer.length && fileNameLen > 0 && fileNameLen < 512) {
        const entryName = buffer.subarray(nameStart, nameEnd).toString('utf8');
        if (entryName && !entryName.includes('\u0000')) {
          entriesSet.add(entryName);
        }
        i = nameEnd + extraLen + commentLen - 1;
      }
    }
  }

  return Array.from(entriesSet);
}

/**
 * Builds a valid, standards-compliant Android APK archive buffer containing
 * AndroidManifest.xml, classes.dex, resources.arsc, and META-INF/MANIFEST.MF.
 */
export function buildValidApkBuffer(options?: {
  packageName?: string;
  versionName?: string;
  title?: string;
  extraPayloadBytes?: number;
}): Buffer {
  const pkg = options?.packageName || 'com.apkforge.game';
  const ver = options?.versionName || '1.0.0';
  const title = options?.title || 'APK Forge Game';

  const files: Array<{ name: string; content: Buffer }> = [
    {
      name: 'AndroidManifest.xml',
      content: Buffer.from(
        `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="${pkg}" android:versionName="${ver}">\n  <application android:label="${title}" />\n</manifest>`,
        'utf8',
      ),
    },
    {
      name: 'classes.dex',
      content: Buffer.from(`dex\n035\x00${pkg}:${title}:${ver}:bytecode-payload`, 'utf8'),
    },
    {
      name: 'resources.arsc',
      content: Buffer.from(`ARSC\x02\x00\x0c\x00${title}:${ver}`, 'utf8'),
    },
    {
      name: 'META-INF/MANIFEST.MF',
      content: Buffer.from(
        `Manifest-Version: 1.0\r\nCreated-By: APK Forge Builder\r\nPackage-Name: ${pkg}\r\n\r\n`,
        'utf8',
      ),
    },
  ];

  if (options?.extraPayloadBytes && options.extraPayloadBytes > 0) {
    files.push({
      name: 'assets/level_data.bin',
      content: Buffer.alloc(options.extraPayloadBytes, 0x41),
    });
  }

  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBuf = Buffer.from(file.name, 'utf8');
    const dataBuf = file.content;
    const crc = crc32(dataBuf);

    const localHeader = Buffer.alloc(30 + nameBuf.length);
    localHeader.writeUInt32LE(0x04034b50, 0); // signature
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0, 6); // flags
    localHeader.writeUInt16LE(0, 8); // compression (0 = stored)
    localHeader.writeUInt16LE(0, 10); // mod time
    localHeader.writeUInt16LE(0, 12); // mod date
    localHeader.writeUInt32LE(crc, 14); // crc32
    localHeader.writeUInt32LE(dataBuf.length, 18); // compressed size
    localHeader.writeUInt32LE(dataBuf.length, 22); // uncompressed size
    localHeader.writeUInt16LE(nameBuf.length, 26); // file name length
    localHeader.writeUInt16LE(0, 28); // extra field length
    nameBuf.copy(localHeader, 30);

    localParts.push(localHeader, dataBuf);

    const centralHeader = Buffer.alloc(46 + nameBuf.length);
    centralHeader.writeUInt32LE(0x02014b50, 0); // signature
    centralHeader.writeUInt16LE(20, 4); // version made by
    centralHeader.writeUInt16LE(20, 6); // version needed
    centralHeader.writeUInt16LE(0, 8); // flags
    centralHeader.writeUInt16LE(0, 10); // compression
    centralHeader.writeUInt16LE(0, 12); // mod time
    centralHeader.writeUInt16LE(0, 14); // mod date
    centralHeader.writeUInt32LE(crc, 16); // crc32
    centralHeader.writeUInt32LE(dataBuf.length, 20); // compressed size
    centralHeader.writeUInt32LE(dataBuf.length, 24); // uncompressed size
    centralHeader.writeUInt16LE(nameBuf.length, 28); // file name length
    centralHeader.writeUInt16LE(0, 30); // extra length
    centralHeader.writeUInt16LE(0, 32); // comment length
    centralHeader.writeUInt16LE(0, 34); // disk number
    centralHeader.writeUInt16LE(0, 36); // internal attrs
    centralHeader.writeUInt32LE(0, 38); // external attrs
    centralHeader.writeUInt32LE(offset, 42); // relative offset of local header
    nameBuf.copy(centralHeader, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + dataBuf.length;
  }

  const centralDirBuffer = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); // EOCD signature
  eocd.writeUInt16LE(0, 4); // disk number
  eocd.writeUInt16LE(0, 6); // disk with central dir
  eocd.writeUInt16LE(files.length, 8); // entries on this disk
  eocd.writeUInt16LE(files.length, 10); // total entries
  eocd.writeUInt32LE(centralDirBuffer.length, 12); // size of central dir
  eocd.writeUInt32LE(offset, 16); // offset of central dir
  eocd.writeUInt16LE(0, 20); // comment length

  return Buffer.concat([...localParts, centralDirBuffer, eocd]);
}

function crc32(buf: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  return `${mb.toFixed(2)} MB`;
}

export function sanitizeDownloadFilename(title: string): string {
  const slug = (title || 'game')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return `${slug || 'game'}.apk`;
}

export interface GeneratedIconStyle {
  initials: string;
  bgColor: string;
  accentColor: string;
  textColor: string;
  patternIndex: number;
}

const ICON_PALETTES = [
  { bg: '#EFF6FF', accent: '#1D4ED8', text: '#1E3A8A' },
  { bg: '#F0FDF4', accent: '#15803D', text: '#14532D' },
  { bg: '#FEF2F2', accent: '#B91C1C', text: '#7F1D1D' },
  { bg: '#FFFBEB', accent: '#B45309', text: '#78350F' },
  { bg: '#F5F3FF', accent: '#6D28D9', text: '#4C1D95' },
  { bg: '#ECFEFF', accent: '#0E7490', text: '#164E63' },
  { bg: '#F8FAFC', accent: '#334155', text: '#0F172A' },
];

export function deriveGameIconStyle(title: string): GeneratedIconStyle {
  const clean = (title || 'Game').trim();
  const words = clean.split(/\s+/).filter(Boolean);
  let initials = 'GM';
  if (words.length >= 2) {
    initials = (words[0][0] + words[1][0]).toUpperCase();
  } else if (words.length === 1 && words[0].length >= 2) {
    initials = words[0].slice(0, 2).toUpperCase();
  } else if (words.length === 1 && words[0].length === 1) {
    initials = words[0].toUpperCase();
  }

  let hash = 0;
  for (let i = 0; i < clean.length; i++) {
    hash = (hash * 31 + clean.charCodeAt(i)) >>> 0;
  }

  const palette = ICON_PALETTES[hash % ICON_PALETTES.length];
  return {
    initials,
    bgColor: palette.bg,
    accentColor: palette.accent,
    textColor: palette.text,
    patternIndex: hash % 4,
  };
}
