import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildValidApkBuffer,
  deriveGameIconStyle,
  formatFileSize,
  sanitizeDownloadFilename,
  validateApkBinary,
  validateApkFilename,
  validateGameMetadata,
} from './apkValidator';

test('validateGameMetadata trims whitespace and enforces length rules', () => {
  const emptyTitle = validateGameMetadata({ title: '   ', description: 'Valid description here' });
  assert.equal(emptyTitle.valid, false);

  const shortDesc = validateGameMetadata({ title: 'Pixel Quest', description: 'Too short' });
  assert.equal(shortDesc.valid, false);

  const valid = validateGameMetadata({
    title: '  Cyber   Runner 3D  ',
    description: '  A high-speed procedural Android arcade racing game with 60fps physics.  ',
    version: ' 2.1.0 ',
  });
  assert.equal(valid.valid, true);
  assert.equal(valid.sanitized?.title, 'Cyber Runner 3D');
  assert.equal(valid.sanitized?.version, '2.1.0');
});

test('validateApkFilename accepts only .apk and rejects .zip, .exe, .aab, .ipa, .html', () => {
  assert.equal(validateApkFilename('cyber-runner.apk').valid, true);
  assert.equal(validateApkFilename('CYBER_RUNNER.APK').valid, true);

  for (const invalid of ['archive.zip', 'installer.exe', 'bundle.aab', 'ios.ipa', 'index.html', 'setup.msi']) {
    const res = validateApkFilename(invalid);
    assert.equal(res.valid, false, `Expected ${invalid} to be rejected`);
  }
});

test('validateApkBinary verifies real APK structure and AndroidManifest.xml', () => {
  const validBuf = buildValidApkBuffer({
    packageName: 'com.apkforge.cyberrunner',
    versionName: '1.2.0',
    title: 'Cyber Runner',
  });

  const validRes = validateApkBinary(validBuf, 'cyber-runner.apk');
  assert.equal(validRes.valid, true);
  assert.equal(validRes.inspection?.hasAndroidManifest, true);
  assert.equal(validRes.inspection?.hasClassesDex, true);
  assert.equal(validRes.inspection?.hasResourcesArsc, true);

  // Reject random text renamed to .apk
  const fakeBuf = Buffer.from('This is not a valid APK or ZIP archive at all', 'utf8');
  const fakeRes = validateApkBinary(fakeBuf, 'fake-game.apk');
  assert.equal(fakeRes.valid, false);
  assert.match(fakeRes.error || '', /header/i);

  // Reject oversized APK
  const oversizeRes = validateApkBinary(validBuf, 'cyber-runner.apk', 100);
  assert.equal(oversizeRes.valid, false);
  assert.match(oversizeRes.error || '', /too large/i);
});

test('deriveGameIconStyle and format helpers produce deterministic output', () => {
  const style1 = deriveGameIconStyle('Shadow Blade Legends');
  const style2 = deriveGameIconStyle('Shadow Blade Legends');
  assert.deepEqual(style1, style2);
  assert.equal(style1.initials, 'SB');
  assert.equal(sanitizeDownloadFilename('Shadow Blade: Legends! 1.0'), 'shadow-blade-legends-1-0.apk');
  assert.equal(formatFileSize(1536), '1.5 KB');
});
