export type PublicationStatus = 'Published' | 'Unpublished' | 'Removed';

export type ReviewStatus = 'Pending' | 'Needs Changes' | 'Approved' | 'Rejected';

export type NotificationType =
  | 'SUBMISSION_RECEIVED'
  | 'SUBMISSION_APPROVED'
  | 'SUBMISSION_REJECTED'
  | 'CHANGES_REQUESTED'
  | 'SUBMISSION_RESUBMITTED'
  | 'ACCOUNT_VERIFIED';

export interface UserRecord {
  userId: string;
  email: string;
  emailVerified: boolean;
  createdAt: string;
  lastLoginAt: string;
  authProvider: 'email' | 'google';
  gmailConnected?: boolean;
}

export interface ApkInspectionSummary {
  fileName: string;
  fileSizeBytes: number;
  sha256: string;
  hasAndroidManifest: boolean;
  hasClassesDex: boolean;
  hasResourcesArsc: boolean;
  entryCount: number;
  entriesPreview: string[];
  formatVerifiedAt: string;
}

export interface GameRecord {
  gameId: string;
  title: string;
  description: string;
  version: string;
  storageObjectPath: string;
  fileSizeBytes: number;
  sha256: string;
  apkInspection: ApkInspectionSummary;
  publicationStatus: PublicationStatus;
  createdAt: string;
  publishedAt: string;
  updatedAt: string;
  publishedBy: string;
  sourceSubmissionId: string | null;
}

export interface CorrectionHistoryEntry {
  entryId: string;
  timestamp: string;
  actorType: 'admin' | 'user';
  actorIdentifier: string;
  action: 'SUBMITTED' | 'CHANGES_REQUESTED' | 'RESUBMITTED' | 'APPROVED' | 'REJECTED';
  message: string;
  formattedNotice?: string;
  version?: string;
  fileSizeBytes?: number;
  emailDeliveryStatus?: 'sent_via_gmail' | 'internal_only' | 'failed';
}

export interface SubmissionRecord {
  submissionId: string;
  userId: string;
  submittedByEmail: string;
  title: string;
  description: string;
  version: string;
  privateStorageObjectPath: string;
  fileSizeBytes: number;
  sha256: string;
  apkInspection: ApkInspectionSummary;
  reviewStatus: ReviewStatus;
  submittedAt: string;
  updatedAt: string;
  reviewedAt: string | null;
  reviewedBy: string | null;
  rejectionReason: string | null;
  latestCorrectionMessage: string | null;
  correctionHistory: CorrectionHistoryEntry[];
  publishedGameId: string | null;
}

export interface NotificationRecord {
  notificationId: string;
  recipientUserId: string;
  relatedSubmissionId: string | null;
  title: string;
  message: string;
  type: NotificationType;
  createdAt: string;
  readAt: string | null;
  emailDelivered?: boolean;
}

export interface ReviewMessageRecord {
  messageId: string;
  submissionId: string;
  recipientUserId: string;
  recipientEmail: string;
  administratorId: string;
  rawMessage: string;
  formattedMessage: string;
  statusTransition: ReviewStatus;
  createdAt: string;
  emailDeliveryStatus: 'sent_via_gmail' | 'internal_only' | 'failed';
}

export interface AuditLogRecord {
  logId: string;
  timestamp: string;
  administratorId: string;
  action:
    | 'ADMIN_LOGIN'
    | 'ADMIN_LOCK'
    | 'GAME_PUBLISHED'
    | 'GAME_EDITED'
    | 'GAME_APK_REPLACED'
    | 'GAME_UNPUBLISHED'
    | 'GAME_REPUBLISHED'
    | 'GAME_REMOVED'
    | 'SUBMISSION_APPROVED'
    | 'SUBMISSION_REJECTED'
    | 'SUBMISSION_CHANGES_REQUESTED';
  targetId: string;
  targetTitle: string;
  details: string;
}

export interface PlatformStats {
  totalPublishedGames: number;
  totalUnpublishedGames: number;
  pendingSubmissions: number;
  approvedSubmissions: number;
  rejectedSubmissions: number;
  needsChangesSubmissions: number;
}
