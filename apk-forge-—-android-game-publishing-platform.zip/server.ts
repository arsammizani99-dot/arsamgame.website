import 'dotenv/config';
import express, { type Request, type Response, type NextFunction } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { PlatformError, PlatformStore } from './src/server/store';

const PORT = 3000;
const store = new PlatformStore();

function decodeMetaHeader(req: Request): Record<string, unknown> {
  const rawHeader = req.headers['x-apk-meta'];
  if (typeof rawHeader === 'string' && rawHeader.trim()) {
    try {
      const jsonStr = Buffer.from(rawHeader, 'base64').toString('utf8');
      return JSON.parse(jsonStr) as Record<string, unknown>;
    } catch {
      throw new PlatformError('Malformed upload metadata header.', 400, 'INVALID_METADATA_HEADER');
    }
  }
  return {};
}

function extractBinaryAndMeta(req: Request): {
  meta: Record<string, unknown>;
  apkFileName: string;
  apkBuffer: Buffer;
} {
  if (Buffer.isBuffer(req.body)) {
    const meta = decodeMetaHeader(req);
    const apkFileName = typeof meta.apkFileName === 'string' ? meta.apkFileName : '';
    return {
      meta,
      apkFileName,
      apkBuffer: req.body,
    };
  }

  const body = (req.body || {}) as Record<string, unknown>;
  const apkFileName = typeof body.apkFileName === 'string' ? body.apkFileName : '';
  const apkBase64 = typeof body.apkBase64 === 'string' ? body.apkBase64 : '';
  const apkBuffer = apkBase64 ? Buffer.from(apkBase64, 'base64') : Buffer.alloc(0);
  return {
    meta: body,
    apkFileName,
    apkBuffer,
  };
}

function getAdminToken(req: Request): string | null {
  const headerToken = req.headers['x-admin-token'];
  if (typeof headerToken === 'string' && headerToken.trim()) {
    return headerToken.trim();
  }
  const auth = req.headers.authorization;
  if (typeof auth === 'string' && auth.startsWith('AdminBearer ')) {
    return auth.slice('AdminBearer '.length).trim();
  }
  if (req.body && typeof req.body === 'object' && 'adminToken' in req.body) {
    const bodyToken = (req.body as Record<string, unknown>).adminToken;
    if (typeof bodyToken === 'string') return bodyToken.trim();
  }
  return null;
}

function getUserToken(req: Request): string | null {
  const auth = req.headers.authorization;
  if (typeof auth === 'string' && auth.trim()) {
    return auth.trim();
  }
  const headerToken = req.headers['x-user-token'];
  if (typeof headerToken === 'string' && headerToken.trim()) {
    return headerToken.trim();
  }
  return null;
}

async function startServer() {
  const app = express();

  // Parse raw binary uploads up to 160 MB on upload routes
  app.use(
    '/api',
    express.raw({
      type: 'application/octet-stream',
      limit: '160mb',
    }),
  );

  // Parse JSON payloads up to 50 MB
  app.use('/api', express.json({ limit: '50mb' }));

  // Prevent caching of sensitive API responses
  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    next();
  });

  // --------------------------------------------------------------------------
  // SYSTEM & CONFIGURATION STATUS
  // --------------------------------------------------------------------------
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      maxApkSizeBytes: store.getMaxApkSizeBytes(),
      adminSecretConfigured: Boolean(process.env.ADMIN_PANEL_PASSWORD || 'arsam27'),
      firebaseConfigPresent: fs.existsSync(path.resolve(process.cwd(), 'firebase-applet-config.json')),
    });
  });

  // --------------------------------------------------------------------------
  // USER EMAIL & GOOGLE AUTHENTICATION
  // --------------------------------------------------------------------------
  app.post('/api/auth/register', (req, res, next) => {
    try {
      const result = store.registerUser({
        email: req.body?.email,
        password: req.body?.password,
      });
      res.status(201).json(result);
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/auth/login', (req, res, next) => {
    try {
      const result = store.loginUser({
        email: req.body?.email,
        password: req.body?.password,
      });
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/auth/google-sync', (req, res, next) => {
    try {
      const result = store.syncGoogleUser({
        email: req.body?.email,
        uid: req.body?.uid,
        gmailConnected: Boolean(req.body?.gmailConnected),
      });
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/auth/verify-email', (req, res, next) => {
    try {
      const currentUser = store.requireAuthenticatedUser(getUserToken(req), false);
      const token = typeof req.body?.token === 'string' ? req.body.token.trim() : undefined;
      const updatedUser = store.verifyUserEmail(currentUser.userId, token);
      res.json({ user: updatedUser });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/auth/forgot-password', (req, res, next) => {
    try {
      const result = store.requestPasswordReset(req.body?.email);
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/auth/reset-password', (req, res, next) => {
    try {
      const user = store.resetPassword({
        email: req.body?.email,
        resetToken: req.body?.resetToken,
        newPassword: req.body?.newPassword,
      });
      res.json({ user, message: 'Your password has been reset successfully. You may now sign in.' });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/auth/me', (req, res) => {
    const user = store.getUserBySessionToken(getUserToken(req));
    if (!user) {
      res.status(401).json({ error: 'Session expired or not signed in.', code: 'UNAUTHORIZED' });
      return;
    }
    res.json({ user });
  });

  app.post('/api/auth/logout', (req, res) => {
    store.logoutUser(getUserToken(req));
    res.json({ success: true });
  });

  // --------------------------------------------------------------------------
  // PUBLIC APPS LIBRARY & AUTHENTICATED APK DOWNLOADS
  // --------------------------------------------------------------------------
  app.get('/api/games', (req, res, next) => {
    try {
      const search = typeof req.query.search === 'string' ? req.query.search : undefined;
      const games = store.listPublicGames(search);
      res.json({ games });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/games/:gameId/download-token', (req, res, next) => {
    try {
      const ticket = store.createGameDownloadTicket({
        userSessionToken: getUserToken(req),
        gameId: req.params.gameId,
      });
      res.json({
        ...ticket,
        downloadUrl: `/api/games/${encodeURIComponent(req.params.gameId)}/download?token=${encodeURIComponent(ticket.downloadToken)}`,
      });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/games/:gameId/download', (req, res, next) => {
    try {
      const token = typeof req.query.token === 'string' ? req.query.token : null;
      const ticket = store.resolveDownloadTicket(token, 'game', req.params.gameId);

      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', `attachment; filename="${ticket.downloadFilename}"`);
      res.setHeader('Content-Length', String(ticket.fileSizeBytes));

      const stream = fs.createReadStream(ticket.filePath);
      stream.on('error', (err) => next(err));
      stream.pipe(res);
    } catch (err) {
      next(err);
    }
  });

  // --------------------------------------------------------------------------
  // USER APK SUBMISSIONS, RESUBMISSIONS & NOTIFICATIONS
  // --------------------------------------------------------------------------
  app.post('/api/submissions', (req, res, next) => {
    try {
      const { meta, apkFileName, apkBuffer } = extractBinaryAndMeta(req);
      const submission = store.createSubmission({
        userSessionToken: getUserToken(req),
        title: meta.title,
        description: meta.description,
        version: meta.version,
        apkFileName,
        apkBuffer,
      });
      res.status(201).json({ submission });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/submissions/:submissionId/resubmit', (req, res, next) => {
    try {
      const { meta, apkFileName, apkBuffer } = extractBinaryAndMeta(req);
      const submission = store.resubmitSubmission({
        userSessionToken: getUserToken(req),
        submissionId: req.params.submissionId,
        description: meta.description,
        version: meta.version,
        apkFileName,
        apkBuffer,
      });
      res.json({ submission });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/submissions/mine', (req, res, next) => {
    try {
      const submissions = store.listUserSubmissions(getUserToken(req));
      res.json({ submissions });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/submissions/:submissionId', (req, res, next) => {
    try {
      const submission = store.getUserSubmissionById(getUserToken(req), req.params.submissionId);
      res.json({ submission });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/notifications', (req, res, next) => {
    try {
      const notifications = store.listUserNotifications(getUserToken(req));
      const unreadCount = notifications.filter((n) => !n.readAt).length;
      res.json({ notifications, unreadCount });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/notifications/read-all', (req, res, next) => {
    try {
      const updatedCount = store.markAllNotificationsRead(getUserToken(req));
      res.json({ updatedCount });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/notifications/:notificationId/read', (req, res, next) => {
    try {
      const notification = store.markNotificationRead(getUserToken(req), req.params.notificationId);
      res.json({ notification });
    } catch (err) {
      next(err);
    }
  });

  // --------------------------------------------------------------------------
  // ADMINISTRATOR PANEL AUTH & OPERATIONS
  // --------------------------------------------------------------------------
  app.post('/api/admin/login', (req, res, next) => {
    try {
      const clientIp = req.ip || req.socket.remoteAddress || 'default';
      const result = store.verifyAdminPassword(req.body?.password, clientIp);
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/admin/lock', (req, res) => {
    const token = getAdminToken(req);
    store.lockAdminSession(token);
    res.json({ locked: true });
  });

  app.get('/api/admin/dashboard', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      store.requireAdminSession(adminToken);

      const status = typeof req.query.status === 'string' ? req.query.status : undefined;
      const search = typeof req.query.search === 'string' ? req.query.search : undefined;

      res.json({
        stats: store.getPlatformStats(),
        games: store.listAllGamesForAdmin(adminToken),
        submissions: store.listSubmissionsForAdmin(adminToken, { status, search }),
        auditLogs: store.getAuditLogs().slice(0, 100),
      });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/admin/games', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const { meta, apkFileName, apkBuffer } = extractBinaryAndMeta(req);
      const game = store.publishGameByAdmin({
        adminToken,
        title: meta.title,
        description: meta.description,
        version: meta.version,
        apkFileName,
        apkBuffer,
      });
      res.status(201).json({
        game,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.put('/api/admin/games/:gameId', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const { meta, apkFileName, apkBuffer } = extractBinaryAndMeta(req);
      const hasReplacementApk = Boolean(apkFileName && apkBuffer && apkBuffer.length > 0);

      const game = store.updateGameByAdmin({
        adminToken,
        gameId: req.params.gameId,
        title: meta.title,
        description: meta.description,
        version: meta.version,
        replacementApk: hasReplacementApk ? { fileName: apkFileName, buffer: apkBuffer } : null,
      });
      res.json({
        game,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.patch('/api/admin/games/:gameId/status', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const status = req.body?.status === 'Published' ? 'Published' : 'Unpublished';
      const game = store.setGamePublicationStatus({
        adminToken,
        gameId: req.params.gameId,
        status,
      });
      res.json({
        game,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.delete('/api/admin/games/:gameId', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      store.deleteGameByAdmin({
        adminToken,
        gameId: req.params.gameId,
      });
      res.json({
        deleted: true,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/admin/submissions', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const status = typeof req.query.status === 'string' ? req.query.status : undefined;
      const search = typeof req.query.search === 'string' ? req.query.search : undefined;
      const submissions = store.listSubmissionsForAdmin(adminToken, { status, search });
      res.json({
        submissions,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/admin/submissions/:submissionId/download-token', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const ticket = store.createSubmissionDownloadTicketForAdmin({
        adminToken,
        submissionId: req.params.submissionId,
      });
      res.json({
        ...ticket,
        downloadUrl: `/api/admin/submissions/${encodeURIComponent(req.params.submissionId)}/download?token=${encodeURIComponent(ticket.downloadToken)}`,
      });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/admin/submissions/:submissionId/download', (req, res, next) => {
    try {
      const token = typeof req.query.token === 'string' ? req.query.token : null;
      const ticket = store.resolveDownloadTicket(token, 'submission', req.params.submissionId);

      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', `attachment; filename="${ticket.downloadFilename}"`);
      res.setHeader('Content-Length', String(ticket.fileSizeBytes));

      const stream = fs.createReadStream(ticket.filePath);
      stream.on('error', (err) => next(err));
      stream.pipe(res);
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/admin/submissions/:submissionId/approve', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const result = store.approveSubmissionByAdmin({
        adminToken,
        submissionId: req.params.submissionId,
        emailDelivered: Boolean(req.body?.emailDelivered),
      });
      res.json({
        ...result,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/admin/submissions/:submissionId/reject', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const submission = store.rejectSubmissionByAdmin({
        adminToken,
        submissionId: req.params.submissionId,
        reason: req.body?.reason,
        emailDelivered: Boolean(req.body?.emailDelivered),
      });
      res.json({
        submission,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/admin/submissions/:submissionId/request-changes', (req, res, next) => {
    try {
      const adminToken = getAdminToken(req);
      const result = store.requestChangesByAdmin({
        adminToken,
        submissionId: req.params.submissionId,
        message: req.body?.message,
        emailDelivered: Boolean(req.body?.emailDelivered),
      });
      res.json({
        ...result,
        stats: store.getPlatformStats(),
      });
    } catch (err) {
      next(err);
    }
  });

  // Catch-all for unknown /api routes
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.', code: 'NOT_FOUND' });
  });

  // Global error handler for API routes
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof PlatformError) {
      res.status(err.statusCode).json({
        error: err.message,
        code: err.code,
      });
      return;
    }
    if (err && typeof err === 'object' && 'type' in err && (err as { type?: string }).type === 'entity.too.large') {
      res.status(413).json({
        error: 'Uploaded APK file exceeds the maximum allowed payload size.',
        code: 'FILE_TOO_LARGE',
      });
      return;
    }
    console.error('[Server Error]:', err instanceof Error ? err.message : 'Unknown error');
    res.status(500).json({
      error: 'An unexpected server error occurred. Please try again.',
      code: 'INTERNAL_SERVER_ERROR',
    });
  });

  // Mount Vite middleware in development or serve static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`APK Forge server listening on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
